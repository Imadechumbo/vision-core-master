# JARVIS CORE V5 — Plataforma Autônoma Universal

Base executável local para operação multi-projeto, com:
- control plane
- memory/scoring
- RCA adaptativo inicial
- patch ranking
- fila local
- execução semi-autônoma
- adapters por stack
- dashboard web operacional
- workers iniciais
- stable vault por projeto

## Instalação

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
```

## Comandos

### Registrar projeto
```bash
python apps/cli/jarvis.py project add technetgame --root "C:\projetos\technetgame" --stack node_express
```

### Listar projetos
```bash
python apps/cli/jarvis.py project list
```

### Executar missão
```bash
python apps/cli/jarvis.py mission "corrigir vision do technetgame" --project technetgame --base-url "https://api.technetgame.com.br" --dry-run
```

### Ver incidentes
```bash
python apps/cli/jarvis.py incidents --project technetgame
```

### Ver ranking de estratégias
```bash
python apps/cli/jarvis.py strategies --project technetgame
```

### Promover snapshot para GOLD
```bash
python apps/cli/jarvis.py stable promote --project technetgame
```

### Rollback
```bash
python apps/cli/jarvis.py stable rollback --project technetgame --target "C:\restore\technetgame"
```

### Rodar dashboard
```bash
python apps/dashboard/server.py
```

Acesse:
- http://127.0.0.1:8088

## Arquitetura

```text
JARVIS V5
├── control_plane       # orquestração e roteamento
├── execution_plane     # fila local e executor
├── intelligence_plane  # RCA adaptativo, ranking e planner
├── memory_plane        # incidentes, scoring e snapshots
├── integration_plane   # adapters por stack e domínio
├── interface_plane     # API do dashboard
└── workers             # workers externos, inclusive Go
```

## Observações
- Esta versão é executável e pronta para extensão.
- O modo de fila padrão é local em arquivo/SQLite.
- O worker Go incluído é um exemplo funcional de runtime distribuído.
- A aplicação automática de patch está protegida por policy/risk.
- Sem PASS GOLD nada é promovido.
