import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from jarvis_v5.control_plane.registry import ProjectRegistry
from jarvis_v5.control_plane.mission_router import MissionRouter
from jarvis_v5.control_plane.execution_controller import ExecutionController
from jarvis_v5.memory_plane.incident_store import IncidentStore
from jarvis_v5.memory_plane.strategy_store import StrategyStore
from jarvis_v5.memory_plane.stable_vault import StableVault


def build_parser():
    parser = argparse.ArgumentParser(description="JARVIS CORE V5")
    sub = parser.add_subparsers(dest="command")

    project = sub.add_parser("project", help="Gerenciar projetos")
    psub = project.add_subparsers(dest="project_command")
    padd = psub.add_parser("add")
    padd.add_argument("name")
    padd.add_argument("--root", required=True)
    padd.add_argument("--stack", required=True)
    psub.add_parser("list")

    mission = sub.add_parser("mission", help="Executar missão")
    mission.add_argument("text")
    mission.add_argument("--project", required=True)
    mission.add_argument("--base-url")
    mission.add_argument("--dry-run", action="store_true")
    mission.add_argument("--auto-apply", action="store_true")
    mission.add_argument("--auto-rollback", action="store_true")

    incidents = sub.add_parser("incidents", help="Listar incidentes")
    incidents.add_argument("--project", required=False)
    incidents.add_argument("--filter", required=False)

    strategies = sub.add_parser("strategies", help="Listar estratégias")
    strategies.add_argument("--project", required=False)

    stable = sub.add_parser("stable", help="Stable vault")
    ssub = stable.add_subparsers(dest="stable_command")
    sprom = ssub.add_parser("promote")
    sprom.add_argument("--project", required=True)
    srollback = ssub.add_parser("rollback")
    srollback.add_argument("--project", required=True)
    srollback.add_argument("--target", required=True)
    slist = ssub.add_parser("list")
    slist.add_argument("--project", required=False)

    runtime = sub.add_parser("runtime", help="Mostrar ajuda do runtime")
    runtime.add_argument("--host", default="127.0.0.1")
    runtime.add_argument("--port", default=8090, type=int)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    registry = ProjectRegistry(ROOT / "storage" / "projects")
    incidents = IncidentStore(ROOT / "storage")
    strategies = StrategyStore(ROOT / "storage")
    stable = StableVault(ROOT / "storage")

    if args.command == "project":
        if args.project_command == "add":
            project = registry.add_project(args.name, args.root, args.stack)
            print(json.dumps(project, indent=2, ensure_ascii=False))
            return
        if args.project_command == "list":
            print(json.dumps(registry.list_projects(), indent=2, ensure_ascii=False))
            return

    if args.command == "mission":
        project = registry.get_project(args.project)
        if not project:
            raise SystemExit(f"Projeto não encontrado: {args.project}")
        router = MissionRouter()
        controller = ExecutionController(
            storage_root=ROOT / "storage",
            registry=registry,
            incident_store=incidents,
            strategy_store=strategies,
            stable_vault=stable,
        )
        mission = router.route(
            text=args.text,
            project=project,
            base_url=args.base_url,
            dry_run=args.dry_run,
            auto_apply=args.auto_apply,
            auto_rollback=args.auto_rollback,
        )
        result = controller.run_mission(mission)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    if args.command == "incidents":
        print(json.dumps(incidents.query(project=args.project, keyword=args.filter), indent=2, ensure_ascii=False))
        return

    if args.command == "strategies":
        print(json.dumps(strategies.list_ranked(project=args.project), indent=2, ensure_ascii=False))
        return

    if args.command == "stable":
        if args.stable_command == "promote":
            print(json.dumps(stable.promote(args.project), indent=2, ensure_ascii=False))
            return
        if args.stable_command == "rollback":
            print(json.dumps(stable.rollback(args.project, args.target), indent=2, ensure_ascii=False))
            return
        if args.stable_command == "list":
            print(json.dumps(stable.list_entries(project=args.project), indent=2, ensure_ascii=False))
            return

    if args.command == "runtime":
        print(f"Runtime API disponível em runtime/server.py. Exemplo: uvicorn runtime.server:app --host {args.host} --port {args.port}")
        return

    parser.print_help()


if __name__ == "__main__":
    main()
