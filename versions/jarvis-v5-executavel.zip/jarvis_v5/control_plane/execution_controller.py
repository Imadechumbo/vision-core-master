from pathlib import Path
from jarvis_v5.execution_plane.local_queue import LocalQueue
from jarvis_v5.execution_plane.executor import MissionExecutor

class ExecutionController:
    def __init__(self, storage_root: Path, registry, incident_store, strategy_store, stable_vault):
        self.queue = LocalQueue(storage_root / "queue")
        self.executor = MissionExecutor(storage_root, registry, incident_store, strategy_store, stable_vault)

    def run_mission(self, mission: dict):
        self.queue.enqueue(mission)
        job = self.queue.dequeue()
        return self.executor.execute(job)
