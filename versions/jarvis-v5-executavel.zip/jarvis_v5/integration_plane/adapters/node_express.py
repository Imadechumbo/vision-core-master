from pathlib import Path

class NodeExpressAdapter:
    def find_critical_files(self, files):
        priorities = ["airoutes.js", "routes", "vision", "chat", "server.js", "app.js"]
        selected = []
        for token in priorities:
            selected.extend([f for f in files if token in f.lower()])
        seen = []
        for item in selected:
            if item not in seen:
                seen.append(item)
        return seen[:20]

    def critical_endpoints(self):
        return [
            {"name": "health", "method": "GET", "path": "/api/health"},
            {"name": "chat", "method": "POST", "path": "/api/v1/chat", "json": {"message": "ping"}},
            {"name": "vision", "method": "POST", "path": "/api/v1/chat/vision", "json": {"message": "ping"}},
        ]

    def infer_notes(self, mission):
        notes = ["adapter Node/Express ativo"]
        if mission["intent"] == "fix_vision":
            notes.append("buscando correção de validação de upload/vision")
        return notes

    def _pick_target(self, project_root):
        root = Path(project_root)
        candidates = []
        for p in root.rglob("*.js"):
            name = p.name.lower()
            rel = str(p.relative_to(root)).replace("\\", "/")
            score = 0
            if "airoutes" in name:
                score += 10
            if "route" in name:
                score += 6
            if "vision" in rel.lower():
                score += 5
            if "chat" in rel.lower():
                score += 4
            candidates.append((score, rel, p))
        candidates.sort(reverse=True)
        return candidates[0][2] if candidates else None

    def build_patch_candidate(self, mission, evidence, project_root):
        target = self._pick_target(project_root)
        before = target.read_text(encoding="utf-8", errors="ignore") if target and target.exists() else ""
        guard = """
// JARVIS_V5_VISION_GUARD_START
if (!req.file && !req.files && !req.body?.image && !req.body?.imageUrl) {
  return res.status(400).json({
    ok: false,
    error: "missing_image_input",
    detail: "Envie arquivo, image, imageUrl ou equivalente."
  });
}
// JARVIS_V5_VISION_GUARD_END
""".strip()

        after = before
        inserted = False
        if mission["intent"] == "fix_vision" and before:
            markers = ["router.post(", "app.post(", "async (req, res)", "(req, res) =>"]
            for marker in markers:
                idx = after.find(marker)
                if idx != -1:
                    line_end = after.find("\n", idx)
                    if line_end != -1 and "JARVIS_V5_VISION_GUARD_START" not in after:
                        after = after[:line_end+1] + guard + "\n" + after[line_end+1:]
                        inserted = True
                        break
        if not inserted and before:
            after = guard + "\n\n" + before

        return {
            "strategy_key": "node_express_fix_vision_guard",
            "target_file": str(target) if target else None,
            "before": before,
            "after": after,
            "operations": [{"type": "insert_guard", "file": str(target) if target else None}],
            "summary": "Inserir guarda de validação para vision/upload em rota Node/Express.",
        }

    def estimate_risk(self, candidate):
        return "medium" if candidate.get("target_file") else "high"

    def apply_patch(self, patch, project_root):
        target_file = patch.get("target_file")
        if not target_file:
            return {"applied": False, "mode": "require_approval", "notes": ["Arquivo alvo não identificado."]}
        path = Path(target_file)
        path.write_text(patch.get("after", ""), encoding="utf-8")
        return {"applied": True, "mode": "auto_apply", "notes": [f"Patch aplicado em {path.name}"]}
