from pathlib import Path

class PythonFastAPIAdapter:
    def find_critical_files(self, files):
        return [f for f in files if f.endswith(".py") and any(k in f.lower() for k in ["main", "app", "router", "api"])][:20]

    def critical_endpoints(self):
        return [
            {"name": "health", "method": "GET", "path": "/health"},
            {"name": "openapi", "method": "GET", "path": "/openapi.json"},
        ]

    def infer_notes(self, mission):
        return ["adapter Python/FastAPI ativo"]

    def build_patch_candidate(self, mission, evidence, project_root):
        root = Path(project_root)
        target = None
        for p in root.rglob("*.py"):
            if p.name in {"main.py", "app.py"}:
                target = p
                break
        before = target.read_text(encoding="utf-8", errors="ignore") if target else ""
        after = before
        return {
            "strategy_key": "python_fastapi_general_guard",
            "target_file": str(target) if target else None,
            "before": before,
            "after": after,
            "operations": [],
            "summary": "Nenhum patch FastAPI automático definido para esta missão.",
        }

    def estimate_risk(self, candidate):
        return "high"

    def apply_patch(self, patch, project_root):
        return {"applied": False, "mode": "require_approval", "notes": ["Patch FastAPI automático ainda não definido."]}
