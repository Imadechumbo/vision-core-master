import requests

class GateRunner:
    def __init__(self, adapter):
        self.adapter = adapter

    def _probe(self, method, url, json_body=None):
        try:
            r = requests.request(method, url, timeout=5, json=json_body)
            body = r.text[:300]
            return {"ok": r.status_code < 500, "status": r.status_code, "body": body}
        except Exception as exc:
            return {"ok": False, "status": 0, "body": str(exc)}

    def run(self, project: dict, mission: dict, evidence: dict):
        base_url = mission.get("base_url")
        checks = []
        if base_url:
            for endpoint in self.adapter.critical_endpoints():
                url = base_url.rstrip("/") + endpoint["path"]
                checks.append({
                    "name": endpoint["name"],
                    "method": endpoint["method"],
                    "url": url,
                    "result": self._probe(endpoint["method"], url, endpoint.get("json")),
                })
        else:
            checks.append({"name": "base_url_missing", "result": {"ok": False, "status": 0, "body": "base_url não informado"}})

        pass_gold = bool(base_url) and all(item["result"]["ok"] for item in checks)
        return {"checks": checks, "pass_gold": pass_gold}
