class AdaptiveRCA:
    def __init__(self, incident_store, strategy_store):
        self.incident_store = incident_store
        self.strategy_store = strategy_store

    def analyze(self, mission: dict, evidence: dict):
        prior = self.incident_store.query(project=mission["project"]["name"], keyword=mission["intent"])
        ranked = self.strategy_store.list_ranked(project=mission["project"]["name"])

        root_cause = "unknown"
        chain = []

        if mission["intent"] == "fix_vision":
            root_cause = "vision_contract_or_upload_validation"
            chain = [
                "endpoint multimodal falhou ou não foi validado",
                "ausência de validação robusta para arquivo/imagem",
                "provider vision ou contrato de upload inconsistente",
            ]
        elif not evidence["scan_signals"]["root_exists"]:
            root_cause = "invalid_project_root"
            chain = ["caminho do projeto não existe"]
        else:
            root_cause = "stack_or_runtime_misconfiguration"
            chain = ["diagnóstico geral por sinais do projeto"]

        anomalies = []
        if not evidence["critical_files"]:
            anomalies.append("nenhum arquivo crítico foi identificado pelo adapter")
        if not prior:
            anomalies.append("sem incidentes prévios semelhantes")
        return {
            "root_cause": root_cause,
            "cause_chain": chain,
            "anomalies": anomalies,
            "prior_incident_count": len(prior),
            "top_strategies": ranked[:3],
        }
