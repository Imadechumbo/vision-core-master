# MANUAL MESTRE — JARVIS CORE V5

## Missão
Transformar o fluxo manual de manutenção técnica em operação supervisionada por plataforma.

## Capacidades
- multi-projeto real
- contexto isolado por projeto
- memória persistente
- ranking de estratégias
- validação HTTP real
- rollback por stable vault
- painel operacional
- execução semi-autônoma
- runtime distribuível

## Regra central
**SEM PASS GOLD → NADA É PROMOVIDO**

## Fluxo
1. missão
2. resolução de intent
3. carregamento do contexto do projeto
4. scan
5. coleta de evidência
6. RCA adaptativo
7. geração/ranking de estratégia
8. policy de risco
9. execução
10. gates reais
11. incidente + scoring
12. promoção GOLD ou rollback
13. atualização do painel

## Operação recomendada
- baixo risco: auto-apply permitido
- médio risco: dry-run por padrão
- alto risco: aprovação manual

## Próxima evolução sugerida
- AST real para Python/JS
- Redis/NATS em vez de fila local
- painel React em vez de HTML simples
- aprendizado por embeddings/clusterização de incidentes
