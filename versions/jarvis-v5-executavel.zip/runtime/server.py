from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="JARVIS V5 Runtime")

class ExecutePayload(BaseModel):
    task: str
    args: dict = {}

@app.get("/health")
def health():
    return {"ok": True, "service": "jarvis-v5-runtime"}

@app.get("/runtime")
def runtime_info():
    return {"workers": ["local_queue", "executor", "go_http_worker"], "mode": "local"}

@app.post("/execute")
def execute(payload: ExecutePayload):
    return {"ok": True, "received": payload.model_dump()}
