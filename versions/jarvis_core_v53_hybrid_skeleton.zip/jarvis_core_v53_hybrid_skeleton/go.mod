module jarvis-core-v53

go 1.22
