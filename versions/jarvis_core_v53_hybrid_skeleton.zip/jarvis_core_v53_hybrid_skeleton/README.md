# JARVIS CORE V5.3 — Hybrid Skeleton

Esqueleto inicial executável com:

- CLI em Go (`cmd/jarvis`)
- core operacional em Python (`python/apps/cli/jarvis.py`)
- métodos base herdados dos modelos anteriores
- scan, bootstrap, gates, pipeline, incident store e snapshot GOLD

## Métodos incluídos neste skeleton

- `detect_project_root()`
- `scan_project()`
- `detect_stack()` via scanner
- `bootstrap_environment()`
- `prepare_runtime()` via bootstrap
- `start_runtime()`
- `probe_runtime()` via resultado do runtime/gates
- `run_gates()`
- `evaluate_gold()`
- `record_incident()`
- `create_snapshot()`
- `run_pipeline()`

## Estrutura

- `cmd/jarvis/main.go` → wrapper Go
- `python/apps/cli/jarvis.py` → CLI real
- `python/jarvis_core/projects/` → root detect + scanner
- `python/jarvis_core/bootstrap/` → bootstrap
- `python/jarvis_core/runtime/` → start runtime
- `python/jarvis_core/gates/` → HTTP gates
- `python/jarvis_core/incidents/` → JSON incident store
- `python/jarvis_core/snapshots/` → JSON snapshot store
- `python/jarvis_core/pipeline.py` → pipeline completo

## Requisitos

- Go 1.22+
- Python 3.10+

## Comandos

### Rodar direto no Python

```bash
python python/apps/cli/jarvis.py scan --project-root /caminho/projeto
python python/apps/cli/jarvis.py bootstrap --project-root /caminho/projeto
python python/apps/cli/jarvis.py gates --base-url https://api.technetgame.com.br --profile technetgame
python python/apps/cli/jarvis.py run --project-root /caminho/projeto --host 127.0.0.1 --port 8088 --profile default --skip-start
```

### Rodar via Go wrapper

```bash
go run ./cmd/jarvis -- scan --project-root /caminho/projeto
go run ./cmd/jarvis -- bootstrap --project-root /caminho/projeto
```

## Observações

- Este pacote é um skeleton inicial, não a versão V5.3 completa.
- `auto_recover`, `apply_playbook`, `rollback_patch`, `rollback_snapshot`, `schedule_jobs` e `queue_job` ainda não estão implementados aqui.
- A regra central já está respeitada: sem `pass_gold=true`, não há snapshot GOLD.
