#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from jarvis_core.bootstrap.engine import bootstrap_environment
from jarvis_core.gates.engine import run_http_gates
from jarvis_core.incidents.store import record_incident
from jarvis_core.pipeline import run_pipeline
from jarvis_core.projects.scanner import scan_project


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jarvis", description="JARVIS CORE V5.3 hybrid skeleton")
    sub = parser.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="scan project structure")
    scan.add_argument("--project-root", default="")

    bootstrap = sub.add_parser("bootstrap", help="prepare runtime environment")
    bootstrap.add_argument("--project-root", default="")
    bootstrap.add_argument("--host", default="127.0.0.1")
    bootstrap.add_argument("--port", type=int, default=8088)

    gates = sub.add_parser("gates", help="run HTTP gates")
    gates.add_argument("--base-url", required=True)
    gates.add_argument("--profile", default="default")

    run = sub.add_parser("run", help="full pipeline")
    run.add_argument("--project-root", default="")
    run.add_argument("--host", default="127.0.0.1")
    run.add_argument("--port", type=int, default=8088)
    run.add_argument("--profile", default="default")
    run.add_argument("--start-command", default="")
    run.add_argument("--skip-start", action="store_true")

    incident = sub.add_parser("incident", help="record incident manually")
    incident.add_argument("--project-root", default="")
    incident.add_argument("--category", required=True)
    incident.add_argument("--failure-type", required=True)
    incident.add_argument("--summary", required=True)
    incident.add_argument("--evidence", nargs="*", default=[])

    return parser


def main() -> int:
    args = build_parser().parse_args()

    if args.command == "scan":
        result = scan_project(args.project_root or None)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0

    if args.command == "bootstrap":
        result = bootstrap_environment(
            project_root=args.project_root or None,
            host=args.host,
            port=args.port,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0

    if args.command == "gates":
        result = run_http_gates(base_url=args.base_url, profile=args.profile)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result.get("pass_gold") else 2

    if args.command == "run":
        result = run_pipeline(
            project_root=args.project_root or None,
            host=args.host,
            port=args.port,
            profile=args.profile,
            start_command=args.start_command or None,
            skip_start=args.skip_start,
        )
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result.get("pass_gold") else 2

    if args.command == "incident":
        incident = record_incident(
            project_root=args.project_root or os.getcwd(),
            category=args.category,
            failure_type=args.failure_type,
            summary=args.summary,
            evidence=args.evidence,
        )
        print(json.dumps(incident, indent=2, ensure_ascii=False))
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
