from __future__ import annotations

import json
import os
from datetime import datetime, UTC
from pathlib import Path


def _jarvis_home() -> Path:
    return Path(os.environ.get("JARVIS_HOME", Path.cwd()))


def create_snapshot(project_root: str, status: str = "gold") -> dict:
    snapshot_id = "snapshot_" + datetime.now(UTC).strftime("%Y%m%d%H%M%S")
    data = {
        "id": snapshot_id,
        "status": status,
        "created_at": datetime.now(UTC).isoformat(),
        "project_root": project_root,
    }
    out_dir = _jarvis_home() / "data" / "snapshots"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f"{snapshot_id}.json").write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return data
