from __future__ import annotations

from jarvis_core.bootstrap.engine import bootstrap_environment
from jarvis_core.gates.engine import run_http_gates
from jarvis_core.incidents.store import record_incident
from jarvis_core.runtime.manager import start_runtime
from jarvis_core.snapshots.store import create_snapshot


def _build_base_url(host: str, port: int) -> str:
    return f"http://{host}:{port}"


def run_pipeline(
    project_root: str | None = None,
    host: str = "127.0.0.1",
    port: int = 8088,
    profile: str = "default",
    start_command: str | None = None,
    skip_start: bool = False,
) -> dict:
    bootstrap = bootstrap_environment(project_root=project_root, host=host, port=port)
    root = bootstrap["project_root"]

    runtime_result = {
        "started": False,
        "message": "runtime start skipped",
        "command": None,
        "pid": None,
    }
    if not skip_start:
        runtime_result = start_runtime(project_root=root, host=host, port=port, start_command=start_command)

    gates = run_http_gates(base_url=_build_base_url(host, port), profile=profile)

    incident = None
    snapshot = None
    if not gates["pass_gold"]:
        incident = record_incident(
            project_root=root,
            category="pipeline",
            failure_type="gate_failure",
            summary="One or more critical gates failed",
            evidence=[g["message"] for g in gates["gates"] if not g["passed"]],
        )
    else:
        snapshot = create_snapshot(project_root=root, status="gold")

    return {
        "status": "gold" if gates["pass_gold"] else "failed",
        "pass_gold": gates["pass_gold"],
        "project_root": root,
        "adapter": bootstrap["scan"]["project_type"],
        "bootstrap": bootstrap,
        "runtime": runtime_result,
        "gates": gates["gates"],
        "incident_id": incident["id"] if incident else None,
        "snapshot_id": snapshot["id"] if snapshot else None,
        "methods": {
            "scan_project": True,
            "detect_project_root": True,
            "bootstrap_environment": True,
            "prepare_runtime": True,
            "start_runtime": True,
            "probe_runtime": True,
            "run_gates": True,
            "evaluate_gold": True,
            "record_incident": True,
            "create_snapshot": True,
            "run_pipeline": True,
        },
    }
