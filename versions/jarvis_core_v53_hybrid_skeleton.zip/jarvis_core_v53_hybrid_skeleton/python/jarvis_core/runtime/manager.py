from __future__ import annotations

import os
import shlex
import subprocess
import time
from pathlib import Path


def _guess_start_command(project_root: str) -> str | None:
    root = Path(project_root)
    if (root / "package.json").exists():
        if (root / "server.js").exists():
            return "node server.js"
        if (root / "app.js").exists():
            return "node app.js"
        return "npm start"
    if (root / "main.py").exists():
        return "python main.py"
    return None


def start_runtime(project_root: str, host: str = "127.0.0.1", port: int = 8088, start_command: str | None = None) -> dict:
    command = start_command or _guess_start_command(project_root)
    if not command:
        return {
            "started": False,
            "message": "no start command detected",
            "command": None,
            "pid": None,
        }

    env = os.environ.copy()
    env["HOST"] = host
    env["PORT"] = str(port)

    process = subprocess.Popen(
        shlex.split(command),
        cwd=project_root,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(2)
    alive = process.poll() is None
    return {
        "started": alive,
        "message": "runtime started" if alive else "runtime exited early",
        "command": command,
        "pid": process.pid,
    }
