from __future__ import annotations

import json
import os
from datetime import datetime, UTC
from pathlib import Path


def _jarvis_home() -> Path:
    return Path(os.environ.get("JARVIS_HOME", Path.cwd()))


def record_incident(project_root: str, category: str, failure_type: str, summary: str, evidence: list[str] | None = None) -> dict:
    incident_id = "incident_" + datetime.now(UTC).strftime("%Y%m%d%H%M%S")
    data = {
        "id": incident_id,
        "timestamp": datetime.now(UTC).isoformat(),
        "project_root": project_root,
        "category": category,
        "failure_type": failure_type,
        "summary": summary,
        "evidence": evidence or [],
        "recovery_ok": False,
    }
    out_dir = _jarvis_home() / "data" / "incidents"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f"{incident_id}.json").write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return data
