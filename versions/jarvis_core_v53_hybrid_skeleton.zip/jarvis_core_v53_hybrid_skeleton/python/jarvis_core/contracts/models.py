from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any


@dataclass
class GateResult:
    name: str
    passed: bool
    severity: str
    duration_ms: int
    message: str
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class PipelineResult:
    status: str
    pass_gold: bool
    project_root: str
    adapter: str
    gates: list[GateResult]
    incident_id: str | None = None
    snapshot_id: str | None = None
    patch_ids: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["gates"] = [g.to_dict() for g in self.gates]
        return data
