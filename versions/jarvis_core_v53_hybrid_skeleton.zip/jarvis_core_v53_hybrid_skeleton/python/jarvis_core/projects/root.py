from __future__ import annotations

import os
from pathlib import Path

FINGERPRINTS = ["package.json", "requirements.txt", "pyproject.toml", "Dockerfile", ".git"]


def detect_project_root(project_root: str | None = None) -> str:
    if project_root:
        path = Path(project_root).expanduser().resolve()
        return str(path)

    cwd = Path.cwd().resolve()
    candidates = [cwd, *cwd.parents]
    for base in candidates:
        for fp in FINGERPRINTS:
            if (base / fp).exists():
                return str(base)
    return str(cwd)
