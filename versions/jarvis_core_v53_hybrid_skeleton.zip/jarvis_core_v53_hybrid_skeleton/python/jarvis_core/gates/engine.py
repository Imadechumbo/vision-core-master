from __future__ import annotations

import time
import urllib.error
import urllib.request

from jarvis_core.contracts.models import GateResult

PROFILES = {
    "default": ["/", "/health", "/api/health"],
    "technetgame": ["/api/health", "/api/news/latest", "/api/v1/chat"],
}


def _check_url(url: str, name: str) -> GateResult:
    start = time.perf_counter()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "JarvisCore/5.3"})
        with urllib.request.urlopen(req, timeout=6) as response:
            status = getattr(response, "status", 200)
            ok = 200 <= status < 500
            return GateResult(
                name=name,
                passed=ok,
                severity="critical",
                duration_ms=int((time.perf_counter() - start) * 1000),
                message=f"status={status}",
                details={"url": url, "status": status},
            )
    except urllib.error.HTTPError as exc:
        return GateResult(
            name=name,
            passed=200 <= exc.code < 500,
            severity="critical",
            duration_ms=int((time.perf_counter() - start) * 1000),
            message=f"http_error={exc.code}",
            details={"url": url, "status": exc.code},
        )
    except Exception as exc:
        return GateResult(
            name=name,
            passed=False,
            severity="critical",
            duration_ms=int((time.perf_counter() - start) * 1000),
            message=str(exc),
            details={"url": url},
        )


def run_http_gates(base_url: str, profile: str = "default") -> dict:
    endpoints = PROFILES.get(profile, PROFILES["default"])
    gates = [_check_url(base_url.rstrip("/") + ep, f"http:{ep}") for ep in endpoints]
    pass_gold = all(g.passed for g in gates)
    status = "gold" if pass_gold else "failed"
    return {
        "status": status,
        "pass_gold": pass_gold,
        "profile": profile,
        "base_url": base_url,
        "gates": [g.to_dict() for g in gates],
        "methods": {
            "run_gates": True,
            "evaluate_gold": True,
        },
    }
