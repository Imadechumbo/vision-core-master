package main

import (
    "fmt"
    "os"
    "os/exec"
    "path/filepath"
)

func main() {
    root, err := os.Getwd()
    if err != nil {
        fmt.Fprintf(os.Stderr, "failed to get cwd: %v\n", err)
        os.Exit(1)
    }

    args := os.Args[1:]
    if len(args) == 0 {
        args = []string{"run"}
    }

    script := filepath.Join(root, "python", "apps", "cli", "jarvis.py")
    cmdArgs := append([]string{script}, args...)
    cmd := exec.Command("python", cmdArgs...)
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr
    cmd.Stdin = os.Stdin
    cmd.Env = append(os.Environ(),
        "PYTHONPATH="+filepath.Join(root, "python"),
        "JARVIS_HOME="+root,
    )

    if err := cmd.Run(); err != nil {
        if exitErr, ok := err.(*exec.ExitError); ok {
            os.Exit(exitErr.ExitCode())
        }
        fmt.Fprintf(os.Stderr, "failed to execute python core: %v\n", err)
        os.Exit(1)
    }
}
