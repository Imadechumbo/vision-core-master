from __future__ import annotations

from datetime import datetime, UTC
from pathlib import Path

from jarvis_core.shared.io import jarvis_home, read_json, write_json, copy_file, safe_relpath, hash_file
from jarvis_core.state.store import update_state

TRACKED_FILES = ['server.js', 'app.js', 'package.json', 'Procfile', 'Dockerfile', '.jarvis.runtime.env']
TRACKED_DIRS = ['.ebextensions', 'src', 'config', 'configs']
TRACKED_PATTERNS = ['*.js', '*.json', '*.yaml', '*.yml', '*.env', '*.config']


def _path():
    return jarvis_home() / 'data' / 'snapshots' / 'snapshots.json'


def _snapshot_dir(snapshot_id: str) -> Path:
    return jarvis_home() / 'data' / 'snapshots' / snapshot_id


def list_snapshots() -> dict:
    return read_json(_path(), {'snapshots': [], 'current_snapshot_id': None})


def _discover_files(project_root: Path) -> list[Path]:
    files = []
    seen = set()
    for rel in TRACKED_FILES:
        candidate = project_root / rel
        if candidate.exists() and candidate.is_file():
            rp = str(candidate.resolve())
            if rp not in seen:
                seen.add(rp); files.append(candidate)
    for sub in TRACKED_DIRS:
        candidate = project_root / sub
        if candidate.exists() and candidate.is_dir():
            for p in candidate.rglob('*'):
                if p.is_file():
                    rp = str(p.resolve())
                    if rp not in seen:
                        seen.add(rp); files.append(p)
    for pattern in TRACKED_PATTERNS:
        for p in project_root.glob(pattern):
            if p.is_file():
                rp = str(p.resolve())
                if rp not in seen:
                    seen.add(rp); files.append(p)
    return sorted(files, key=lambda p: safe_relpath(p, project_root))


def create_snapshot(project_root: str, status: str = 'gold') -> dict:
    root = Path(project_root).resolve()
    data = list_snapshots()
    snapshot_id = 'snapshot_' + datetime.now(UTC).strftime('%Y%m%d%H%M%S')
    snapshot_dir = _snapshot_dir(snapshot_id)
    files_meta = []
    for src in _discover_files(root):
        rel = safe_relpath(src, root)
        dst = snapshot_dir / 'files' / rel
        copy_file(src, dst)
        files_meta.append({'source': rel, 'snapshot': str(dst), 'sha256': hash_file(src)})
    item = {
        'id': snapshot_id,
        'status': status,
        'created_at': datetime.now(UTC).isoformat(),
        'project_root': str(root),
        'scope': 'expanded_tree',
        'files': files_meta,
    }
    write_json(snapshot_dir / 'snapshot.json', item)
    data.setdefault('snapshots', []).append(item)
    data['current_snapshot_id'] = snapshot_id
    write_json(_path(), data)
    update_state(status, project_root=str(root), current_snapshot_id=snapshot_id)
    return item


def rollback_snapshot(snapshot_id: str) -> dict:
    data = list_snapshots()
    for item in data.get('snapshots', []):
        if item['id'] != snapshot_id:
            continue
        root = Path(item['project_root']).resolve()
        restored = []
        mismatches = []
        for file_meta in item.get('files', []):
            src = Path(file_meta['snapshot'])
            dst = root / file_meta['source']
            if src.exists():
                copy_file(src, dst)
                restored.append(str(dst))
                if file_meta.get('sha256') and hash_file(dst) != file_meta['sha256']:
                    mismatches.append(str(dst))
        data['current_snapshot_id'] = snapshot_id
        data['restored_at'] = datetime.now(UTC).isoformat()
        write_json(_path(), data)
        update_state('recovered', project_root=str(root), current_snapshot_id=snapshot_id)
        return {'snapshot_id': snapshot_id, 'restored': not mismatches, 'snapshot': item, 'restored_files': restored, 'mismatches': mismatches}
    return {'snapshot_id': snapshot_id, 'restored': False, 'message': 'snapshot not found'}
