from __future__ import annotations

from datetime import datetime, UTC
from pathlib import Path

from jarvis_core.shared.io import jarvis_home, read_json, write_json, slugify, ensure_dir


def _config_path() -> Path:
    return jarvis_home() / 'configs' / 'opensquad.json'


def load_opensquad_config() -> dict:
    return read_json(_config_path(), {
        'enabled': True,
        'mode': 'delegated',
        'roles': ['architect', 'diagnostician', 'patch-planner', 'validator'],
        'mission_handoff': True,
        'squads': {
            'recover': ['diagnostician', 'patch-planner', 'validator'],
            'scan': ['diagnostician', 'validator'],
            'run': ['architect', 'diagnostician', 'validator'],
            'queue': ['architect'],
        },
    })


def build_squad_plan(mission_text: str, intent: str, project_root: str | None = None) -> dict:
    config = load_opensquad_config()
    squad_id = f"squad_{slugify(intent)}_{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
    roles = config.get('squads', {}).get(intent) or config.get('roles', [])
    steps = []
    if 'architect' in roles:
        steps.append({'role': 'architect', 'task': 'translate mission into executable plan'})
    if 'diagnostician' in roles:
        steps.append({'role': 'diagnostician', 'task': 'gather evidence and classify probable root cause'})
    if 'patch-planner' in roles:
        steps.append({'role': 'patch-planner', 'task': 'propose safest patch/recovery sequence'})
    if 'validator' in roles:
        steps.append({'role': 'validator', 'task': 'define gates and GOLD criteria for this mission'})
    return {
        'enabled': config.get('enabled', False),
        'mode': config.get('mode', 'delegated'),
        'squad_id': squad_id,
        'mission': mission_text,
        'intent': intent,
        'project_root': project_root,
        'roles': roles,
        'steps': steps,
        'created_at': datetime.now(UTC).isoformat(),
    }


def persist_squad_plan(plan: dict) -> dict:
    base = ensure_dir(jarvis_home() / 'data' / 'opensquad' / 'plans')
    path = base / f"{plan['squad_id']}.json"
    write_json(path, plan)
    return {'path': str(path), 'plan': plan}


def persist_squad_run(run: dict) -> dict:
    base = ensure_dir(jarvis_home() / 'data' / 'opensquad' / 'runs')
    path = base / f"{run['run_id']}.json"
    write_json(path, run)
    return {'path': str(path), 'run': run}


def delegate_execution(plan: dict, payload: dict | None = None) -> dict:
    run = {
        'run_id': f"run_{plan['squad_id']}",
        'squad_id': plan['squad_id'],
        'intent': plan['intent'],
        'mode': plan['mode'],
        'project_root': plan.get('project_root'),
        'delegated': bool(plan.get('enabled')),
        'status': 'delegated' if plan.get('enabled') else 'disabled',
        'payload': payload or {},
        'created_at': datetime.now(UTC).isoformat(),
        'handlers': [{
            'role': step['role'],
            'status': 'planned',
            'task': step['task'],
        } for step in plan.get('steps', [])],
    }
    persisted = persist_squad_run(run)
    return {'delegated': run['delegated'], 'run_path': persisted['path'], 'run': run}
