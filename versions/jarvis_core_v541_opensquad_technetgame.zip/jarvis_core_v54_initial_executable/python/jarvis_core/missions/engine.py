from __future__ import annotations

from jarvis_core.opensquad.bridge import build_squad_plan, persist_squad_plan, delegate_execution


def resolve_intent(text: str) -> dict:
    lower = text.lower()
    if 'scan' in lower or 'analisar' in lower or 'diagnost' in lower:
        intent = 'scan'
    elif 'rollback' in lower or 'reverter' in lower:
        intent = 'rollback'
    elif 'gate' in lower or 'validar' in lower:
        intent = 'gates'
    elif 'corrigir' in lower or 'patch' in lower or 'recovery' in lower:
        intent = 'recover'
    elif 'fila' in lower or 'queue' in lower:
        intent = 'queue'
    elif 'agendar' in lower or 'scheduler' in lower:
        intent = 'schedule'
    else:
        intent = 'run'
    return {'intent': intent, 'confidence': 0.84, 'text': text}


def accept_mission(text: str, project_root: str | None = None, delegate: bool = True) -> dict:
    resolved = resolve_intent(text)
    squad_plan = build_squad_plan(text, resolved['intent'], project_root=project_root)
    persisted = persist_squad_plan(squad_plan)
    delegation = delegate_execution(squad_plan, payload={'mission_text': text}) if delegate else {'delegated': False}
    return {
        'mission': text,
        'accepted': True,
        'resolved': resolved,
        'dispatch_hint': resolved['intent'],
        'opensquad': {
            'enabled': squad_plan['enabled'],
            'mode': squad_plan['mode'],
            'plan_path': persisted['path'],
            'squad_id': squad_plan['squad_id'],
            'delegation': delegation,
        },
        'methods': {
            'accept_mission': True,
            'resolve_intent': True,
            'delegate_execution': True,
        },
    }
