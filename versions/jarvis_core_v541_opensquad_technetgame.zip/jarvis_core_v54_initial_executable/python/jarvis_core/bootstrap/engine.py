from __future__ import annotations

import os
import shutil
import socket
from pathlib import Path

from jarvis_core.projects.root import detect_project_root
from jarvis_core.projects.scanner import scan_project
from jarvis_core.state.store import update_state
from jarvis_core.adapters.node import adapter_summary, detect


def _find_executable(name: str) -> str | None:
    return shutil.which(name)


def _port_available(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex((host, port)) != 0


def bootstrap_environment(project_root: str | None = None, host: str = "127.0.0.1", port: int = 8088) -> dict:
    root = detect_project_root(project_root)
    scan = scan_project(root)

    deps = {
        "python": _find_executable("python"),
        "node": _find_executable("node"),
        "npm": _find_executable("npm"),
        "go": _find_executable("go"),
    }

    env_file = Path(root) / ".jarvis.runtime.env"
    env_file.write_text(f"HOST={host}\nPORT={port}\nPROJECT_ROOT={root}\n", encoding="utf-8")
    update_state(current_state="bootstrapped", project_root=root, profile="default")
    result = {
        "status": "ready",
        "project_root": root,
        "scan": scan,
        "dependencies": deps,
        "port_available": _port_available(host, port),
        "env_file": str(env_file),
        "pythonpath_hint": os.environ.get("PYTHONPATH", ""),
        "methods": {
            "detect_project_root": True,
            "scan_project": True,
            "detect_stack": True,
            "bootstrap_environment": True,
            "prepare_runtime": True,
        },
    }
    if detect(scan):
        result['adapter'] = adapter_summary(root)
    return result
