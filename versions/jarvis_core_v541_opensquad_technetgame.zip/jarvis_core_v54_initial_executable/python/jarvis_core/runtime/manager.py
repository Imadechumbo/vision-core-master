
from __future__ import annotations

import os
import shlex
import subprocess
import time
from pathlib import Path

from jarvis_core.adapters import node
from jarvis_core.shared.io import jarvis_home, ensure_dir


def _guess_start_command(project_root: str) -> str | None:
    command = node.suggest_start_command(project_root)
    if command:
        return command
    root = Path(project_root)
    if (root / 'main.py').exists():
        return 'python main.py'
    return None


def probe_runtime(pid: int | None) -> dict:
    if not pid:
        return {'alive': False, 'pid': pid}
    try:
        os.kill(pid, 0)
        return {'alive': True, 'pid': pid}
    except Exception:
        return {'alive': False, 'pid': pid}


def start_runtime(project_root: str, host: str = '127.0.0.1', port: int = 8088, start_command: str | None = None) -> dict:
    command = start_command or _guess_start_command(project_root)
    if not command:
        return {'started': False, 'message': 'no start command detected', 'command': None, 'pid': None}

    env = os.environ.copy()
    env['HOST'] = host
    env['PORT'] = str(port)

    logs_dir = ensure_dir(jarvis_home() / 'data' / 'logs')
    stdout_path = logs_dir / 'runtime.stdout.log'
    stderr_path = logs_dir / 'runtime.stderr.log'
    stdout_f = stdout_path.open('a', encoding='utf-8')
    stderr_f = stderr_path.open('a', encoding='utf-8')

    process = subprocess.Popen(shlex.split(command), cwd=project_root, env=env, stdout=stdout_f, stderr=stderr_f)
    time.sleep(2)
    alive = process.poll() is None
    return {
        'started': alive,
        'message': 'runtime started' if alive else 'runtime exited early',
        'command': command,
        'pid': process.pid,
        'probe': probe_runtime(process.pid),
        'stdout_log': str(stdout_path),
        'stderr_log': str(stderr_path),
    }
