
from __future__ import annotations

from jarvis_core.adapters import node
from jarvis_core.bootstrap.engine import bootstrap_environment
from jarvis_core.gates.engine import run_http_gates
from jarvis_core.incidents.store import record_incident, update_incident
from jarvis_core.missions.engine import accept_mission
from jarvis_core.patches.store import create_patch_record
from jarvis_core.recovery.engine import auto_recover
from jarvis_core.runtime.manager import start_runtime
from jarvis_core.snapshots.store import create_snapshot
from jarvis_core.state.store import update_state


def _build_base_url(host: str, port: int) -> str:
    return f'http://{host}:{port}'


def run_pipeline(project_root: str | None = None, host: str = '127.0.0.1', port: int = 8088, profile: str = 'default', start_command: str | None = None, skip_start: bool = False, mission: str | None = None) -> dict:
    mission_result = accept_mission(mission, project_root=project_root) if mission else None
    update_state('scanning', project_root=project_root or 'auto', profile=profile)
    bootstrap = bootstrap_environment(project_root=project_root, host=host, port=port)
    root = bootstrap['project_root']
    chosen_profile = node.build_gate_profile(root, profile)

    update_state('starting', project_root=root, profile=chosen_profile)
    runtime_result = {'started': False, 'message': 'runtime start skipped', 'command': None, 'pid': None}
    if not skip_start:
        runtime_result = start_runtime(project_root=root, host=host, port=port, start_command=start_command)

    update_state('validating', project_root=root, profile=chosen_profile)
    gates = run_http_gates(base_url=_build_base_url(host, port), profile=chosen_profile)

    incident = None
    recovery = None
    patch = None
    snapshot = None

    if not gates['pass_gold']:
        incident = record_incident(project_root=root, category='pipeline', failure_type='gate_failure', summary='One or more critical gates failed', evidence=[g['message'] for g in gates['gates'] if not g['passed']], metadata={'runtime': runtime_result, 'profile': chosen_profile})
        recovery = auto_recover(root, runtime_result, gates)
        update_incident(incident['id'], {'recovery_ok': recovery.get('recovered', False), 'recovery': recovery})
        if recovery.get('recovered'):
            patch = create_patch_record(root, f"Auto-recovery planned via playbook {recovery['classified']['playbook']}", [t['file'] for t in recovery.get('patch_plan', {}).get('targets', [])])
            gates = run_http_gates(base_url=_build_base_url(host, port), profile=chosen_profile)

    if gates['pass_gold']:
        update_state('gold', project_root=root, profile=chosen_profile)
        snapshot = create_snapshot(project_root=root, status='gold')
    else:
        update_state('failed', project_root=root, profile=chosen_profile)

    return {
        'status': 'gold' if gates['pass_gold'] else 'failed',
        'pass_gold': gates['pass_gold'],
        'project_root': root,
        'adapter': bootstrap['scan']['project_type'],
        'bootstrap': bootstrap,
        'mission': mission_result,
        'runtime': runtime_result,
        'gates': gates['gates'],
        'incident_id': incident['id'] if incident else None,
        'snapshot_id': snapshot['id'] if snapshot else None,
        'patch_id': patch['id'] if patch else None,
        'recovery': recovery,
        'methods': {
            'accept_mission': True,
            'resolve_intent': True,
            'scan_project': True,
            'detect_project_root': True,
            'detect_stack': True,
            'select_adapter': True,
            'bootstrap_environment': True,
            'prepare_runtime': True,
            'start_runtime': True,
            'probe_runtime': True,
            'run_gates': True,
            'evaluate_gold': True,
            'record_incident': True,
            'classify_failure': True,
            'apply_playbook': True,
            'auto_recover': True,
            'create_snapshot': True,
            'rollback_patch': True,
            'rollback_snapshot': True,
            'schedule_jobs': True,
            'queue_job': True,
            'update_state': True,
            'run_pipeline': True,
            'opensquad_bridge': True,
        },
    }
