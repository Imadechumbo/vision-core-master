
from __future__ import annotations

from pathlib import Path

from jarvis_core.patches.planner import generate_patch_plan


def classify_failure(runtime_result: dict, gates: dict) -> dict:
    message = (runtime_result.get('message') or '') + ' ' + ' '.join(g.get('message', '') for g in gates.get('gates', []))
    lower = message.lower()
    if 'address already in use' in lower or 'eaddrinuse' in lower:
        failure_type = 'port_conflict'
        playbook = 'port_conflict'
    elif 'cannot find module' in lower or 'npm' in lower:
        failure_type = 'missing_node_dependency'
        playbook = 'missing_node_dependency'
    elif 'no module named' in lower:
        failure_type = 'missing_python_dependency'
        playbook = 'missing_python_dependency'
    elif runtime_result.get('started') is False:
        failure_type = 'node_runtime_failed'
        playbook = 'node_runtime_failed'
    else:
        failure_type = 'health_endpoint_failed'
        playbook = 'health_endpoint_failed'
    return {'failure_type': failure_type, 'playbook': playbook, 'evidence': [message.strip()]}


def _parse_simple_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    actions = []
    current_key = None
    data = {}
    for raw in path.read_text(encoding='utf-8').splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('- '):
            actions.append(line[2:].strip())
            continue
        if ':' in line:
            key, value = line.split(':', 1)
            data[key.strip()] = value.strip().strip('"')
            current_key = key.strip()
    if actions:
        data['actions'] = actions
    return data


def apply_playbook(project_root: str, playbook_name: str) -> dict:
    path = Path(__file__).resolve().parents[3] / 'playbooks' / f'{playbook_name}.yaml'
    parsed = _parse_simple_yaml(path)
    exists = path.exists()
    return {
        'playbook': playbook_name,
        'found': exists,
        'project_root': project_root,
        'actions': parsed.get('actions', ['manual review required'] if exists else ['playbook not found']),
        'applied': exists,
    }


def auto_recover(project_root: str, runtime_result: dict, gates: dict) -> dict:
    classified = classify_failure(runtime_result, gates)
    applied = apply_playbook(project_root, classified['playbook'])
    plan = generate_patch_plan(project_root, classified)
    return {'classified': classified, 'applied': applied, 'patch_plan': plan, 'recovered': applied.get('applied', False)}
