from __future__ import annotations

from datetime import datetime, UTC
from pathlib import Path
from typing import Any

from jarvis_core.shared.io import jarvis_home, write_json, read_json


def record_incident(project_root: str, category: str, failure_type: str, summary: str, evidence: list[str] | None = None, metadata: dict[str, Any] | None = None) -> dict:
    incident_id = "incident_" + datetime.now(UTC).strftime("%Y%m%d%H%M%S")
    data = {
        "id": incident_id,
        "timestamp": datetime.now(UTC).isoformat(),
        "project_root": project_root,
        "category": category,
        "failure_type": failure_type,
        "summary": summary,
        "evidence": evidence or [],
        "recovery_ok": False,
        "metadata": metadata or {},
    }
    out_dir = jarvis_home() / "data" / "incidents"
    write_json(out_dir / f"{incident_id}.json", data)
    return data


def update_incident(incident_id: str, updates: dict) -> dict:
    path = jarvis_home() / "data" / "incidents" / f"{incident_id}.json"
    data = read_json(path, {})
    data.update(updates)
    write_json(path, data)
    return data
