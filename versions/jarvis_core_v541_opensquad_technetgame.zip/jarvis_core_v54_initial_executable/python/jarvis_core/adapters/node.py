from __future__ import annotations

import json
from pathlib import Path

TECHNET_HEALTH = ["/api/health", "/api/news/latest", "/api/v1/chat"]
TECHNET_OPTIONAL = ["/api/v1/chat/vision"]


def _read_package_json(root: Path) -> dict:
    try:
        return json.loads((root / "package.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def detect(project: dict) -> bool:
    return project.get("project_type") == "node_api" or project.get("node_project")


def detect_technetgame(root: str | Path) -> dict:
    path = Path(root)
    files = {
        'procfile': (path / 'Procfile').exists(),
        'ebextensions': (path / '.ebextensions').exists(),
        'server_js': (path / 'server.js').exists(),
        'app_js': (path / 'app.js').exists(),
        'src': (path / 'src').exists(),
    }
    pkg = _read_package_json(path)
    scripts = pkg.get('scripts', {})
    hints = []
    if files['ebextensions']:
        hints.append('elastic_beanstalk_ready')
    if files['procfile']:
        hints.append('procfile_present')
    if scripts.get('start'):
        hints.append('npm_start_available')
    is_tg = bool((files['procfile'] or files['ebextensions']) and (files['server_js'] or files['app_js'] or files['src']))
    return {
        'is_technetgame': is_tg,
        'files': files,
        'scripts': scripts,
        'hints': hints,
        'critical_endpoints': TECHNET_HEALTH,
        'optional_endpoints': TECHNET_OPTIONAL,
    }


def suggest_start_command(project_root: str) -> str | None:
    root = Path(project_root)
    pkg = _read_package_json(root)
    scripts = pkg.get("scripts", {})
    tech = detect_technetgame(root)
    if scripts.get('start'):
        return 'npm start'
    if tech['is_technetgame']:
        if (root / 'server.js').exists():
            return 'node server.js'
        if (root / 'app.js').exists():
            return 'node app.js'
        if (root / 'src' / 'server.js').exists():
            return 'node src/server.js'
        if (root / 'src' / 'app.js').exists():
            return 'node src/app.js'
    for name in ["server.js", "app.js"]:
        if (root / name).exists():
            return f"node {name}"
    if (root / "src" / "server.js").exists():
        return "node src/server.js"
    return None


def build_gate_profile(project_root: str, requested: str = "default") -> str:
    root = Path(project_root)
    if requested != "default":
        return requested
    if detect_technetgame(root).get('is_technetgame'):
        return 'technetgame'
    return 'default'


def adapter_summary(project_root: str) -> dict:
    root = Path(project_root)
    tech = detect_technetgame(root)
    command = suggest_start_command(project_root)
    return {
        'adapter': 'node',
        'start_command': command,
        'gate_profile': build_gate_profile(project_root),
        'technetgame': tech,
    }
