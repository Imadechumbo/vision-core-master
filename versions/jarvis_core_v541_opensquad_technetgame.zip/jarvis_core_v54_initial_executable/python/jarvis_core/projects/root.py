from __future__ import annotations

from pathlib import Path

FINGERPRINTS = ["package.json", "requirements.txt", "pyproject.toml", "Dockerfile", ".git", "Procfile"]


def detect_project_root(project_root: str | None = None) -> str:
    if project_root:
        return str(Path(project_root).expanduser().resolve())

    cwd = Path.cwd().resolve()
    candidates = [cwd, *cwd.parents]
    for base in candidates:
        for fp in FINGERPRINTS:
            if (base / fp).exists():
                return str(base)
        for child in base.iterdir() if base.exists() else []:
            if child.is_dir() and any((child / fp).exists() for fp in FINGERPRINTS):
                return str(child.resolve())
    return str(cwd)
