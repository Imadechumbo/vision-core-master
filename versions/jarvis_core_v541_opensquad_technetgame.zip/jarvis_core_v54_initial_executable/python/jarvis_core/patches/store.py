
from __future__ import annotations

from datetime import datetime, UTC
from pathlib import Path

from jarvis_core.shared.io import jarvis_home, read_json, write_json, copy_file, ensure_dir, safe_relpath
from jarvis_core.state.store import update_state


def _index_path():
    return jarvis_home() / 'data' / 'patches' / 'patches.json'


def _patch_dir(patch_id: str) -> Path:
    return jarvis_home() / 'data' / 'patches' / patch_id


def list_patches() -> dict:
    return read_json(_index_path(), {'patches': []})


def _register_patch(item: dict) -> dict:
    data = list_patches()
    data.setdefault('patches', []).append(item)
    write_json(_index_path(), data)
    return item


def create_patch_record(project_root: str, summary: str, files: list[str]) -> dict:
    item = {
        'id': 'patch_' + datetime.now(UTC).strftime('%Y%m%d%H%M%S'),
        'project_root': project_root,
        'summary': summary,
        'files': files,
        'rolled_back': False,
        'created_at': datetime.now(UTC).isoformat(),
        'backups': [],
        'type': 'record',
    }
    update_state('patched', project_root=project_root, current_patch_id=item['id'])
    return _register_patch(item)


def apply_text_patch(project_root: str, relative_path: str, search_text: str, replace_text: str, summary: str = 'text patch') -> dict:
    root = Path(project_root).resolve()
    target = (root / relative_path).resolve()
    if not target.exists():
        return {'applied': False, 'message': 'target file not found', 'file': str(target)}
    original = target.read_text(encoding='utf-8')
    if search_text not in original:
        return {'applied': False, 'message': 'search text not found', 'file': str(target)}
    patch_id = 'patch_' + datetime.now(UTC).strftime('%Y%m%d%H%M%S')
    patch_dir = _patch_dir(patch_id)
    backup_rel = safe_relpath(target, root)
    backup_path = patch_dir / 'backups' / backup_rel
    copy_file(target, backup_path)
    target.write_text(original.replace(search_text, replace_text, 1), encoding='utf-8')
    item = {
        'id': patch_id,
        'project_root': str(root),
        'summary': summary,
        'files': [backup_rel],
        'rolled_back': False,
        'created_at': datetime.now(UTC).isoformat(),
        'backups': [{'source': backup_rel, 'backup': str(backup_path)}],
        'type': 'text_patch',
    }
    write_json(patch_dir / 'manifest.json', item)
    _register_patch(item)
    update_state('patched', project_root=str(root), current_patch_id=patch_id)
    return {'applied': True, 'patch': item}


def rollback_patch(patch_id: str) -> dict:
    data = list_patches()
    for item in data.get('patches', []):
        if item['id'] != patch_id:
            continue
        root = Path(item['project_root']).resolve()
        restored = []
        for backup in item.get('backups', []):
            source_rel = backup['source']
            backup_path = Path(backup['backup'])
            target = root / source_rel
            if backup_path.exists():
                copy_file(backup_path, target)
                restored.append(str(target))
        item['rolled_back'] = True
        item['rolled_back_at'] = datetime.now(UTC).isoformat()
        item['restored_files'] = restored
        write_json(_index_path(), data)
        update_state('rollback', project_root=str(root), current_patch_id=patch_id)
        return {'patch_id': patch_id, 'rolled_back': True, 'patch': item, 'restored_files': restored}
    return {'patch_id': patch_id, 'rolled_back': False, 'message': 'patch not found'}
