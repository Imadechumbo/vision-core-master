
from __future__ import annotations

from datetime import datetime, UTC


def generate_patch_plan(project_root: str, classification: dict, scan: dict | None = None) -> dict:
    failure_type = classification.get('failure_type', 'generic_failure')
    targets = []
    if failure_type == 'missing_node_dependency':
        targets.append({'file': 'package.json', 'strategy': 'manifest_patch', 'action': 'review and add missing dependency'})
    elif failure_type == 'port_conflict':
        targets.append({'file': '.jarvis.runtime.env', 'strategy': 'env_patch', 'action': 'change runtime port'})
    elif failure_type == 'health_endpoint_failed':
        targets.append({'file': 'server.js', 'strategy': 'line_edit', 'action': 'review health route and startup path'})
    else:
        targets.append({'file': 'runtime', 'strategy': 'playbook_guided', 'action': 'stabilize runtime and rerun gates'})
    return {
        'patch_plan_id': 'plan_' + datetime.now(UTC).strftime('%Y%m%d%H%M%S'),
        'project_root': project_root,
        'reason': failure_type,
        'targets': targets,
        'risk': 'medium' if targets else 'low',
        'requires_supervision': True,
    }
