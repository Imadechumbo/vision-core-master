
from __future__ import annotations

from datetime import datetime, UTC

from jarvis_core.shared.io import jarvis_home, read_json, write_json


def _state_path():
    return jarvis_home() / 'data' / 'state' / 'state.json'


def load_state() -> dict:
    return read_json(_state_path(), {
        'current_state': 'idle',
        'history': [],
        'current_snapshot_id': None,
        'current_patch_id': None,
        'active_jobs': [],
    })


def update_state(current_state: str, **metadata) -> dict:
    data = load_state()
    data['current_state'] = current_state
    if 'current_snapshot_id' in metadata:
        data['current_snapshot_id'] = metadata['current_snapshot_id']
    if 'current_patch_id' in metadata:
        data['current_patch_id'] = metadata['current_patch_id']
    if 'active_jobs' in metadata:
        data['active_jobs'] = metadata['active_jobs']
    data.setdefault('history', []).append({'state': current_state, 'timestamp': datetime.now(UTC).isoformat(), **metadata})
    write_json(_state_path(), data)
    return data
