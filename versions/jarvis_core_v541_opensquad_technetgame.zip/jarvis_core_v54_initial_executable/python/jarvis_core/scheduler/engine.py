from __future__ import annotations

from datetime import datetime, UTC
import time

from jarvis_core.shared.io import jarvis_home, read_json, write_json
from jarvis_core.queue.store import queue_job, worker_run_once
from jarvis_core.state.store import update_state


def _path():
    return jarvis_home() / 'data' / 'scheduler' / 'jobs.json'


def _load() -> dict:
    return read_json(_path(), {'jobs': []})


def _save(data: dict) -> None:
    write_json(_path(), data)


def schedule_jobs(name: str, every_seconds: int, command: str, payload: dict | None = None) -> dict:
    data = _load()
    item = {
        'name': name,
        'every_seconds': every_seconds,
        'command': command,
        'payload': payload or {},
        'last_run_at': None,
        'last_job_id': None,
        'created_at': datetime.now(UTC).isoformat(),
    }
    data.setdefault('jobs', []).append(item)
    _save(data)
    return item


def _due(job: dict) -> bool:
    if not job.get('last_run_at'):
        return True
    try:
        last = datetime.fromisoformat(job['last_run_at'].replace('Z', '+00:00'))
    except Exception:
        return True
    delta = datetime.now(UTC) - last.astimezone(UTC)
    return delta.total_seconds() >= int(job.get('every_seconds', 60))


def run_due_jobs_once() -> dict:
    data = _load()
    queued = []
    now = datetime.now(UTC).isoformat()
    for job in data.get('jobs', []):
        if _due(job):
            queued_job = queue_job(job['command'], {**job.get('payload', {}), 'scheduled': True, 'schedule_name': job['name']})
            queued.append(queued_job)
            job['last_run_at'] = now
            job['last_job_id'] = queued_job['id']
    _save(data)
    return {'queued_count': len(queued), 'queued': queued}


def scheduler_loop(tick_seconds: int = 10, max_cycles: int | None = None, run_worker: bool = True) -> dict:
    cycles = 0
    dispatched = 0
    processed = 0
    update_state('scheduler_running')
    while True:
        queued = run_due_jobs_once()
        dispatched += queued.get('queued_count', 0)
        if run_worker:
            result = worker_run_once()
            if result.get('processed'):
                processed += 1
        cycles += 1
        if max_cycles is not None and cycles >= max_cycles:
            update_state('idle')
            return {'cycles': cycles, 'dispatched': dispatched, 'processed': processed}
        time.sleep(tick_seconds)
