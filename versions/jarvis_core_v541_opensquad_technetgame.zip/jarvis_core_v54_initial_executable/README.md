# JARVIS CORE V5.4.1

Pacote híbrido inicial evoluído com:
- adapter Node TechNetGame mais profundo
- restore expandido por árvore
- worker da fila com retry/backoff exponencial
- scheduler contínuo
- patch planner supervisionado (inicial)
- execução delegada OpenSquad por squad de missão

## Estrutura
- `python/jarvis_core/adapters/node.py` → adapter Node/TechNetGame
- `python/jarvis_core/snapshots/store.py` → snapshot/restore por árvore rastreada
- `python/jarvis_core/queue/store.py` → fila + worker + retry/backoff
- `python/jarvis_core/scheduler/engine.py` → scheduler contínuo
- `python/jarvis_core/opensquad/bridge.py` → delegação por squad

## Comandos principais
```bash
python python/apps/cli/jarvis.py mission "corrigir runtime do technetgame"
python python/apps/cli/jarvis.py run --project-root "C:\SEU_PROJETO" --profile technetgame --mission "corrigir runtime do technetgame"
python python/apps/cli/jarvis.py scan --project-root "C:\SEU_PROJETO"
python python/apps/cli/jarvis.py bootstrap --project-root "C:\SEU_PROJETO"
python python/apps/cli/jarvis.py snapshot-create --project-root "C:\SEU_PROJETO"
python python/apps/cli/jarvis.py rollback-snapshot --snapshot-id snapshot_YYYYMMDDHHMMSS
python python/apps/cli/jarvis.py queue --name opensquad_mission --payload '{"text":"corrigir runtime do technetgame","project_root":"C:\SEU_PROJETO"}'
python python/apps/cli/jarvis.py worker-run-once
python python/apps/cli/jarvis.py scheduler-loop --tick-seconds 10 --max-cycles 5
```

## Regra central
SEM PASS GOLD → NADA É PROMOVIDO
