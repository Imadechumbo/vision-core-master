
# JARVIS CORE V5.4 INITIAL EXECUTABLE

Pacote híbrido inicial com:
- rollback real de patch por backup de arquivo
- snapshot real de arquivos rastreados
- worker da fila
- scheduler contínuo
- patch planner supervisionado (inicial)
- bridge de integração com OpenSquad em modo advisory

## Estrutura
- `cmd/jarvis/main.go` → wrapper Go para delegar ao core Python
- `python/apps/cli/jarvis.py` → CLI principal
- `python/jarvis_core/opensquad/bridge.py` → plano cooperativo para OpenSquad
- `python/jarvis_core/patches/store.py` → patch real + rollback
- `python/jarvis_core/snapshots/store.py` → snapshot real + restore
- `python/jarvis_core/queue/store.py` → fila + worker
- `python/jarvis_core/scheduler/engine.py` → scheduler contínuo

## OpenSquad
O pacote adiciona uma ponte em `configs/opensquad.json` e grava planos de missão em:
- `data/opensquad/plans/*.json`

Uso atual:
- advisory/cooperative
- não executa o framework OpenSquad diretamente
- prepara handoff estruturado de missão, intenção e papéis

## Comandos principais
```bash
python python/apps/cli/jarvis.py mission "corrigir runtime do technetgame"
python python/apps/cli/jarvis.py run --project-root "C:\SEU_PROJETO" --profile technetgame --mission "corrigir runtime do technetgame"
python python/apps/cli/jarvis.py apply-text-patch --project-root "C:\SEU_PROJETO" --file package.json --search '"name": "app"' --replace '"name": "app-fixed"'
python python/apps/cli/jarvis.py rollback-patch --patch-id patch_YYYYMMDDHHMMSS
python python/apps/cli/jarvis.py snapshot-create --project-root "C:\SEU_PROJETO"
python python/apps/cli/jarvis.py rollback-snapshot --snapshot-id snapshot_YYYYMMDDHHMMSS
python python/apps/cli/jarvis.py queue --name scan --payload '{"project_root":"C:\SEU_PROJETO"}'
python python/apps/cli/jarvis.py worker-run-once
python python/apps/cli/jarvis.py schedule --name tg-hourly-scan --every-seconds 3600 --command scan --payload '{"project_root":"C:\SEU_PROJETO"}'
python python/apps/cli/jarvis.py scheduler-loop --tick-seconds 10 --max-cycles 5
```

## Observações
- rollback real está implementado para patches criados pelo próprio JARVIS
- snapshot real cobre arquivos rastreados mais comuns do projeto
- scheduler e worker já são executáveis, mas ainda são simples
- planner supervisionado gera plano; não altera arquivos sozinho sem comando explícito

## Regra central
SEM PASS GOLD → NADA É PROMOVIDO
