
from __future__ import annotations

from datetime import datetime, UTC
from pathlib import Path

from jarvis_core.shared.io import jarvis_home, read_json, write_json, slugify, ensure_dir


def _config_path() -> Path:
    return jarvis_home() / 'configs' / 'opensquad.json'


def load_opensquad_config() -> dict:
    return read_json(_config_path(), {
        'enabled': True,
        'mode': 'advisory',
        'roles': ['architect', 'diagnostician', 'patch-planner', 'validator'],
        'mission_handoff': True,
    })


def build_squad_plan(mission_text: str, intent: str, project_root: str | None = None) -> dict:
    config = load_opensquad_config()
    squad_id = f"squad_{slugify(intent)}_{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}"
    steps = [
        {'role': 'architect', 'task': 'translate mission into executable plan'},
        {'role': 'diagnostician', 'task': 'gather evidence and classify probable root cause'},
        {'role': 'patch-planner', 'task': 'propose safest patch/recovery sequence'},
        {'role': 'validator', 'task': 'define gates and GOLD criteria for this mission'},
    ]
    return {
        'enabled': config.get('enabled', False),
        'mode': config.get('mode', 'advisory'),
        'squad_id': squad_id,
        'mission': mission_text,
        'intent': intent,
        'project_root': project_root,
        'steps': steps,
        'created_at': datetime.now(UTC).isoformat(),
    }


def persist_squad_plan(plan: dict) -> dict:
    base = ensure_dir(jarvis_home() / 'data' / 'opensquad' / 'plans')
    path = base / f"{plan['squad_id']}.json"
    write_json(path, plan)
    return {'path': str(path), 'plan': plan}
