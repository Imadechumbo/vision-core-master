
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any


def jarvis_home() -> Path:
    return Path(os.environ.get("JARVIS_HOME", Path.cwd())).resolve()


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, data: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def copy_file(src: Path, dst: Path) -> None:
    ensure_dir(dst.parent)
    shutil.copy2(src, dst)


def safe_relpath(path: Path, start: Path) -> str:
    try:
        return path.resolve().relative_to(start.resolve()).as_posix()
    except Exception:
        return path.name


def slugify(value: str) -> str:
    allowed = []
    for ch in value.lower():
        if ch.isalnum():
            allowed.append(ch)
        elif ch in {' ', '-', '_'}:
            allowed.append('-')
    text = ''.join(allowed).strip('-')
    while '--' in text:
        text = text.replace('--', '-')
    return text or 'item'
