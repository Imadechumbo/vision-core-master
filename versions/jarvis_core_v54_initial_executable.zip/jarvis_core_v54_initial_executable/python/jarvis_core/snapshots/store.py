
from __future__ import annotations

from datetime import datetime, UTC
from pathlib import Path

from jarvis_core.shared.io import jarvis_home, read_json, write_json, copy_file, ensure_dir, safe_relpath
from jarvis_core.state.store import update_state

TRACKED_FILES = ['server.js', 'app.js', 'package.json', 'Procfile', 'Dockerfile', '.jarvis.runtime.env']


def _path():
    return jarvis_home() / 'data' / 'snapshots' / 'snapshots.json'


def _snapshot_dir(snapshot_id: str) -> Path:
    return jarvis_home() / 'data' / 'snapshots' / snapshot_id


def list_snapshots() -> dict:
    return read_json(_path(), {'snapshots': [], 'current_snapshot_id': None})


def _discover_files(project_root: Path) -> list[Path]:
    files = []
    for rel in TRACKED_FILES:
        candidate = project_root / rel
        if candidate.exists() and candidate.is_file():
            files.append(candidate)
    for sub in ['.ebextensions']:
        candidate = project_root / sub
        if candidate.exists() and candidate.is_dir():
            for p in candidate.rglob('*'):
                if p.is_file():
                    files.append(p)
    return files


def create_snapshot(project_root: str, status: str = 'gold') -> dict:
    root = Path(project_root).resolve()
    data = list_snapshots()
    snapshot_id = 'snapshot_' + datetime.now(UTC).strftime('%Y%m%d%H%M%S')
    snapshot_dir = _snapshot_dir(snapshot_id)
    files_meta = []
    for src in _discover_files(root):
        rel = safe_relpath(src, root)
        dst = snapshot_dir / 'files' / rel
        copy_file(src, dst)
        files_meta.append({'source': rel, 'snapshot': str(dst)})
    item = {
        'id': snapshot_id,
        'status': status,
        'created_at': datetime.now(UTC).isoformat(),
        'project_root': str(root),
        'files': files_meta,
    }
    write_json(snapshot_dir / 'snapshot.json', item)
    data.setdefault('snapshots', []).append(item)
    data['current_snapshot_id'] = snapshot_id
    write_json(_path(), data)
    update_state(status, project_root=str(root), current_snapshot_id=snapshot_id)
    return item


def rollback_snapshot(snapshot_id: str) -> dict:
    data = list_snapshots()
    for item in data.get('snapshots', []):
        if item['id'] != snapshot_id:
            continue
        root = Path(item['project_root']).resolve()
        restored = []
        for file_meta in item.get('files', []):
            src = Path(file_meta['snapshot'])
            dst = root / file_meta['source']
            if src.exists():
                copy_file(src, dst)
                restored.append(str(dst))
        data['current_snapshot_id'] = snapshot_id
        data['restored_at'] = datetime.now(UTC).isoformat()
        write_json(_path(), data)
        update_state('recovered', project_root=str(root), current_snapshot_id=snapshot_id)
        return {'snapshot_id': snapshot_id, 'restored': True, 'snapshot': item, 'restored_files': restored}
    return {'snapshot_id': snapshot_id, 'restored': False, 'message': 'snapshot not found'}
