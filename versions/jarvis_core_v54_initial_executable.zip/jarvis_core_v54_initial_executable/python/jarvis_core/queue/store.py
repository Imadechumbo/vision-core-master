
from __future__ import annotations

from datetime import datetime, UTC
import time

from jarvis_core.shared.io import jarvis_home, read_json, write_json
from jarvis_core.state.store import update_state


def _path():
    return jarvis_home() / 'data' / 'queue' / 'jobs.json'


def list_jobs() -> dict:
    return read_json(_path(), {'jobs': []})


def _save(data: dict) -> None:
    write_json(_path(), data)


def queue_job(name: str, payload: dict) -> dict:
    data = list_jobs()
    item = {
        'id': 'job_' + datetime.now(UTC).strftime('%Y%m%d%H%M%S'),
        'name': name,
        'payload': payload,
        'status': 'queued',
        'attempts': 0,
        'max_attempts': payload.get('max_attempts', 3),
        'created_at': datetime.now(UTC).isoformat(),
        'updated_at': datetime.now(UTC).isoformat(),
    }
    data.setdefault('jobs', []).append(item)
    _save(data)
    return item


def dequeue_job() -> dict | None:
    data = list_jobs()
    now = datetime.now(UTC).isoformat()
    for item in data.get('jobs', []):
        if item.get('status') in {'queued', 'retry_wait'}:
            item['status'] = 'running'
            item['attempts'] = int(item.get('attempts', 0)) + 1
            item['updated_at'] = now
            _save(data)
            return item
    return None


def complete_job(job_id: str, result: dict) -> dict:
    data = list_jobs()
    for item in data.get('jobs', []):
        if item['id'] == job_id:
            item['status'] = 'completed'
            item['result'] = result
            item['updated_at'] = datetime.now(UTC).isoformat()
            _save(data)
            return item
    return {'id': job_id, 'status': 'missing'}


def fail_job(job_id: str, error: str) -> dict:
    data = list_jobs()
    for item in data.get('jobs', []):
        if item['id'] == job_id:
            item['status'] = 'failed'
            item['error'] = error
            item['updated_at'] = datetime.now(UTC).isoformat()
            _save(data)
            return item
    return {'id': job_id, 'status': 'missing'}


def retry_job(job_id: str, error: str) -> dict:
    data = list_jobs()
    for item in data.get('jobs', []):
        if item['id'] == job_id:
            if int(item.get('attempts', 0)) >= int(item.get('max_attempts', 3)):
                item['status'] = 'dead_letter'
            else:
                item['status'] = 'retry_wait'
                item['next_retry_at'] = datetime.now(UTC).isoformat()
            item['error'] = error
            item['updated_at'] = datetime.now(UTC).isoformat()
            _save(data)
            return item
    return {'id': job_id, 'status': 'missing'}


def run_job(job: dict) -> dict:
    name = job.get('name', '')
    payload = job.get('payload', {})
    if name == 'scan':
        from jarvis_core.projects.scanner import scan_project
        return scan_project(payload.get('project_root'))
    if name == 'gates':
        from jarvis_core.gates.engine import run_http_gates
        return run_http_gates(payload['base_url'], profile=payload.get('profile', 'default'))
    if name == 'pipeline':
        from jarvis_core.pipeline import run_pipeline
        return run_pipeline(project_root=payload.get('project_root'), profile=payload.get('profile', 'default'), host=payload.get('host', '127.0.0.1'), port=int(payload.get('port', 8088)), skip_start=bool(payload.get('skip_start', False)), mission=payload.get('mission'))
    if name == 'mission':
        from jarvis_core.missions.engine import accept_mission
        return accept_mission(payload['text'], project_root=payload.get('project_root'))
    return {'ok': True, 'message': f'no-op handler for {name}', 'payload': payload}


def worker_run_once() -> dict:
    job = dequeue_job()
    if not job:
        return {'processed': False, 'message': 'no queued jobs'}
    update_state('worker_running', active_jobs=[job['id']])
    try:
        result = run_job(job)
        complete = complete_job(job['id'], result)
        update_state('idle', active_jobs=[])
        return {'processed': True, 'job': complete, 'result': result}
    except Exception as exc:
        retried = retry_job(job['id'], str(exc))
        update_state('warning', active_jobs=[])
        return {'processed': True, 'job': retried, 'error': str(exc)}


def worker_loop(poll_seconds: int = 5, max_cycles: int | None = None) -> dict:
    cycles = 0
    processed = 0
    while True:
        result = worker_run_once()
        if result.get('processed'):
            processed += 1
        cycles += 1
        if max_cycles is not None and cycles >= max_cycles:
            return {'cycles': cycles, 'processed': processed}
        time.sleep(poll_seconds)
