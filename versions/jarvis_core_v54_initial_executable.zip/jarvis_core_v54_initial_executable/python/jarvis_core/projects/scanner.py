from __future__ import annotations

import json
from pathlib import Path

from .root import detect_project_root


def _safe_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def scan_project(project_root: str | None = None) -> dict:
    root = Path(detect_project_root(project_root))
    files = {p.name for p in root.iterdir()} if root.exists() else set()
    package_json = _safe_json(root / "package.json") if (root / "package.json").exists() else {}
    requirements_exists = (root / "requirements.txt").exists()
    pyproject_exists = (root / "pyproject.toml").exists()
    src_exists = (root / "src").exists()
    deps = {**package_json.get("dependencies", {}), **package_json.get("devDependencies", {})}

    node_project = "package.json" in files
    python_project = requirements_exists or pyproject_exists
    has_routes = src_exists or any(name in files for name in ["routes", "app.js", "server.js", "main.py"])
    has_api = has_routes or any(k.lower() in {"express", "fastapi", "flask"} for k in deps)

    stack = []
    if node_project:
        stack.append("node")
    if python_project:
        stack.append("python")
    if (root / "Dockerfile").exists():
        stack.append("docker")
    if (root / "index.html").exists():
        stack.append("static")

    if node_project and has_api:
        project_type = "node_api"
    elif python_project and has_api:
        project_type = "python_api"
    elif (root / "index.html").exists():
        project_type = "static_site"
    else:
        project_type = "generic"

    entry_files = [name for name in ["server.js", "app.js", "main.py", "manage.py", "index.html"] if name in files]

    return {
        "root_exists": root.exists(),
        "root": str(root),
        "project_type": project_type,
        "stack": stack,
        "node_project": node_project,
        "python_project": python_project,
        "has_routes": has_routes,
        "has_api": has_api,
        "sample_files": sorted(list(files))[:25],
        "entry_files": entry_files,
        "has_procfile": (root / "Procfile").exists(),
        "has_dockerfile": (root / "Dockerfile").exists(),
        "has_ebextensions": (root / ".ebextensions").exists(),
        "npm_scripts": package_json.get("scripts", {}),
    }
