from __future__ import annotations

import json
from pathlib import Path


def _read_package_json(root: Path) -> dict:
    try:
        return json.loads((root / "package.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def detect(project: dict) -> bool:
    return project.get("project_type") == "node_api" or project.get("node_project")


def suggest_start_command(project_root: str) -> str | None:
    root = Path(project_root)
    pkg = _read_package_json(root)
    scripts = pkg.get("scripts", {})
    if scripts.get("start"):
        return "npm start"
    for name in ["server.js", "app.js"]:
        if (root / name).exists():
            return f"node {name}"
    if (root / "src" / "server.js").exists():
        return "node src/server.js"
    return None


def build_gate_profile(project_root: str, requested: str = "default") -> str:
    root = Path(project_root)
    if requested != "default":
        return requested
    if (root / "package.json").exists() and ((root / ".ebextensions").exists() or (root / "Procfile").exists()):
        return "technetgame"
    return "default"
