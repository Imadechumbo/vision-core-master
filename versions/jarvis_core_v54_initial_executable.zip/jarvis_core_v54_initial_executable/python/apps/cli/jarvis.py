
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from jarvis_core.bootstrap.engine import bootstrap_environment
from jarvis_core.gates.engine import run_http_gates
from jarvis_core.incidents.store import record_incident
from jarvis_core.missions.engine import accept_mission
from jarvis_core.pipeline import run_pipeline
from jarvis_core.projects.scanner import scan_project
from jarvis_core.queue.store import queue_job, list_jobs, worker_run_once, worker_loop
from jarvis_core.scheduler.engine import schedule_jobs, run_due_jobs_once, scheduler_loop
from jarvis_core.snapshots.store import rollback_snapshot, list_snapshots, create_snapshot
from jarvis_core.patches.store import create_patch_record, rollback_patch, list_patches, apply_text_patch
from jarvis_core.patches.planner import generate_patch_plan
from jarvis_core.state.store import load_state
from jarvis_core.opensquad.bridge import load_opensquad_config


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog='jarvis', description='JARVIS CORE V5.4 hybrid initial executable')
    sub = parser.add_subparsers(dest='subcommand', required=True)

    scan = sub.add_parser('scan', help='scan project structure')
    scan.add_argument('--project-root', default='')

    bootstrap = sub.add_parser('bootstrap', help='prepare runtime environment')
    bootstrap.add_argument('--project-root', default='')
    bootstrap.add_argument('--host', default='127.0.0.1')
    bootstrap.add_argument('--port', type=int, default=8088)

    gates = sub.add_parser('gates', help='run HTTP gates')
    gates.add_argument('--base-url', required=True)
    gates.add_argument('--profile', default='default')

    run = sub.add_parser('run', help='full pipeline')
    run.add_argument('--project-root', default='')
    run.add_argument('--host', default='127.0.0.1')
    run.add_argument('--port', type=int, default=8088)
    run.add_argument('--profile', default='default')
    run.add_argument('--start-command', default='')
    run.add_argument('--skip-start', action='store_true')
    run.add_argument('--mission', default='')

    mission = sub.add_parser('mission', help='accept mission in natural language')
    mission.add_argument('text')
    mission.add_argument('--project-root', default='')

    incident = sub.add_parser('incident', help='record incident manually')
    incident.add_argument('--project-root', default='')
    incident.add_argument('--category', required=True)
    incident.add_argument('--failure-type', required=True)
    incident.add_argument('--summary', required=True)
    incident.add_argument('--evidence', nargs='*', default=[])

    recover = sub.add_parser('rollback-snapshot', help='rollback to snapshot')
    recover.add_argument('--snapshot-id', required=True)

    rbp = sub.add_parser('rollback-patch', help='rollback one patch record')
    rbp.add_argument('--patch-id', required=True)

    patch = sub.add_parser('patch-record', help='create patch record for manual patch tracking')
    patch.add_argument('--project-root', required=True)
    patch.add_argument('--summary', required=True)
    patch.add_argument('--files', nargs='*', default=[])

    text_patch = sub.add_parser('apply-text-patch', help='apply text patch with real backup + rollback support')
    text_patch.add_argument('--project-root', required=True)
    text_patch.add_argument('--file', required=True)
    text_patch.add_argument('--search', required=True)
    text_patch.add_argument('--replace', required=True)
    text_patch.add_argument('--summary', default='text patch')

    plan = sub.add_parser('patch-plan', help='generate supervised patch plan from failure type')
    plan.add_argument('--project-root', required=True)
    plan.add_argument('--failure-type', required=True)

    snapshot = sub.add_parser('snapshot-create', help='create real snapshot of tracked files')
    snapshot.add_argument('--project-root', required=True)
    snapshot.add_argument('--status', default='gold')

    sched = sub.add_parser('schedule', help='schedule recurring job')
    sched.add_argument('--name', required=True)
    sched.add_argument('--every-seconds', type=int, required=True)
    sched.add_argument('--command', required=True)
    sched.add_argument('--payload', default='{}')

    sub.add_parser('scheduler-run-once', help='run due jobs once')
    sched_loop = sub.add_parser('scheduler-loop', help='run continuous scheduler loop')
    sched_loop.add_argument('--tick-seconds', type=int, default=10)
    sched_loop.add_argument('--max-cycles', type=int, default=0)
    sched_loop.add_argument('--no-worker', action='store_true')

    queue = sub.add_parser('queue', help='queue one job')
    queue.add_argument('--name', required=True)
    queue.add_argument('--payload', default='{}')

    sub.add_parser('queue-list', help='list queued jobs')
    sub.add_parser('worker-run-once', help='process one queued job')
    worker_loop_parser = sub.add_parser('worker-loop', help='run worker loop')
    worker_loop_parser.add_argument('--poll-seconds', type=int, default=5)
    worker_loop_parser.add_argument('--max-cycles', type=int, default=0)

    sub.add_parser('state', help='show persisted state')
    sub.add_parser('snapshots', help='list snapshots')
    sub.add_parser('patches', help='list patches')
    sub.add_parser('opensquad-config', help='show OpenSquad bridge config')

    return parser


def _json_or_raw(value: str) -> dict:
    try:
        return json.loads(value)
    except Exception:
        return {'raw': value}


def main() -> int:
    args = build_parser().parse_args()

    if args.subcommand == 'scan':
        result = scan_project(args.project_root or None)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'bootstrap':
        result = bootstrap_environment(project_root=args.project_root or None, host=args.host, port=args.port)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'gates':
        result = run_http_gates(base_url=args.base_url, profile=args.profile)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0 if result.get('pass_gold') else 2
    if args.subcommand == 'run':
        result = run_pipeline(project_root=args.project_root or None, host=args.host, port=args.port, profile=args.profile, start_command=args.start_command or None, skip_start=args.skip_start, mission=args.mission or None)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0 if result.get('pass_gold') else 2
    if args.subcommand == 'mission':
        result = accept_mission(args.text, project_root=args.project_root or None)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'incident':
        incident = record_incident(project_root=args.project_root or os.getcwd(), category=args.category, failure_type=args.failure_type, summary=args.summary, evidence=args.evidence)
        print(json.dumps(incident, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'rollback-snapshot':
        result = rollback_snapshot(args.snapshot_id)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0 if result.get('restored') else 2
    if args.subcommand == 'rollback-patch':
        result = rollback_patch(args.patch_id)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0 if result.get('rolled_back') else 2
    if args.subcommand == 'patch-record':
        result = create_patch_record(args.project_root, args.summary, args.files)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'apply-text-patch':
        result = apply_text_patch(args.project_root, args.file, args.search, args.replace, args.summary)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0 if result.get('applied') else 2
    if args.subcommand == 'patch-plan':
        result = generate_patch_plan(args.project_root, {'failure_type': args.failure_type})
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'snapshot-create':
        result = create_snapshot(args.project_root, status=args.status)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'schedule':
        result = schedule_jobs(args.name, args.every_seconds, args.command, payload=_json_or_raw(args.payload))
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'scheduler-run-once':
        result = run_due_jobs_once()
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'scheduler-loop':
        result = scheduler_loop(tick_seconds=args.tick_seconds, max_cycles=(args.max_cycles or None), run_worker=not args.no_worker)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'queue':
        result = queue_job(args.name, _json_or_raw(args.payload))
        print(json.dumps(result, indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'queue-list':
        print(json.dumps(list_jobs(), indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'worker-run-once':
        print(json.dumps(worker_run_once(), indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'worker-loop':
        print(json.dumps(worker_loop(poll_seconds=args.poll_seconds, max_cycles=(args.max_cycles or None)), indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'state':
        print(json.dumps(load_state(), indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'snapshots':
        print(json.dumps(list_snapshots(), indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'patches':
        print(json.dumps(list_patches(), indent=2, ensure_ascii=False)); return 0
    if args.subcommand == 'opensquad-config':
        print(json.dumps(load_opensquad_config(), indent=2, ensure_ascii=False)); return 0
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
