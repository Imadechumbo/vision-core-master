"""Comandos CLI pra gerenciar projetos."""
from __future__ import annotations

import json

from jarvis_core.projects import registry


def cmd_list(args) -> str:
    return json.dumps(registry.list_projects(), indent=2, ensure_ascii=False)


def cmd_show(args) -> str:
    proj = registry.get_project(args.id)
    if not proj:
        return json.dumps({"error": f"projeto '{args.id}' não encontrado"})
    return json.dumps(proj, indent=2, ensure_ascii=False)


def cmd_add(args) -> str:
    proj = registry.register_project(
        project_id=args.id,
        display_name=args.name,
        adapter=args.adapter,
        base_url=args.base_url or "",
        project_root=args.project_root or "",
        critical=not args.not_critical,
        auto_apply_enabled=args.auto_apply,
        metadata=json.loads(args.metadata) if args.metadata else {},
    )
    return json.dumps(proj, indent=2, ensure_ascii=False)


def cmd_update(args) -> str:
    updates: dict = {}
    if args.name is not None:         updates["display_name"] = args.name
    if args.adapter is not None:      updates["adapter"] = args.adapter
    if args.base_url is not None:     updates["base_url"] = args.base_url
    if args.project_root is not None: updates["project_root"] = args.project_root
    if args.critical is not None:     updates["critical"] = (args.critical == "true")
    if args.auto_apply is not None:   updates["auto_apply_enabled"] = (args.auto_apply == "true")
    if args.metadata:                 updates["metadata"] = json.loads(args.metadata)
    proj = registry.update_project(args.id, **updates)
    return json.dumps(proj, indent=2, ensure_ascii=False)


def cmd_delete(args) -> str:
    ok = registry.delete_project(args.id)
    return json.dumps({"deleted": ok, "id": args.id})


def cmd_seed(args) -> str:
    registry.ensure_default_projects()
    return json.dumps({"ok": True, "message": "defaults garantidos (technetgame)"},
                      ensure_ascii=False, indent=2)
