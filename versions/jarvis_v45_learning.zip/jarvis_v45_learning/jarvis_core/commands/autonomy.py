"""
CLI de autonomia — permite testar a decisão sem rodar missão inteira.

Uso típico:
  jarvis autonomy check --project technetgame --strategy vision_mimetype_guard_v1 \\
         --risk 15 --root-cause missing_input_validation
"""
from __future__ import annotations

import json
from dataclasses import dataclass

from jarvis_core.autonomy import decision
from jarvis_core.projects.context import ProjectContext
from jarvis_core.models import PatchOperation, StructuredPatch


@dataclass
class _FakeMission:
    intent: str
    risk_profile: str = "medium"


def cmd_check(args) -> str:
    ctx = ProjectContext.load(args.project)

    # Monta patch fake com o strategy_id informado
    patch = StructuredPatch(
        risk_level="low",
        summary=f"check for {args.strategy}",
        operations=[PatchOperation(
            file="x.txt", op_type="insert", target="X",
            content="", reason="",
            strategy_id=args.strategy,
        )],
    )
    policy = {
        "risk_final": args.risk,
        "blocked": False,
        "allowed": True,
    }
    result = decision.decide(ctx, policy, patch, args.root_cause)
    return json.dumps(result, indent=2, ensure_ascii=False)
