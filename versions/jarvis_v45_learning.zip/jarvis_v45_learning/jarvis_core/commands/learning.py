"""Comandos CLI pro learning layer."""
from __future__ import annotations

import json

from jarvis_core.learning import strategy_scorer


def cmd_record(args) -> str:
    strategy_scorer.record_outcome(
        mission_id=args.mission_id,
        project_id=args.project,
        strategy_id=args.strategy,
        root_cause=args.root_cause,
        outcome=args.outcome,
        risk_score=args.risk_score or 0,
        auto_applied=args.auto_applied,
    )
    return json.dumps({"ok": True, "recorded": {
        "mission_id": args.mission_id,
        "strategy_id": args.strategy,
        "outcome": args.outcome,
    }}, indent=2, ensure_ascii=False)


def cmd_score(args) -> str:
    return json.dumps(
        strategy_scorer.score_strategy(args.strategy, args.project),
        indent=2, ensure_ascii=False,
    )


def cmd_rank(args) -> str:
    candidates = args.candidates.split(",") if args.candidates else None
    return json.dumps(
        strategy_scorer.rank_strategies_for(args.root_cause, args.project, candidates),
        indent=2, ensure_ascii=False,
    )


def cmd_stats(args) -> str:
    return json.dumps(strategy_scorer.learning_stats(), indent=2, ensure_ascii=False)
