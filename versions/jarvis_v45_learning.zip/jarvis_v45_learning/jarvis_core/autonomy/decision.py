"""
Autonomy Decision Engine — decide se auto-apply é permitido.

Regras HARD (nenhuma pode falhar):
  1. Projeto tem auto_apply_enabled = True
  2. Projeto NÃO está marcado como critical
  3. Risk score ≤ MAX_AUTO_RISK
  4. Strategy tem veredito 'proven' (success_rate ≥ 0.8, n ≥ 3)
  5. Strategy NÃO está blocklisted
  6. Política Aegis não bloqueou

Qualquer falha → requires_approval.
"""
from __future__ import annotations

from typing import Any

from jarvis_core.learning import strategy_scorer


MAX_AUTO_RISK = 25              # risk_score máximo pra auto-apply
MIN_SUCCESS_RATE = 0.80
MIN_HISTORY_N = 3


def decide(
    ctx,                         # ProjectContext
    policy: dict,                # saída do evaluate_policy
    patch,                       # StructuredPatch
    root_cause: str,
) -> dict[str, Any]:
    reasons: list[str] = []

    # 1. flag do projeto
    if not ctx.auto_apply_enabled:
        reasons.append("auto_apply_disabled_for_project")

    # 2. criticality
    if ctx.critical:
        reasons.append("project_marked_critical")

    # 3. risk score numérico
    risk = int(policy.get("risk_final", policy.get("risk_score", 100)))
    if risk > MAX_AUTO_RISK:
        reasons.append(f"risk_above_threshold:{risk}>{MAX_AUTO_RISK}")

    # 4. política
    if policy.get("blocked") or policy.get("allowed") is False:
        reasons.append("aegis_blocked")

    # 5. strategy proven?
    strategy_ids = [op.strategy_id for op in patch.operations if op.strategy_id]
    strategy_scores: list[dict] = []
    for sid in strategy_ids:
        s = strategy_scorer.score_strategy(sid, ctx.project_id)
        strategy_scores.append(s)
        if s["verdict"] != "proven":
            reasons.append(f"strategy_not_proven:{sid}:{s['verdict']}(n={s['n']})")
        elif (s["success_rate"] or 0) < MIN_SUCCESS_RATE:
            reasons.append(f"success_rate_low:{sid}:{s['success_rate']}")
        # 6. blocklist
        blocked, blockreason = strategy_scorer.is_blocklisted(sid, ctx.project_id)
        if blocked:
            reasons.append(f"strategy_blocklisted:{sid}:{blockreason}")

    approved = len(reasons) == 0

    return {
        "auto_apply_approved": approved,
        "reasons": reasons,
        "thresholds": {
            "max_risk": MAX_AUTO_RISK,
            "min_success_rate": MIN_SUCCESS_RATE,
            "min_history_n": MIN_HISTORY_N,
        },
        "strategy_scores": strategy_scores,
        "risk_final": risk,
    }
