"""
RCA V5 — classificação de causa raiz.

Duas partes:

1. DETERMINÍSTICO (confiável, usado em produção):
   Taxonomia formal + regras + confidence explicável.

2. ADAPTATIVO HOOK (experimental, opt-in):
   Chama `experimental.adaptive_rca` se habilitado no ambiente.
   Retorna apenas HINTS, nunca sobrescreve a classificação determinística.
   Ver `experimental/README.md` pra honestidade sobre o que "adaptativo"
   significa de verdade (SPOILER: não é ML real).
"""
from __future__ import annotations

import os
from typing import Any

from jarvis_core.models import RCAResult
from jarvis_core.taxonomy import TAXONOMY, CAUSAL_LINKS, assert_valid


def _cause(rc: str, confidence: float, narrative: str) -> dict:
    return {"root_cause": assert_valid(rc),
            "confidence": round(confidence, 2),
            "narrative": narrative}


def _deterministic_rca(mission, evidence: dict) -> list[dict]:
    signals = set(evidence.get("signals", []))
    intent = mission.intent
    causes: list[dict] = []

    if intent == "fix_vision":
        if "vision_route_missing" in signals:
            causes.append(_cause("vision_route_missing", 0.95,
                "Rota de vision não foi encontrada no fonte."))
        else:
            causes.append(_cause("missing_input_validation", 0.78,
                "Rota existe mas handler provavelmente não valida arquivo/mimetype."))
            causes.append(_cause("provider_not_configured", 0.64,
                "Env vars do provider vision podem estar ausentes ou inválidas."))
            causes.append(_cause("rate_limit_upstream", 0.45,
                "Modelo free pode estar rate-limited."))

    elif intent == "fix_zip_ingest":
        if "zip_route_missing" in signals:
            causes.append(_cause("zip_route_missing", 0.97,
                "Rota /project-zip ausente no roteamento."))
        else:
            causes.append(_cause("zip_security_block", 0.55,
                "Rota existe; provavelmente limites de tamanho/mime estão bloqueando."))

    elif intent == "fix_cors":
        causes.append(_cause("cors_misconfiguration", 0.8,
            "Allowlist de origens provavelmente incompleta ou preflight mal configurado."))

    elif intent == "fix_auth":
        causes.append(_cause("auth_token_invalid", 0.75,
            "JWT pode estar com secret errado ou expiry muito curto."))

    elif intent == "fix_deploy":
        causes.append(_cause("deploy_artifact_mismatch", 0.65,
            "Artifact atual pode divergir do stable version label."))
        causes.append(_cause("runtime_config_mismatch", 0.55,
            "Env vars do ambiente EB podem não bater com o esperado."))

    elif intent == "rollback":
        causes.append(_cause("deploy_artifact_mismatch", 0.6,
            "Rollback requerido para stable version label conhecido."))

    else:
        causes.append(_cause("unknown_general_issue", 0.35,
            "Missão genérica sem classificação automática confiável."))

    causes.sort(key=lambda c: c["confidence"], reverse=True)
    return causes


def build_rca(mission, evidence: dict) -> RCAResult:
    causes = _deterministic_rca(mission, evidence)
    primary = causes[0]

    # Cause chain = encadeamento
    chain = [c["root_cause"] for c in causes]
    underlying = []
    seen = set(chain)
    for rc in chain:
        parent = CAUSAL_LINKS.get(rc)
        if parent and parent not in seen:
            underlying.append(parent)
            seen.add(parent)

    # Hook adaptativo (experimental, opt-in via env JARVIS_EXPERIMENTAL_RCA=1)
    # Se o pacote experimental existir no sistema, chama; senão, ignora.
    experimental_hints: list[dict] = []
    if os.getenv("JARVIS_EXPERIMENTAL_RCA") == "1":
        try:
            from jarvis_core.experimental import adaptive_rca  # type: ignore
            experimental_hints = adaptive_rca.suggest_hints(mission, evidence)
        except ImportError:
            experimental_hints = [{"status": "experimental_module_not_installed"}]
        except Exception as e:
            experimental_hints = [{"error": f"experimental_rca_failed:{e}"}]

    return RCAResult(
        root_cause=primary["root_cause"],
        root_cause_narrative=primary["narrative"],
        cause_chain=chain,
        underlying=underlying,
        confidence=primary["confidence"],
        evidence=[
            {"signals": list(evidence.get("signals", []))},
            {"all_causes": causes},
            {"experimental_hints": experimental_hints},
        ],
    )
