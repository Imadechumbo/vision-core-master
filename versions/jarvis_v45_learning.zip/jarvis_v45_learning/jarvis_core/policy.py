"""
Aegis Policy V5 — risk scoring numérico 0-100.
Regras determinísticas + allowlist de op types.
"""
from __future__ import annotations

HIGH_RISK_OPS = {"delete_file", "deploy_prod", "rollback_prod", "modify_secrets"}
AUTO_APPROVED_OPS = {"insert", "replace", "delete"}
RISK_PROFILE_WEIGHT = {"low": 0, "medium": 10, "high": 25, "critical": 50}
HARD_BLOCK_AT = 80


def evaluate_policy(mission, patch, apply: bool) -> dict:
    reasons: list[str] = []
    blocked = False

    # Op allowlist
    for op in patch.operations:
        if op.op_type in HIGH_RISK_OPS:
            blocked = True
            reasons.append(f"blocked_op:{op.op_type}")
        elif op.op_type not in AUTO_APPROVED_OPS:
            reasons.append(f"unknown_op:{op.op_type}")

    # Path allowlist heurística: arquivos críticos
    sensitive_tokens = ["auth", "billing", "payment", ".env", "secret"]
    for op in patch.operations:
        low = op.file.lower()
        for tok in sensitive_tokens:
            if tok in low:
                blocked = True
                reasons.append(f"sensitive_file:{op.file}")
                break

    # Risk final numérico
    base = {"low": 10, "medium": 30, "high": 55}.get(patch.risk_level, 40)
    profile = RISK_PROFILE_WEIGHT.get(mission.risk_profile, 10)
    risk_final = min(100, base + profile)

    if risk_final >= HARD_BLOCK_AT:
        blocked = True
        reasons.append(f"risk_too_high:{risk_final}")

    decision = "BLOCK" if (apply and blocked) else (
        "ALLOW_WITH_SUPERVISION" if apply else "ALLOW_DRY_RUN"
    )

    return {
        "decision": decision,
        "blocked": blocked,
        "allowed": not blocked,
        "reasons": reasons,
        "risk_final": risk_final,
        "risk_level_plan": patch.risk_level,
        "risk_profile_mission": mission.risk_profile,
        "risky_touched_files": [op.file for op in patch.operations],
    }
