"""Config V5 — paths globais e por-projeto."""
from __future__ import annotations

import os

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_DIR = os.path.join(ROOT_DIR, "data")
PROJECTS_DIR = os.path.join(DATA_DIR, "projects")
GLOBAL_REGISTRY_DB = os.path.join(DATA_DIR, "projects.sqlite")
GLOBAL_LEARNING_DB = os.path.join(DATA_DIR, "learning.sqlite")
PATCHES_DIR_NAME = "patches"
INCIDENTS_DB_NAME = "incidents.sqlite"
STABLE_DIR_NAME = "stable"
OBSIDIAN_DIR_NAME = "obsidian"

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PROJECTS_DIR, exist_ok=True)


def project_data_dir(project_id: str) -> str:
    d = os.path.join(PROJECTS_DIR, project_id)
    os.makedirs(d, exist_ok=True)
    return d


def project_incidents_db(project_id: str) -> str:
    return os.path.join(project_data_dir(project_id), INCIDENTS_DB_NAME)


def project_stable_dir(project_id: str) -> str:
    d = os.path.join(project_data_dir(project_id), STABLE_DIR_NAME)
    os.makedirs(d, exist_ok=True)
    os.makedirs(os.path.join(d, "history"), exist_ok=True)
    return d


def project_patches_dir(project_id: str) -> str:
    d = os.path.join(project_data_dir(project_id), PATCHES_DIR_NAME)
    os.makedirs(d, exist_ok=True)
    return d


def project_obsidian_dir(project_id: str) -> str:
    d = os.path.join(project_data_dir(project_id), OBSIDIAN_DIR_NAME)
    os.makedirs(d, exist_ok=True)
    return d
