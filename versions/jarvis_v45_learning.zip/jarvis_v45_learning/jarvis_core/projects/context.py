"""
ProjectContext — agrega tudo que é por-projeto num lugar só.

Uso:
    ctx = ProjectContext.load("technetgame")
    ctx.incidents.save(...)
    ctx.stable.promote_gold(...)
    ctx.patches_dir   # diretório onde salvar diffs
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from jarvis_core.config import (
    project_incidents_db,
    project_patches_dir,
    project_stable_dir,
    project_obsidian_dir,
)
from jarvis_core.projects.registry import get_project


@dataclass
class ProjectContext:
    project_id: str
    data: dict[str, Any]

    @classmethod
    def load(cls, project_id: str) -> "ProjectContext":
        data = get_project(project_id)
        if not data:
            raise LookupError(
                f"projeto '{project_id}' não existe no registry. "
                f"Registre com: jarvis.py projects add --id {project_id} ..."
            )
        return cls(project_id=project_id, data=data)

    # ---------- paths ----------
    @property
    def incidents_db(self) -> str:
        return project_incidents_db(self.project_id)

    @property
    def stable_dir(self) -> str:
        return project_stable_dir(self.project_id)

    @property
    def patches_dir(self) -> str:
        return project_patches_dir(self.project_id)

    @property
    def obsidian_dir(self) -> str:
        return project_obsidian_dir(self.project_id)

    # ---------- flags ----------
    @property
    def critical(self) -> bool:
        return bool(self.data.get("critical", True))

    @property
    def auto_apply_enabled(self) -> bool:
        return bool(self.data.get("auto_apply_enabled", False))

    @property
    def adapter_name(self) -> str:
        return self.data.get("adapter", "generic")

    @property
    def base_url(self) -> str:
        return self.data.get("base_url", "") or ""

    @property
    def project_root(self) -> str:
        return self.data.get("project_root", "") or ""
