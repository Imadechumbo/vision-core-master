"""
Projects Registry — multi-projeto de verdade.

Cada projeto tem:
  - id único
  - adapter (technetgame, generic, ...)
  - base_url pra gates HTTP
  - project_root no filesystem
  - flags: critical (impede auto-apply), auto_apply_enabled
  - data isolada em data/projects/<id>/
"""
from __future__ import annotations

import json
import sqlite3
from typing import Any

from jarvis_core.config import GLOBAL_REGISTRY_DB, project_data_dir
from jarvis_core.utils import utc_now_iso


_CREATE = """
CREATE TABLE IF NOT EXISTS projects (
    id                   TEXT PRIMARY KEY,
    display_name         TEXT NOT NULL,
    adapter              TEXT NOT NULL,
    base_url             TEXT DEFAULT '',
    project_root         TEXT DEFAULT '',
    critical             INTEGER DEFAULT 1,
    auto_apply_enabled   INTEGER DEFAULT 0,
    metadata_json        TEXT DEFAULT '{}',
    created_at           TEXT NOT NULL,
    updated_at           TEXT NOT NULL
)
"""


def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(GLOBAL_REGISTRY_DB)
    conn.execute(_CREATE)
    conn.commit()
    return conn


def _row_to_dict(row: tuple) -> dict[str, Any]:
    keys = ["id", "display_name", "adapter", "base_url", "project_root",
            "critical", "auto_apply_enabled", "metadata_json",
            "created_at", "updated_at"]
    d = dict(zip(keys, row))
    d["critical"] = bool(d["critical"])
    d["auto_apply_enabled"] = bool(d["auto_apply_enabled"])
    try:
        d["metadata"] = json.loads(d.pop("metadata_json") or "{}")
    except Exception:
        d["metadata"] = {}
    return d


def register_project(
    project_id: str,
    display_name: str,
    adapter: str = "generic",
    base_url: str = "",
    project_root: str = "",
    critical: bool = True,
    auto_apply_enabled: bool = False,
    metadata: dict | None = None,
) -> dict[str, Any]:
    now = utc_now_iso()
    conn = _db()
    try:
        conn.execute(
            """INSERT OR REPLACE INTO projects
               (id, display_name, adapter, base_url, project_root,
                critical, auto_apply_enabled, metadata_json,
                created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                project_id, display_name, adapter, base_url, project_root,
                1 if critical else 0,
                1 if auto_apply_enabled else 0,
                json.dumps(metadata or {}, ensure_ascii=False),
                now, now,
            ),
        )
        conn.commit()
    finally:
        conn.close()
    project_data_dir(project_id)  # garante pasta
    return get_project(project_id) or {}


def get_project(project_id: str) -> dict[str, Any] | None:
    conn = _db()
    try:
        row = conn.execute(
            "SELECT * FROM projects WHERE id = ?", (project_id,)
        ).fetchone()
        return _row_to_dict(row) if row else None
    finally:
        conn.close()


def list_projects() -> list[dict[str, Any]]:
    conn = _db()
    try:
        rows = conn.execute(
            "SELECT * FROM projects ORDER BY updated_at DESC"
        ).fetchall()
        return [_row_to_dict(r) for r in rows]
    finally:
        conn.close()


def update_project(project_id: str, **fields) -> dict[str, Any] | None:
    allowed = {"display_name", "adapter", "base_url", "project_root",
               "critical", "auto_apply_enabled", "metadata"}
    sets = []
    params: list[Any] = []
    for k, v in fields.items():
        if k not in allowed:
            continue
        if k == "metadata":
            sets.append("metadata_json = ?")
            params.append(json.dumps(v or {}, ensure_ascii=False))
        elif k in ("critical", "auto_apply_enabled"):
            sets.append(f"{k} = ?")
            params.append(1 if v else 0)
        else:
            sets.append(f"{k} = ?")
            params.append(v)
    if not sets:
        return get_project(project_id)
    sets.append("updated_at = ?")
    params.append(utc_now_iso())
    params.append(project_id)

    conn = _db()
    try:
        conn.execute(
            f"UPDATE projects SET {', '.join(sets)} WHERE id = ?",
            params,
        )
        conn.commit()
    finally:
        conn.close()
    return get_project(project_id)


def delete_project(project_id: str) -> bool:
    conn = _db()
    try:
        cur = conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def ensure_default_projects() -> None:
    """Garante que o technetgame existe no registry."""
    if not get_project("technetgame"):
        register_project(
            "technetgame",
            display_name="TechNetGame V2",
            adapter="technetgame",
            base_url="https://api.technetgame.com.br",
            critical=True,
            auto_apply_enabled=False,
            metadata={
                "deploy_env": "Technetgame-env-1",
                "stable_version_label": "v-46",
                "repo": "Imadechumbo/technetgamev2",
            },
        )
