"""Utils — I/O, tempo, slug, cópia filtrada."""
from __future__ import annotations

import datetime
import json
import os
import re
import shutil


IGNORE_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv",
               ".next", "dist", "build", ".pytest_cache", "data"}
IGNORE_FILES = {".DS_Store"}


def utc_now_iso() -> str:
    return datetime.datetime.utcnow().isoformat() + "Z"


def slugify(text: str, maxlen: int = 80) -> str:
    s = re.sub(r"[^a-zA-Z0-9_-]+", "-", text.strip())
    s = re.sub(r"-+", "-", s).strip("-").lower()
    return s[:maxlen] or "item"


def safe_read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()


def safe_write_text(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)


def write_json(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def read_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def copytree_filtered(src: str, dst: str) -> None:
    """Copia árvore pulando diretórios comuns pesados."""
    if os.path.exists(dst):
        shutil.rmtree(dst)
    def _ignore(_, names):
        return [n for n in names if n in IGNORE_DIRS or n in IGNORE_FILES]
    shutil.copytree(src, dst, ignore=_ignore)


def short_id(n: int = 8) -> str:
    import uuid
    return uuid.uuid4().hex[:n]
