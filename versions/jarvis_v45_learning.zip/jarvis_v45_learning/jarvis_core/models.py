"""Modelos de dados V5."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any


@dataclass
class Mission:
    raw: str
    normalized: str
    intent: str
    project_id: str = "generic"
    risk_profile: str = "medium"  # low|medium|high|critical

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class PatchOperation:
    file: str
    op_type: str            # insert|replace|delete
    target: str             # marker ou "__FULL_FILE__"
    content: str
    reason: str = ""
    strategy_id: str = ""   # usado pelo learning

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class StructuredPatch:
    operations: list[PatchOperation] = field(default_factory=list)
    risk_level: str = "medium"
    summary: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "operations": [op.to_dict() for op in self.operations],
            "risk_level": self.risk_level,
            "summary": self.summary,
        }


@dataclass
class RCAResult:
    root_cause: str                     # classe da TAXONOMY
    root_cause_narrative: str           # descrição humana
    cause_chain: list[str] = field(default_factory=list)
    underlying: list[str] = field(default_factory=list)
    confidence: float = 0.5
    evidence: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Outcome:
    """Resultado final de uma missão — alimenta o learning."""
    mission_id: str
    project_id: str
    intent: str
    root_cause: str
    strategy_ids: list[str]
    risk_score: int
    pass_gold: bool
    rolled_back: bool
    auto_applied: bool
    created_at: str = ""
