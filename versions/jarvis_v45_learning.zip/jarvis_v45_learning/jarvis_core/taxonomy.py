"""Taxonomia canônica (seção 12 do manual). Usada em todo classify/agregação."""
from __future__ import annotations

TAXONOMY: set[str] = {
    "missing_input_validation",
    "invalid_mimetype_handling",
    "invalid_api_key",
    "provider_not_configured",
    "vision_route_missing",
    "zip_route_missing",
    "zip_security_block",
    "cloudflare_waf_block",
    "runtime_config_mismatch",
    "deploy_artifact_mismatch",
    "repo_identity_mismatch",
    "adapter_resolution_failure",
    "cors_misconfiguration",
    "auth_token_invalid",
    "rate_limit_upstream",
    "unknown_general_issue",
}


def assert_valid(rc: str) -> str:
    if rc not in TAXONOMY:
        raise ValueError(f"root cause fora da taxonomia: {rc}")
    return rc


# Efeito → provável causa subjacente (pra cause chain)
CAUSAL_LINKS: dict[str, str] = {
    "missing_input_validation": "provider_not_configured",
    "invalid_api_key": "provider_not_configured",
    "invalid_mimetype_handling": "missing_input_validation",
    "deploy_artifact_mismatch": "runtime_config_mismatch",
    "rate_limit_upstream": "provider_not_configured",
}
