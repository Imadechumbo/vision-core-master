"""
Patch planner V5 — cada operation carrega `strategy_id`.
É por isso que o learning consegue agregar outcomes: toda vez que aplica
`vision_mimetype_guard_v1`, grava o outcome dessa strategy.
"""
from __future__ import annotations

from jarvis_core.models import PatchOperation, StructuredPatch


VISION_GUARD_SNIPPET = """// [JARVIS_V5_PATCH] Vision input guards
if (!req.file) {
  return res.status(400).json({
    ok: false, error: 'IMAGE_REQUIRED',
    message: 'Envie uma imagem no campo \"image\".'
  });
}
if (!req.file.mimetype || req.file.mimetype === 'null') {
  const path = require('path');
  const ext = path.extname(String(req.file.originalname || '').toLowerCase());
  const mimeMap = {'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg',
    '.webp':'image/webp','.gif':'image/gif','.bmp':'image/bmp'};
  req.file.mimetype = mimeMap[ext] || 'image/png';
}
if (!String(req.file.mimetype).startsWith('image/')) {
  return res.status(400).json({
    ok: false, error: 'INVALID_IMAGE_MIMETYPE',
    message: 'Arquivo enviado não é uma imagem válida.'
  });
}
// [JARVIS_V5_PATCH_END]
"""

CORS_SNIPPET = """// [JARVIS_V5_PATCH] CORS allowlist + preflight
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use((req, res, next) => {
  const origin = req.headers.origin || '';
  if (allowedOrigins.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Refresh-Token, Accept');
  res.setHeader('Access-Control-Max-Age', '86400');
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
});
// [JARVIS_V5_PATCH_END]
"""

ZIP_ROUTE_FILE = """const express = require('express');
const router = express.Router();
router.post('/api/v1/chat/project-zip', async (req, res) => {
  return res.json({ok: true, message: 'ZIP ingest criado pelo JARVIS V5.'});
});
module.exports = router;
"""


def plan_patch(mission, evidence: dict, rca_result) -> StructuredPatch:
    scan = evidence.get("scan", {})
    route_cands = scan.get("route_candidates", []) if scan.get("ok") else []
    root_cause = rca_result.root_cause
    patch = StructuredPatch(risk_level="medium",
                            summary=f"Plano para {mission.intent}")

    if root_cause == "missing_input_validation":
        target = next((f for f in route_cands if f.endswith("aiRoutes.js")),
                      route_cands[0] if route_cands else "src/routes/aiRoutes.js")
        patch.operations.append(PatchOperation(
            file=target, op_type="insert",
            target="VISION_HANDLER_GUARD",
            content=VISION_GUARD_SNIPPET,
            reason="Adicionar guardas de req.file e mimetype",
            strategy_id="vision_mimetype_guard_v1",
        ))
        patch.risk_level = "low"

    elif root_cause == "vision_route_missing":
        patch.operations.append(PatchOperation(
            file="src/routes/aiRoutes.js", op_type="insert",
            target="VISION_ROUTE",
            content="// TODO: registrar router.post('/api/v1/chat/vision', ...)",
            reason="Criar rota de vision",
            strategy_id="vision_route_create_v1",
        ))
        patch.risk_level = "medium"

    elif root_cause == "cors_misconfiguration":
        target = next((f for f in route_cands if f.endswith(("server.js","app.js","index.js"))),
                      "src/server.js")
        patch.operations.append(PatchOperation(
            file=target, op_type="insert",
            target="CORS_MIDDLEWARE",
            content=CORS_SNIPPET,
            reason="Middleware CORS com allowlist",
            strategy_id="cors_headers_consistent_v1",
        ))
        patch.risk_level = "low"

    elif root_cause == "zip_route_missing":
        patch.operations.append(PatchOperation(
            file="src/routes/projectIngestRoutes.js",
            op_type="replace", target="__FULL_FILE__",
            content=ZIP_ROUTE_FILE,
            reason="Criar rota project-zip placeholder",
            strategy_id="zip_route_create_v1",
        ))
        patch.risk_level = "medium"

    elif root_cause == "provider_not_configured":
        patch.operations.append(PatchOperation(
            file="JARVIS_CHECKLIST.md",
            op_type="replace", target="__FULL_FILE__",
            content=(
                "# Provider checklist\n\n"
                "Verifique no ambiente:\n"
                "- VISION_PROVIDER\n- VISION_API_KEY\n"
                "- VISION_BASE_URL\n- VISION_MODEL\n"
            ),
            reason="Checklist de env vars do provider",
            strategy_id="provider_env_checklist_v1",
        ))
        patch.risk_level = "low"

    elif root_cause == "rate_limit_upstream":
        patch.operations.append(PatchOperation(
            file="JARVIS_NOTE.md",
            op_type="replace", target="__FULL_FILE__",
            content="# Rate limit upstream\nImplementar fallback de modelos.",
            reason="Sugerir fallback de modelos",
            strategy_id="vision_provider_fallback_v1",
        ))
        patch.risk_level = "low"

    else:
        patch.operations.append(PatchOperation(
            file="JARVIS_REVIEW.md",
            op_type="replace", target="__FULL_FILE__",
            content=f"# Revisão manual\nCausa detectada: {root_cause}.",
            reason="Sem strategy automática definida",
            strategy_id="manual_review_v1",
        ))
        patch.risk_level = "high"

    return patch
