"""
Learning V5 — ranking honesto de estratégias por histórico.

NÃO é ML. É agregação SQL sobre outcomes reais.

Tabela: strategy_outcomes
  - cada missão finalizada escreve aqui
  - scorer agrega: N tentativas, % PASS GOLD
  - ranker escolhe strategy com maior success_rate (n ≥ threshold)
  - blocklist: strategy que falhou N vezes seguidas → temporariamente evitada

Tudo explicável. Tudo consultável. Zero alucinação.
"""
from __future__ import annotations

import sqlite3
from typing import Any

from jarvis_core.config import GLOBAL_LEARNING_DB
from jarvis_core.utils import utc_now_iso


_CREATE = """
CREATE TABLE IF NOT EXISTS strategy_outcomes (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    mission_id     TEXT NOT NULL,
    project_id     TEXT NOT NULL,
    strategy_id    TEXT NOT NULL,
    root_cause     TEXT NOT NULL,
    outcome        TEXT NOT NULL,     -- pass_gold | fail | rolled_back
    risk_score     INTEGER DEFAULT 0,
    auto_applied   INTEGER DEFAULT 0,
    created_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_strat ON strategy_outcomes(strategy_id);
CREATE INDEX IF NOT EXISTS idx_proj  ON strategy_outcomes(project_id);
CREATE INDEX IF NOT EXISTS idx_cause ON strategy_outcomes(root_cause);
"""


def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(GLOBAL_LEARNING_DB)
    conn.executescript(_CREATE)
    conn.commit()
    return conn


# ---------- registro ----------

def record_outcome(
    mission_id: str,
    project_id: str,
    strategy_id: str,
    root_cause: str,
    outcome: str,
    risk_score: int = 0,
    auto_applied: bool = False,
) -> None:
    """Grava resultado. outcome deve ser pass_gold | fail | rolled_back."""
    assert outcome in {"pass_gold", "fail", "rolled_back"}, outcome
    conn = _db()
    try:
        conn.execute(
            """INSERT INTO strategy_outcomes
               (mission_id, project_id, strategy_id, root_cause, outcome,
                risk_score, auto_applied, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (mission_id, project_id, strategy_id, root_cause, outcome,
             risk_score, 1 if auto_applied else 0, utc_now_iso()),
        )
        conn.commit()
    finally:
        conn.close()


# ---------- leitura / ranking ----------

def score_strategy(strategy_id: str, project_id: str | None = None) -> dict[str, Any]:
    """Retorna estatísticas de uma strategy."""
    conn = _db()
    try:
        base = "FROM strategy_outcomes WHERE strategy_id = ?"
        params: list[Any] = [strategy_id]
        if project_id:
            base += " AND project_id = ?"
            params.append(project_id)

        n = conn.execute(f"SELECT COUNT(*) {base}", params).fetchone()[0]
        if n == 0:
            return {
                "strategy_id": strategy_id,
                "n": 0,
                "pass_gold_n": 0,
                "success_rate": None,
                "last_outcomes": [],
                "verdict": "unproven",
            }
        pg = conn.execute(
            f"SELECT COUNT(*) {base} AND outcome = 'pass_gold'", params
        ).fetchone()[0]
        last = conn.execute(
            f"SELECT outcome {base} ORDER BY id DESC LIMIT 10", params
        ).fetchall()

        rate = pg / n
        return {
            "strategy_id": strategy_id,
            "n": n,
            "pass_gold_n": pg,
            "success_rate": round(rate, 3),
            "last_outcomes": [r[0] for r in last],
            "verdict": _verdict(n, rate),
        }
    finally:
        conn.close()


def _verdict(n: int, rate: float) -> str:
    if n < 3:
        return "unproven"
    if rate >= 0.8:
        return "proven"
    if rate >= 0.5:
        return "promising"
    return "risky"


def rank_strategies_for(
    root_cause: str,
    project_id: str | None = None,
    candidate_ids: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Retorna ranking ordenado pra uma causa raiz."""
    conn = _db()
    try:
        q = "SELECT DISTINCT strategy_id FROM strategy_outcomes WHERE root_cause = ?"
        params: list[Any] = [root_cause]
        if project_id:
            q += " AND project_id = ?"
            params.append(project_id)
        rows = conn.execute(q, params).fetchall()
        ids = [r[0] for r in rows]
        if candidate_ids:
            # garante que todos os candidatos aparecem, mesmo sem histórico
            for cid in candidate_ids:
                if cid not in ids:
                    ids.append(cid)
    finally:
        conn.close()

    scored = [score_strategy(sid, project_id) for sid in ids]
    # ordena: proven > promising > unproven > risky; dentro do tier, rate desc
    tier_order = {"proven": 0, "promising": 1, "unproven": 2, "risky": 3}
    scored.sort(key=lambda s: (tier_order[s["verdict"]],
                                -(s["success_rate"] or 0),
                                -s["n"]))
    return scored


# ---------- blocklist ----------

def is_blocklisted(strategy_id: str, project_id: str | None = None,
                   streak_threshold: int = 3) -> tuple[bool, str]:
    """True se a strategy falhou N vezes seguidas recentemente."""
    s = score_strategy(strategy_id, project_id)
    last = s["last_outcomes"][:streak_threshold]
    if len(last) < streak_threshold:
        return False, "insufficient_history"
    if all(o != "pass_gold" for o in last):
        return True, f"failed_{streak_threshold}_in_a_row"
    return False, "ok"


# ---------- métricas globais ----------

def learning_stats() -> dict[str, Any]:
    conn = _db()
    try:
        total = conn.execute("SELECT COUNT(*) FROM strategy_outcomes").fetchone()[0]
        per_outcome = dict(conn.execute(
            "SELECT outcome, COUNT(*) FROM strategy_outcomes GROUP BY outcome"
        ).fetchall())
        top = conn.execute(
            """SELECT strategy_id, COUNT(*) as n,
                      SUM(CASE WHEN outcome='pass_gold' THEN 1 ELSE 0 END) as pg
               FROM strategy_outcomes
               GROUP BY strategy_id
               ORDER BY n DESC
               LIMIT 10"""
        ).fetchall()
        return {
            "total_outcomes": total,
            "by_outcome": per_outcome,
            "top_strategies": [
                {
                    "strategy_id": r[0],
                    "n": r[1],
                    "pass_gold_n": r[2],
                    "success_rate": round(r[2] / r[1], 3) if r[1] else 0,
                }
                for r in top
            ],
        }
    finally:
        conn.close()
