#!/usr/bin/env python3
"""
JARVIS V4.5 Learning Layer — CLI

Bolt-on pro Jarvis V4. Adiciona:
  - multi-project registry
  - strategy learning (success rate histórico)
  - autonomy decision engine (threshold-based)

Uso:
  python apps/cli/jarvis_learn.py projects list
  python apps/cli/jarvis_learn.py projects add --id x --name "X" --adapter generic
  python apps/cli/jarvis_learn.py learning record --mission-id m1 --project technetgame \\
         --strategy vision_mimetype_guard_v1 --root-cause missing_input_validation \\
         --outcome pass_gold --risk-score 15
  python apps/cli/jarvis_learn.py learning score --strategy vision_mimetype_guard_v1
  python apps/cli/jarvis_learn.py learning rank --root-cause missing_input_validation
  python apps/cli/jarvis_learn.py learning stats
  python apps/cli/jarvis_learn.py autonomy check --project technetgame \\
         --strategy vision_mimetype_guard_v1 --risk 15 \\
         --root-cause missing_input_validation
"""
from __future__ import annotations

import argparse
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from jarvis_core.commands import projects as cmd_projects
from jarvis_core.commands import learning as cmd_learning
from jarvis_core.commands import autonomy as cmd_autonomy


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="jarvis-learn",
                                description="Jarvis V4.5 Learning Layer")
    sub = p.add_subparsers(dest="group", required=True)

    # ---- projects ----
    pp = sub.add_parser("projects", help="Gerenciar projetos")
    pps = pp.add_subparsers(dest="action", required=True)

    pps.add_parser("list").set_defaults(fn=cmd_projects.cmd_list)

    s = pps.add_parser("show"); s.add_argument("id"); s.set_defaults(fn=cmd_projects.cmd_show)

    s = pps.add_parser("add")
    s.add_argument("--id", required=True)
    s.add_argument("--name", required=True)
    s.add_argument("--adapter", default="generic")
    s.add_argument("--base-url", default="")
    s.add_argument("--project-root", default="")
    s.add_argument("--not-critical", action="store_true", help="projeto não crítico (default: crítico)")
    s.add_argument("--auto-apply", action="store_true", help="habilita auto-apply (default: off)")
    s.add_argument("--metadata", default="", help="JSON string")
    s.set_defaults(fn=cmd_projects.cmd_add)

    s = pps.add_parser("update")
    s.add_argument("id")
    s.add_argument("--name", default=None)
    s.add_argument("--adapter", default=None)
    s.add_argument("--base-url", default=None)
    s.add_argument("--project-root", default=None)
    s.add_argument("--critical", choices=["true", "false"], default=None)
    s.add_argument("--auto-apply", choices=["true", "false"], default=None)
    s.add_argument("--metadata", default="")
    s.set_defaults(fn=cmd_projects.cmd_update)

    s = pps.add_parser("delete"); s.add_argument("id")
    s.set_defaults(fn=cmd_projects.cmd_delete)

    pps.add_parser("seed",
                   help="Cria technetgame default se não existir"
                   ).set_defaults(fn=cmd_projects.cmd_seed)

    # ---- learning ----
    pl = sub.add_parser("learning", help="Strategy outcomes + ranking")
    pls = pl.add_subparsers(dest="action", required=True)

    s = pls.add_parser("record")
    s.add_argument("--mission-id", required=True)
    s.add_argument("--project", required=True)
    s.add_argument("--strategy", required=True)
    s.add_argument("--root-cause", required=True)
    s.add_argument("--outcome", required=True,
                   choices=["pass_gold", "fail", "rolled_back"])
    s.add_argument("--risk-score", type=int, default=0)
    s.add_argument("--auto-applied", action="store_true")
    s.set_defaults(fn=cmd_learning.cmd_record)

    s = pls.add_parser("score")
    s.add_argument("--strategy", required=True)
    s.add_argument("--project", default=None)
    s.set_defaults(fn=cmd_learning.cmd_score)

    s = pls.add_parser("rank")
    s.add_argument("--root-cause", required=True)
    s.add_argument("--project", default=None)
    s.add_argument("--candidates", default="",
                   help="CSV de strategy_ids candidatas (inclui mesmo sem histórico)")
    s.set_defaults(fn=cmd_learning.cmd_rank)

    pls.add_parser("stats").set_defaults(fn=cmd_learning.cmd_stats)

    # ---- autonomy ----
    pa = sub.add_parser("autonomy", help="Decisão de auto-apply")
    pas = pa.add_subparsers(dest="action", required=True)

    s = pas.add_parser("check")
    s.add_argument("--project", required=True)
    s.add_argument("--strategy", required=True)
    s.add_argument("--root-cause", required=True)
    s.add_argument("--risk", type=int, required=True,
                   help="risk_final (0-100)")
    s.set_defaults(fn=cmd_autonomy.cmd_check)

    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    print(args.fn(args))


if __name__ == "__main__":
    main()
