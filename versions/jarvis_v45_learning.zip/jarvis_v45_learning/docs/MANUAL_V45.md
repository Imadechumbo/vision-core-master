# Manual V4.5 Learning Layer

## Conceito

V4.5 não é uma reescrita. É um **módulo plugável** que adiciona aprendizado estatístico e decisão autônoma ao V4.

> **Princípio:** não alucina. Tudo é agregação SQL sobre outcomes reais.

## Componentes

### 1. Projects Registry (`jarvis_core/projects/`)

Registro global SQLite de projetos. Cada um tem:
- `id`, `display_name`, `adapter`, `base_url`, `project_root`
- `critical` (bool) — se true, auto-apply **nunca** acontece
- `auto_apply_enabled` (bool) — master switch de autonomia
- `metadata` (JSON livre)

Cada projeto ganha diretório próprio em `data/projects/<id>/` com incidents, patches, stable vault isolados.

### 2. Learning (`jarvis_core/learning/strategy_scorer.py`)

Cada patch aplicado tem um `strategy_id` (ex: `vision_mimetype_guard_v1`). Ao fim da missão, grava-se um **outcome**:
- `pass_gold` — gates passaram
- `fail` — falhou sem rollback
- `rolled_back` — falhou e teve rollback

A partir daí:
- **`score_strategy(id)`** — retorna `n`, `pass_gold_n`, `success_rate`, veredito (`proven` / `promising` / `unproven` / `risky`)
- **`rank_strategies_for(root_cause)`** — ordena strategies por veredito e taxa de sucesso
- **`is_blocklisted(id)`** — true se falhou N vezes seguidas

**Regra de veredito:**
```
n < 3              → unproven
rate ≥ 0.8         → proven
0.5 ≤ rate < 0.8   → promising
rate < 0.5         → risky
```

### 3. Autonomy Decision (`jarvis_core/autonomy/decision.py`)

Para cada missão que pode ser auto-aplicada, roda:

```
auto_apply_approved = TRUE  ⟺
  ctx.auto_apply_enabled
  AND NOT ctx.critical
  AND risk_final ≤ 25
  AND policy.allowed
  AND TODAS as strategies do patch são "proven"
  AND NENHUMA strategy está blocklisted
```

Qualquer falha → `requires_approval` com lista explícita de `reasons`.

### 4. Taxonomia formal (`jarvis_core/taxonomy.py`)

16 classes canônicas de root cause. `assert_valid(rc)` rejeita qualquer coisa fora da lista. Força o RCA a ser **agregável**.

### 5. RCA determinístico (`jarvis_core/rca.py`)

Classificação por intent + signals. Retorna `RCAResult` com `root_cause` (classe canônica), `narrative` (humano), `cause_chain` (efeito → causa subjacente via `CAUSAL_LINKS`).

Hook opt-in: `JARVIS_EXPERIMENTAL_RCA=1` tenta importar `jarvis_core.experimental.adaptive_rca` — só anexa `hints`, nunca sobrescreve.

### 6. Policy com risk score numérico (`jarvis_core/policy.py`)

`risk_final = {low:10, medium:30, high:55}[patch.risk_level] + RISK_PROFILE_WEIGHT[mission.risk_profile]`

Bloqueia em:
- op type fora da allowlist (`delete_file`, `deploy_prod`, `rollback_prod`, `modify_secrets`)
- arquivo sensível (contém `auth`, `billing`, `payment`, `.env`, `secret`)
- `risk_final ≥ 80`

### 7. Patch planner com strategy_id (`jarvis_core/patch_planner.py`)

Cada `PatchOperation` carrega `strategy_id`. É o que conecta **planejamento** ao **learning**.

Strategies conhecidas (v1):
- `vision_mimetype_guard_v1`
- `vision_route_create_v1`
- `vision_provider_fallback_v1`
- `cors_headers_consistent_v1`
- `zip_route_create_v1`
- `provider_env_checklist_v1`
- `manual_review_v1`

Novas strategies: adicione op no planner com `strategy_id="novo_nome_v1"`. Learning começa a trackear automaticamente.

## Fluxo numa missão real

```
1. orchestrator V4 chama parse_mission / scan / evidence  (V4 original)
2. rca.build_rca() retorna RCAResult com classe canônica    (V4.5)
3. patch_planner.plan_patch() gera StructuredPatch com strategy_ids  (V4.5)
4. policy.evaluate_policy() retorna risk_final numérico     (V4.5)
5. autonomy.decision.decide() diz se auto-apply ou não      (V4.5, novo!)
6. patch_applier.apply_patch() aplica (dry-run ou real)     (V4 original)
7. gates.run_http_gates() valida via HTTP real              (V4 original)
8. se PASS → stable_vault.promote_to_gold() snapshot        (V4 original)
9. se FAIL + auto_rollback → stable_vault.rollback_gold()   (V4 original)
10. strategy_scorer.record_outcome() grava histórico       (V4.5, novo!)
11. incident_store.save_incident() persiste                 (V4 original)
```

Cada passo faz uma coisa só, cada peça é testável isolada.

## Estado da arte honesto

| Capacidade | V4 | V4.5 |
|---|---|---|
| Multi-projeto | ❌ hardcoded technetgame | ✅ registry |
| Risk scoring | ⚠️ booleano | ✅ numérico 0-100 |
| Taxonomia root cause | ❌ string livre | ✅ enum de 16 |
| Learning histórico | ❌ | ✅ success rate |
| Decisão autônoma | ❌ | ✅ threshold-based |
| Gates HTTP reais | ✅ | ✅ (preservado) |
| Stable Vault + rollback | ✅ | ✅ (preservado) |
| Runtime Go distribuído | ⚠️ stub | ⚠️ stub (adiado) |
| RCA adaptativo ML | ❌ | ❌ (hook opt-in) |
| Dashboard web | ❌ | ❌ (adiado — meu V3 tem) |
| Domain adapters EB/GH/CF | ❌ | ❌ (adiado) |

## Próximos passos realistas

Por ordem de ROI:

1. **Hooks no `run_mission.py`** — 1 sessão, passa a gravar outcomes automaticamente
2. **UI web do meu V3 adaptada pra multi-projeto** — 1 sessão
3. **Domain adapter EB (boto3 real + rollback)** — 1 sessão
4. **Domain adapter GitHub Actions (gh CLI wrapper)** — 1 sessão
5. **Domain adapter Cloudflare** — 1 sessão
6. **Runtime Go com workers** — 1 sessão (ou reutilizar meu V3 do runtime Go V1)

Seis sessões focadas te levam ao V5 real, com cada peça **testada** e documentada.
