# Integração V4 → V4.5

Passo a passo pra plugar o Learning Layer no seu V4 existente sem quebrar nada.

## 1. Copiar o pacote

```bash
cp -r jv45/jarvis_core/projects   /caminho/do/v4/jarvis_core/
cp -r jv45/jarvis_core/learning   /caminho/do/v4/jarvis_core/
cp -r jv45/jarvis_core/autonomy   /caminho/do/v4/jarvis_core/
cp    jv45/jarvis_core/taxonomy.py /caminho/do/v4/jarvis_core/
```

## 2. Substituir dois arquivos do V4

**`jarvis_core/policy.py`** — trocar pela versão com `risk_final` numérico:
```bash
cp jv45/jarvis_core/policy.py /caminho/v4/jarvis_core/policy.py
```

A assinatura muda levemente. No V4 original:
```python
def evaluate_policy(mission, patch) -> dict:
```

No V4.5:
```python
def evaluate_policy(mission, patch, apply: bool) -> dict:
```

O `run_mission.py` do V4 precisa passar `apply=apply and not dry_run`. Grep por `evaluate_policy(` e ajuste.

**`jarvis_core/patch_planner.py`** — trocar pela versão que gera `strategy_id` em cada operation:
```bash
cp jv45/jarvis_core/patch_planner.py /caminho/v4/jarvis_core/patch_planner.py
```

O model `PatchOperation` ganhou um campo `strategy_id: str = ""`. Copie o `models.py`:
```bash
cp jv45/jarvis_core/models.py /caminho/v4/jarvis_core/models.py
```

Compatível com código V4 existente (campo novo com default).

## 3. Seed do registry

Primeira vez:
```bash
cd /caminho/do/v4
python apps/cli/jarvis_learn.py projects seed
```

Isso cria o `technetgame` no `data/projects.sqlite`. Também cria `data/projects/technetgame/` com subdirs.

## 4. Modificar `run_mission.py` do V4

Adicionar 3 hooks:

### Hook 1 — antes da policy, carregar context do projeto

```python
from jarvis_core.projects.context import ProjectContext

def run_mission(mission, project_root, project, base_url, apply, dry_run, auto_rollback):
    # garante projeto registrado
    from jarvis_core.projects import registry
    if not registry.get_project(project):
        registry.register_project(project, display_name=project, adapter=project)

    ctx = ProjectContext.load(project)
    # ... resto igual ao V4 ...
```

### Hook 2 — depois da policy, consultar autonomy

```python
from jarvis_core.autonomy import decision

policy = evaluate_policy(mission_obj, patch, apply=apply)  # note novo arg
auto = decision.decide(ctx, policy, patch, rca.root_cause)

# Se usuário passou --auto e autonomy aprovou, força apply=True
effective_apply = apply or (auto["auto_apply_approved"] and args.auto)
```

Adicionar flag `--auto` no argparser do V4.

### Hook 3 — depois dos gates, gravar outcomes

```python
from jarvis_core.learning import strategy_scorer

# outcome final
if gates["pass_gold"]:
    outcome = "pass_gold"
elif rollback:
    outcome = "rolled_back"
else:
    outcome = "fail"

# grava um outcome por strategy aplicada
for op in patch.operations:
    if op.strategy_id:
        strategy_scorer.record_outcome(
            mission_id=mission_obj.mission_id if hasattr(mission_obj, 'mission_id') else incident.get("incident_id"),
            project_id=project,
            strategy_id=op.strategy_id,
            root_cause=rca.root_cause if isinstance(rca.root_cause, str) else "unknown_general_issue",
            outcome=outcome,
            risk_score=policy.get("risk_final", 0),
            auto_applied=effective_apply and auto["auto_apply_approved"],
        )
```

### Retorno — anexar ao JSON final

```python
return {
    # ... tudo que o V4 já retorna ...
    "autonomy": auto,
    "registry_context": ctx.data,
}
```

## 5. Usar

```bash
# Cada missão agora grava histórico automaticamente
python apps/cli/jarvis.py "corrigir vision do technetgame" \
    --project-root /caminho/projeto \
    --base-url https://api.technetgame.com.br

# Ver learning
python apps/cli/jarvis_learn.py learning stats

# Habilitar auto-apply no projeto (fica off por default)
python apps/cli/jarvis_learn.py projects update technetgame --auto-apply true
# E tirar ele de crítico quando tiver confiança:
python apps/cli/jarvis_learn.py projects update technetgame --critical false

# Agora missões low-risk com strategies proven podem rodar com --auto
python apps/cli/jarvis.py "..." --auto
```

## 6. Rollback dessa integração (se algo quebrar)

```bash
cd /caminho/v4
git checkout jarvis_core/policy.py jarvis_core/patch_planner.py jarvis_core/models.py
rm -rf jarvis_core/projects jarvis_core/learning jarvis_core/autonomy jarvis_core/taxonomy.py
```

O V4.5 é **aditivo** — sem ele, o V4 volta exatamente como era.

## 7. Onde os dados ficam

```
data/
├── projects.sqlite              # registry global
├── learning.sqlite              # outcomes globais (cross-project)
└── projects/
    ├── technetgame/
    │   ├── incidents.sqlite     # V4 continua escrevendo aqui
    │   ├── patches/             # V4 continua
    │   ├── stable/GOLD/         # V4 continua
    │   └── obsidian/            # V4 continua
    └── outro_projeto/
        └── ...                  # isolado
```

O V4 precisa ser ajustado pra escrever em `data/projects/<id>/` em vez de `data/` global. Um find/replace no V4:
```python
# Antes (V4):
INCIDENT_DB_PATH = os.path.join(DATA_DIR, 'incidents.sqlite')

# Depois (V4.5):
from jarvis_core.config import project_incidents_db
INCIDENT_DB_PATH = project_incidents_db(project_id)
```

Ou mais simples: manter V4 como está e deixar o V4.5 escrever em `data/learning.sqlite` separado. Decisão sua.
