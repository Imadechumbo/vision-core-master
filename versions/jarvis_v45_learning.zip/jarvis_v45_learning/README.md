# Jarvis V4.5 Learning Layer

**Bolt-on do V4.** Adiciona três capacidades reais em cima do V4 sem quebrar nada:

1. **Multi-projeto real** — registry com isolamento de stores por projeto
2. **Learning estatístico** — success rate por strategy, ranking, blocklist
3. **Autonomy decision engine** — decide auto-apply por thresholds (risk + success rate + criticality)

Zero ML, zero alucinação. É **estatística sobre histórico real**.

## Status

✅ **36/36 smoke tests passando** (`python tests/smoke_test.py`)

## O que NÃO é isso

- **Não é V5 completo.** V5 aspiracional tinha 7 pontos; só 3 são entregáveis honestos agora. Ver `docs/WHAT_IS_NOT_INCLUDED.md`.
- **Não executa missão.** V4.5 é uma biblioteca que o V4 chama. O orquestrador do V4 continua sendo o orquestrador.
- **Não é RCA adaptativo de verdade.** O `rca.py` aqui é determinístico com taxonomia formal — só tem um hook opt-in pra um `experimental/adaptive_rca` que você pode preencher depois.

## Instalação

```bash
# Extrai em cima (ou lado a lado) do seu jarvis_core_v4_complete/
unzip jarvis_v45_learning.zip
cd jv45
pip install -r requirements.txt   # só stdlib + opcional
```

Zero dependências obrigatórias — tudo Python stdlib. `requirements.txt` lista opcionais só pra CLI colorida.

## Uso — CLI rápida

```bash
# 1. Garante projeto technetgame no registry
python apps/cli/jarvis_learn.py projects seed

# 2. Lista projetos
python apps/cli/jarvis_learn.py projects list

# 3. Adiciona outro projeto
python apps/cli/jarvis_learn.py projects add --id my_api \
    --name "Minha API" --adapter generic --base-url https://api.minha.com \
    --project-root /caminho/projeto

# 4. Registra outcome (o V4 chama isso no fim de cada missão)
python apps/cli/jarvis_learn.py learning record \
    --mission-id m-001 --project technetgame \
    --strategy vision_mimetype_guard_v1 \
    --root-cause missing_input_validation \
    --outcome pass_gold --risk-score 15

# 5. Vê success rate dessa strategy
python apps/cli/jarvis_learn.py learning score \
    --strategy vision_mimetype_guard_v1 --project technetgame

# 6. Ranking por causa raiz
python apps/cli/jarvis_learn.py learning rank \
    --root-cause missing_input_validation --project technetgame

# 7. Stats globais
python apps/cli/jarvis_learn.py learning stats

# 8. Pergunta se auto-apply pode acontecer
python apps/cli/jarvis_learn.py autonomy check \
    --project technetgame --strategy vision_mimetype_guard_v1 \
    --root-cause missing_input_validation --risk 15
```

## Como integrar com o V4

No seu V4, edite `run_mission.py` pra chamar 2 novos hooks:

**Antes de aplicar patch:**
```python
from jarvis_core.autonomy import decision
from jarvis_core.projects.context import ProjectContext

ctx = ProjectContext.load(project)
decision_result = decision.decide(ctx, policy, patch, rca.root_cause)

# Se auto-apply aprovado e usuário pediu --auto, aplica sem pedir aprovação
if decision_result["auto_apply_approved"] and args.auto:
    will_apply = True
else:
    will_apply = args.apply  # fluxo manual normal
```

**Depois dos gates:**
```python
from jarvis_core.learning import strategy_scorer

outcome = "pass_gold" if gates["pass_gold"] else ("rolled_back" if rollback else "fail")

for op in patch.operations:
    if op.strategy_id:
        strategy_scorer.record_outcome(
            mission_id=mission_obj.mission_id,
            project_id=project,
            strategy_id=op.strategy_id,
            root_cause=rca.root_cause,
            outcome=outcome,
            risk_score=policy.get("risk_final", 0),
            auto_applied=will_apply,
        )
```

Pronto. Cada missão agora alimenta o learning e consulta a decisão.

## Estrutura

```
jv45/
├── apps/cli/jarvis_learn.py          # CLI bolt-on
├── jarvis_core/
│   ├── config.py                     # paths por projeto
│   ├── utils.py
│   ├── models.py                     # Mission, Patch, RCAResult, Outcome
│   ├── taxonomy.py                   # 16 root causes canônicas
│   ├── rca.py                        # RCA determinístico
│   ├── patch_planner.py              # com strategy_id
│   ├── policy.py                     # risk score numérico
│   ├── projects/
│   │   ├── registry.py               # SQLite registry
│   │   └── context.py                # isolamento per-project
│   ├── learning/
│   │   └── strategy_scorer.py        # record/score/rank/blocklist/stats
│   ├── autonomy/
│   │   └── decision.py               # decisão auto-apply
│   └── commands/                     # projects|learning|autonomy
├── tests/smoke_test.py               # 36 testes
├── docs/
│   ├── MANUAL_V45.md                 # o que é
│   ├── WHAT_IS_NOT_INCLUDED.md       # o que NÃO é
│   └── INTEGRATION_V4.md             # passo a passo
└── data/                             # criado em runtime
    ├── projects.sqlite               # registry global
    ├── learning.sqlite               # outcomes
    └── projects/<id>/                # por projeto
        ├── incidents.sqlite
        ├── patches/
        ├── stable/
        └── obsidian/
```

## Thresholds de autonomia (ajustáveis)

Em `jarvis_core/autonomy/decision.py`:

```python
MAX_AUTO_RISK = 25           # risk_score máximo
MIN_SUCCESS_RATE = 0.80      # strategy tem que ter ≥80% de PASS GOLD
MIN_HISTORY_N = 3            # mínimo 3 usos pra considerar "provado"
```

**Por projeto** você tem duas flags em `projects.sqlite`:
- `critical` — se true, NUNCA auto-apply (bom pra produção por N meses)
- `auto_apply_enabled` — master switch

## Filosofia

**"Aprende sozinho" aqui significa:** quanto mais missões você roda, mais o sistema sabe quais strategies funcionam pra quê. Depois de 30 execuções no TechNetGame, o ranking começa a mostrar padrões reais ("sempre que `vision_mimetype_guard_v1` é aplicado, 85% das vezes dá PASS GOLD → prefira essa").

**Não significa:** o sistema inventa strategies novas. Isso é pra V6.

Ver `docs/WHAT_IS_NOT_INCLUDED.md` pra honestidade total sobre limites.
