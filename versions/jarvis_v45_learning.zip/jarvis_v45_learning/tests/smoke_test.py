"""
Smoke test do V4.5 Learning Layer.

Prova que:
  1. Registry multi-projeto: add/list/get/update funciona com isolamento
  2. Strategy scorer: após 5 outcomes, success_rate bate com conta manual
  3. Ranking: strategy 'proven' aparece antes de 'unproven'
  4. Blocklist: 3 falhas seguidas → blocklisted=True
  5. Autonomy: só aprova se TUDO bate; bloqueia e explica reason
  6. Isolamento por projeto: mesma strategy, projetos diferentes → stats isoladas
  7. Taxonomia formal rejeita root cause inválida
  8. RCA determinístico classifica corretamente
  9. Patch planner gera strategy_id conhecido
 10. Policy score numérico reage a risk_profile
"""
from __future__ import annotations

import os
import shutil
import sys
import tempfile

# Isola cada run do teste num DATA_DIR temporário
_TMP = tempfile.mkdtemp(prefix="jarvis_v45_test_")
os.environ["JARVIS_TEST_ROOT"] = _TMP

# Monkey-patch config pra usar _TMP
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)

import jarvis_core.config as cfg
cfg.DATA_DIR = os.path.join(_TMP, "data")
cfg.PROJECTS_DIR = os.path.join(cfg.DATA_DIR, "projects")
cfg.GLOBAL_REGISTRY_DB = os.path.join(cfg.DATA_DIR, "projects.sqlite")
cfg.GLOBAL_LEARNING_DB = os.path.join(cfg.DATA_DIR, "learning.sqlite")
os.makedirs(cfg.DATA_DIR, exist_ok=True)
os.makedirs(cfg.PROJECTS_DIR, exist_ok=True)

GREEN = "\033[92m"; RED = "\033[91m"; YELLOW = "\033[93m"; END = "\033[0m"
passed = 0; failed = 0; failures: list[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    global passed, failed
    if cond:
        passed += 1
        print(f"  {GREEN}✓{END} {name}")
    else:
        failed += 1
        failures.append(f"{name} — {detail}")
        print(f"  {RED}✗{END} {name}  {YELLOW}{detail}{END}")


def section(t: str) -> None:
    print(f"\n{t}")


# ---------- 1. Registry multi-projeto ----------
section("1. Registry multi-projeto")
from jarvis_core.projects import registry

p1 = registry.register_project("proj_a", "Projeto A", adapter="generic",
                                base_url="https://a.example.com",
                                critical=True)
check("add proj_a", p1["id"] == "proj_a")
check("isolamento data_dir", os.path.isdir(cfg.project_data_dir("proj_a")))

p2 = registry.register_project("proj_b", "Projeto B", adapter="technetgame",
                                auto_apply_enabled=True, critical=False)
check("add proj_b", p2["id"] == "proj_b")

lst = registry.list_projects()
check("list retorna 2 projetos", len(lst) == 2)

got = registry.get_project("proj_b")
check("get respeita flags", got["auto_apply_enabled"] is True and got["critical"] is False)

upd = registry.update_project("proj_a", auto_apply_enabled=True)
check("update funciona", upd["auto_apply_enabled"] is True)


# ---------- 2-4. Learning: record + score + rank + blocklist ----------
section("2-4. Strategy scorer + ranking + blocklist")
from jarvis_core.learning import strategy_scorer

# proj_a: strategy_x com 4 PASS e 1 FAIL
for i in range(4):
    strategy_scorer.record_outcome(f"m_{i}", "proj_a", "strategy_x",
                                    "missing_input_validation", "pass_gold", 15)
strategy_scorer.record_outcome("m_4", "proj_a", "strategy_x",
                                "missing_input_validation", "fail", 15)

score = strategy_scorer.score_strategy("strategy_x", "proj_a")
check("score n=5", score["n"] == 5, f"got n={score['n']}")
check("success_rate=0.8", score["success_rate"] == 0.8,
      f"got {score['success_rate']}")
check("verdict=proven (rate≥0.8, n≥3)", score["verdict"] == "proven",
      f"got {score['verdict']}")

# strategy_y: nunca foi usada
score_y = strategy_scorer.score_strategy("strategy_y", "proj_a")
check("strategy inexistente = unproven", score_y["verdict"] == "unproven")

# Ranking: strategy_x deve vir antes de strategy_y
ranking = strategy_scorer.rank_strategies_for("missing_input_validation",
                                               "proj_a",
                                               candidate_ids=["strategy_y"])
check("ranking inclui ambas", len(ranking) == 2)
check("proven vem antes de unproven",
      ranking[0]["verdict"] == "proven" and ranking[1]["verdict"] == "unproven")

# Blocklist: 3 fails seguidas na strategy_z
for i in range(3):
    strategy_scorer.record_outcome(f"mz_{i}", "proj_a", "strategy_z",
                                    "cors_misconfiguration", "fail", 20)
blocked, reason = strategy_scorer.is_blocklisted("strategy_z", "proj_a")
check("blocklist detecta 3 fails seguidas", blocked,
      f"blocked={blocked} reason={reason}")

# Não bloqueia se há PASS recente
strategy_scorer.record_outcome("mz_recover", "proj_a", "strategy_z",
                                "cors_misconfiguration", "pass_gold", 20)
blocked2, _ = strategy_scorer.is_blocklisted("strategy_z", "proj_a")
check("blocklist libera após PASS", not blocked2)


# ---------- 5. Isolamento por projeto ----------
section("5. Isolamento de histórico por projeto")
# strategy_x tem histórico em proj_a. Em proj_b deve aparecer vazio.
score_b = strategy_scorer.score_strategy("strategy_x", "proj_b")
check("mesma strategy, projeto diferente → n=0 isolado",
      score_b["n"] == 0, f"got n={score_b['n']}")


# ---------- 6. Autonomy ----------
section("6. Autonomy decision engine")
from jarvis_core.autonomy import decision
from jarvis_core.projects.context import ProjectContext
from jarvis_core.models import PatchOperation, StructuredPatch


class _M: intent = "fix_vision"; risk_profile = "medium"


ctx_a = ProjectContext.load("proj_a")
patch = StructuredPatch(
    risk_level="low", summary="test",
    operations=[PatchOperation(file="x", op_type="insert", target="X",
                                content="", reason="",
                                strategy_id="strategy_x")],
)
policy_ok = {"risk_final": 15, "blocked": False, "allowed": True}

# proj_a tem auto_apply_enabled=True, critical=True → deve bloquear por crítico
d = decision.decide(ctx_a, policy_ok, patch, "missing_input_validation")
check("crítico bloqueia auto-apply", not d["auto_apply_approved"],
      f"reasons={d['reasons']}")
check("motivo aparece", "project_marked_critical" in d["reasons"])

# proj_b não-crítico, auto_apply=True, strategy_x em proj_b é unproven → bloqueia
ctx_b = ProjectContext.load("proj_b")
d_b = decision.decide(ctx_b, policy_ok, patch, "missing_input_validation")
check("strategy unproven bloqueia em proj novo", not d_b["auto_apply_approved"])

# Migrar histórico: gravar 3 PASS em proj_b com strategy_x
for i in range(5):
    strategy_scorer.record_outcome(f"b_{i}", "proj_b", "strategy_x",
                                    "missing_input_validation", "pass_gold", 15)
d_b2 = decision.decide(ctx_b, policy_ok, patch, "missing_input_validation")
check("strategy proven + proj não-crítico + risk baixo → APROVA",
      d_b2["auto_apply_approved"],
      f"reasons={d_b2['reasons']}")

# Risk alto bloqueia mesmo com tudo OK
policy_hi = {"risk_final": 80, "blocked": False, "allowed": True}
d_b3 = decision.decide(ctx_b, policy_hi, patch, "missing_input_validation")
check("risk alto bloqueia", not d_b3["auto_apply_approved"])


# ---------- 7. Taxonomia ----------
section("7. Taxonomia formal")
from jarvis_core.taxonomy import TAXONOMY, assert_valid

check("taxonomia não vazia", len(TAXONOMY) >= 15)
check("assert_valid aceita válido",
      assert_valid("missing_input_validation") == "missing_input_validation")

try:
    assert_valid("inventei_essa_causa")
    check("assert_valid rejeita inválido", False, "deveria levantar")
except ValueError:
    check("assert_valid rejeita inválido", True)


# ---------- 8. RCA determinístico ----------
section("8. RCA")
from jarvis_core.rca import build_rca


class _Mv: intent = "fix_vision"; risk_profile = "high"


rca = build_rca(_Mv(), {"signals": ["vision_route_missing"]})
check("fix_vision + vision_route_missing → classe certa",
      rca.root_cause == "vision_route_missing",
      f"got {rca.root_cause}")
check("confidence alta", rca.confidence >= 0.9)

rca2 = build_rca(_Mv(), {"signals": ["vision_route_present",
                                      "ai_routes_file_present"]})
check("fix_vision sem rota-missing → missing_input_validation",
      rca2.root_cause == "missing_input_validation",
      f"got {rca2.root_cause}")
check("cause_chain é lista", isinstance(rca2.cause_chain, list))


# ---------- 9. Patch planner ----------
section("9. Patch planner strategy_ids")
from jarvis_core.patch_planner import plan_patch


class _Mc: intent = "fix_cors"; risk_profile = "medium"


class _Rca:
    root_cause = "cors_misconfiguration"


patch_p = plan_patch(_Mc(), {"scan": {"ok": False}}, _Rca())
check("gera pelo menos 1 operation", len(patch_p.operations) >= 1)
check("operation tem strategy_id",
      bool(patch_p.operations[0].strategy_id),
      f"got '{patch_p.operations[0].strategy_id}'")
check("strategy_id conhecido",
      patch_p.operations[0].strategy_id == "cors_headers_consistent_v1")


# ---------- 10. Policy numérica ----------
section("10. Policy score numérico")
from jarvis_core.policy import evaluate_policy


class _Mlow: intent = "fix_cors"; risk_profile = "low"


class _Mcrit: intent = "rollback"; risk_profile = "critical"


from jarvis_core.models import PatchOperation, StructuredPatch
simple = StructuredPatch(risk_level="low", summary="x",
                          operations=[PatchOperation(
                              file="src/routes/cors.js", op_type="insert",
                              target="CORS", content="// x",
                              reason="t", strategy_id="s1")])
pol_low = evaluate_policy(_Mlow(), simple, apply=False)
pol_crit = evaluate_policy(_Mcrit(), simple, apply=True)

check("low risk → score baixo", pol_low["risk_final"] <= 30,
      f"got {pol_low['risk_final']}")
check("critical risk → score mais alto",
      pol_crit["risk_final"] > pol_low["risk_final"],
      f"crit={pol_crit['risk_final']} low={pol_low['risk_final']}")
check("decision DRY_RUN quando apply=False",
      pol_low["decision"] == "ALLOW_DRY_RUN")


# ---------- 11. Learning stats agregado ----------
section("11. Learning stats global")
stats = strategy_scorer.learning_stats()
check("stats tem total > 0", stats["total_outcomes"] > 0)
check("stats agrupa por outcome",
      "pass_gold" in stats["by_outcome"] and "fail" in stats["by_outcome"])
check("top_strategies retorna lista ordenada",
      isinstance(stats["top_strategies"], list) and len(stats["top_strategies"]) >= 1)


# ---------- cleanup + sumário ----------
shutil.rmtree(_TMP, ignore_errors=True)

print(f"\n{'='*60}")
total = passed + failed
if failed == 0:
    print(f"{GREEN}✓ TODOS OS {total} TESTES PASSARAM{END}")
    sys.exit(0)
else:
    print(f"{RED}✗ {failed}/{total} testes falharam{END}")
    for f in failures:
        print(f"  {RED}-{END} {f}")
    sys.exit(1)
