from validation.gates import health_gate, vision_contract_gate, vision_provider_gate, zip_ingest_gate

_GATE_MAP = {
    "health_gate": health_gate.run,
    "vision_contract_gate": vision_contract_gate.run,
    "vision_provider_gate": vision_provider_gate.run,
    "zip_ingest_gate": zip_ingest_gate.run,
}

def run_gates(gate_names, evidence):
    results = []
    for name in gate_names:
        fn = _GATE_MAP.get(name)
        if fn:
            results.append(fn(evidence))
        else:
            results.append({"gate": name, "status": "SKIP", "details": {"reason": "gate_not_implemented"}})
    return {"results": results, "gold": all(r["status"] == "PASS" for r in results if r["gate"] != "vision_provider_gate")}
