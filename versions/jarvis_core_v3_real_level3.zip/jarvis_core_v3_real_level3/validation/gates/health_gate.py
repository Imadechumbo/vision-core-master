def run(evidence: dict) -> dict:
    scan = evidence.get("scan", {})
    routes = [r["route"] for r in scan.get("route_hits", [])]
    ok = "/api/health" in routes
    return {"gate": "health_gate", "status": "PASS" if ok else "FAIL", "details": {"api_health_route_found": ok}}
