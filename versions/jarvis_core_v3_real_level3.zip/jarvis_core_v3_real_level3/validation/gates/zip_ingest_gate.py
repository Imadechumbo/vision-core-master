def run(evidence: dict) -> dict:
    scan = evidence.get("scan", {})
    routes = [r["route"] for r in scan.get("route_hits", [])]
    ok = "/api/v1/chat/project-zip" in routes
    return {"gate": "zip_ingest_gate", "status": "PASS" if ok else "FAIL", "details": {"zip_route_found": ok}}
