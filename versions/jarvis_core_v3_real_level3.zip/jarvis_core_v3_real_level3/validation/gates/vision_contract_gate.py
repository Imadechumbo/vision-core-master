def run(evidence: dict) -> dict:
    scan = evidence.get("scan", {})
    routes = [r["route"] for r in scan.get("route_hits", [])]
    ok = "/api/v1/chat/vision" in routes or "/api/v1/vision" in routes
    return {"gate": "vision_contract_gate", "status": "PASS" if ok else "FAIL", "details": {"vision_route_found": ok}}
