def run(evidence: dict) -> dict:
    env_files = evidence.get("scan", {}).get("env_like_files", [])
    ok = len(env_files) > 0
    return {"gate": "vision_provider_gate", "status": "PASS" if ok else "WARN", "details": {"env_like_files_found": env_files}}
