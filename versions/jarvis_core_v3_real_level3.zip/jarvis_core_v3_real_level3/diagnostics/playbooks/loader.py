import os, yaml

def load_playbook_for_intent(intent: str, playbooks_dir: str) -> dict:
    path = os.path.join(playbooks_dir, f"{intent}.yaml")
    if not os.path.exists(path):
        path = os.path.join(playbooks_dir, "general_diagnosis.yaml")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)
