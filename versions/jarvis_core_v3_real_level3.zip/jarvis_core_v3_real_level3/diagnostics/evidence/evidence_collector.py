from core.mission.project_scanner import scan_project_tree

def collect_evidence(mission: dict, project_root: str) -> dict:
    scan = scan_project_tree(project_root)
    evidence = {"mission": mission, "scan": scan, "signals": []}

    if scan.get("ok"):
        routes = [item["route"] for item in scan.get("route_hits", [])]
        env_files = scan.get("env_like_files", [])

        evidence["signals"].append("vision_route_present" if ("/api/v1/chat/vision" in routes or "/api/v1/vision" in routes) else "vision_route_missing")
        evidence["signals"].append("zip_route_present" if "/api/v1/chat/project-zip" in routes else "zip_route_missing")
        if env_files:
            evidence["signals"].append("env_files_present")
        if any("aiRoutes.js" in f for f in scan.get("interesting_files", [])):
            evidence["signals"].append("ai_routes_file_present")

    return evidence
