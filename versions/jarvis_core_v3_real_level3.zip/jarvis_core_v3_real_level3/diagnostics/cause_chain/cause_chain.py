def build_cause_chain(classification: dict) -> dict:
    return {"cause_chain": [c["root_cause"] for c in classification.get("all_causes", [])]}
