def classify_root_causes(mission: dict, evidence: dict) -> dict:
    signals = set(evidence.get("signals", []))
    intent = mission.get("intent")
    causes = []

    if intent == "fix_vision":
        if "vision_route_missing" in signals:
            causes.append({"root_cause": "vision_route_missing", "confidence": 0.95, "recommended_action": "create_or_register_vision_route"})
        else:
            causes.append({"root_cause": "missing_input_validation", "confidence": 0.78, "recommended_action": "patch_vision_input_validation"})
            causes.append({"root_cause": "provider_not_configured", "confidence": 0.64, "recommended_action": "check_vision_env_provider"})
    elif intent == "fix_zip_ingest":
        if "zip_route_missing" in signals:
            causes.append({"root_cause": "zip_route_missing", "confidence": 0.97, "recommended_action": "create_zip_ingest_route"})
        else:
            causes.append({"root_cause": "zip_ingest_incomplete", "confidence": 0.61, "recommended_action": "inspect_zip_parser_and_contract"})
    else:
        causes.append({"root_cause": "unknown_general_issue", "confidence": 0.35, "recommended_action": "manual_review"})

    return {"primary": causes[0], "all_causes": causes}
