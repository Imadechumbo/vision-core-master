const express = require('express');
const router = express.Router();

router.post('/api/v1/chat/vision', async (req, res) => {
  return res.json({ ok: true });
});

module.exports = router;
