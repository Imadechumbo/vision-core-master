def evaluate_policy(mission: dict, patch_plan: dict, apply_patch: bool) -> dict:
    high_risk_ops = {"delete_file", "deploy_prod", "rollback_prod"}
    blocked = False
    reasons = []

    for op in patch_plan.get("operations", []):
        if op.get("type") in high_risk_ops:
            blocked = True
            reasons.append(f"blocked_high_risk_operation:{op.get('type')}")

    if mission.get("constraints", {}).get("allow_production") is True:
        blocked = True
        reasons.append("production_not_allowed_in_v3_level3")

    if apply_patch and blocked:
        decision = "BLOCK"
    elif apply_patch:
        decision = "ALLOW_WITH_SUPERVISION"
    else:
        decision = "ALLOW_DRY_RUN"

    return {"decision": decision, "blocked": blocked, "reasons": reasons}
