# MANUAL MESTRE DO PROJETO V3

## Escopo desta versão
V3 REAL NÍVEL 3 consolida:
- execução por missão
- scan estrutural do projeto
- RCA por playbook
- memória de incidentes
- patch supervisionado
- gates SDDF iniciais para TechNetGame

## Blocos novos desta entrega
1. Patch Planner
2. Patch Applier Supervisionado
3. Project Scanner
4. Incident Store (JSON + SQLite)
5. RCA Playbooks por intent
6. Gates reais iniciais TechNetGame

## Regra principal
SEM PASS GOLD → NADA É PROMOVIDO

## Memória
- incidentes estruturados em JSON
- banco SQLite para consultas futuras
- notas operacionais em Obsidian Markdown
