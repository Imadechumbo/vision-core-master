import os, datetime, json

def write_obsidian_note(root_dir: str, mission: dict, classification: dict, patch_plan: dict, gate_results: dict) -> str:
    obsidian_dir = os.path.join(root_dir, "memory", "obsidian")
    os.makedirs(obsidian_dir, exist_ok=True)
    path = os.path.join(obsidian_dir, f"{mission['mission_id']}.md")
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"# Missão {mission['mission_id']}\n\n")
        f.write(f"- Projeto: {mission['project_id']}\n")
        f.write(f"- Intent: {mission['intent']}\n")
        f.write(f"- Data: {datetime.datetime.utcnow().isoformat()}Z\n\n")
        f.write("## Causa raiz\n")
        f.write(f"- Primária: {classification.get('primary', {}).get('root_cause')}\n\n")
        f.write("## Patch plan\n```json\n")
        f.write(json.dumps(patch_plan, indent=2, ensure_ascii=False))
        f.write("\n```\n\n## Gates\n```json\n")
        f.write(json.dumps(gate_results, indent=2, ensure_ascii=False))
        f.write("\n```\n")
    return path
