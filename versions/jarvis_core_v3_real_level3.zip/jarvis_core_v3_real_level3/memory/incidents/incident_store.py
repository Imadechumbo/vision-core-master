import os, json, sqlite3, datetime

class IncidentStore:
    def __init__(self, root_dir: str):
        self.root_dir = root_dir
        self.json_path = os.path.join(root_dir, "memory", "incidents", "incidents.json")
        self.sqlite_path = os.path.join(root_dir, "memory", "incidents", "incidents.sqlite3")
        os.makedirs(os.path.dirname(self.json_path), exist_ok=True)
        if not os.path.exists(self.json_path):
            with open(self.json_path, "w", encoding="utf-8") as f:
                json.dump([], f, indent=2)
        self._init_sqlite()

    def _init_sqlite(self):
        conn = sqlite3.connect(self.sqlite_path)
        try:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS incidents (
                    incident_id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    project_id TEXT,
                    intent TEXT,
                    primary_root_cause TEXT,
                    status TEXT,
                    payload_json TEXT NOT NULL
                )
            ''')
            conn.commit()
        finally:
            conn.close()

    def save(self, incident: dict):
        with open(self.json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        data.append(incident)
        with open(self.json_path, "w", encoding="utf-8", newline="\n") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        conn = sqlite3.connect(self.sqlite_path)
        try:
            conn.execute(
                "INSERT OR REPLACE INTO incidents (incident_id, created_at, project_id, intent, primary_root_cause, status, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    incident["incident_id"],
                    incident["created_at"],
                    incident.get("project_id"),
                    incident.get("intent"),
                    incident.get("primary_root_cause"),
                    incident.get("status", "OPEN"),
                    json.dumps(incident, ensure_ascii=False),
                ),
            )
            conn.commit()
        finally:
            conn.close()

    def build_incident(self, mission: dict, classification: dict, cause_chain: dict, payload: dict) -> dict:
        return {
            "incident_id": mission["mission_id"],
            "created_at": datetime.datetime.utcnow().isoformat() + "Z",
            "project_id": mission["project_id"],
            "intent": mission["intent"],
            "primary_root_cause": classification.get("primary", {}).get("root_cause"),
            "cause_chain": cause_chain.get("cause_chain", []),
            "status": "OPEN",
            "payload": payload,
        }
