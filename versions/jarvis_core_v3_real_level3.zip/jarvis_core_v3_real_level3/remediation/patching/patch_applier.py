VISION_GUARD_SNIPPET = '''
// [JARVIS_V3_PATCH] Vision guards
if (!req.file) {
  return res.status(400).json({
    ok: false,
    error: 'IMAGE_REQUIRED',
    message: 'Envie uma imagem no campo "image".'
  });
}

if (!req.file.mimetype || req.file.mimetype === 'null' || req.file.mimetype === 'undefined') {
  const path = require('path');
  const ext = path.extname(String(req.file.originalname || '').toLowerCase());
  const mimeMap = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
    '.bmp': 'image/bmp'
  };
  req.file.mimetype = mimeMap[ext] || 'image/png';
}

if (!String(req.file.mimetype).startsWith('image/')) {
  return res.status(400).json({
    ok: false,
    error: 'INVALID_IMAGE_MIMETYPE',
    message: 'Arquivo enviado não é uma imagem válida.'
  });
}
// [JARVIS_V3_PATCH_END]
'''.strip()

ZIP_ROUTE_FILE = '''
const express = require('express');
const router = express.Router();

router.post('/api/v1/chat/project-zip', async (req, res) => {
  return res.json({
    ok: true,
    message: 'ZIP ingest route placeholder criada pelo JARVIS V3.'
  });
});

module.exports = router;
'''.strip()

def apply_patch_plan(project_root: str, patch_plan: dict, apply_patch: bool = False) -> dict:
    import os
    results = []

    for op in patch_plan.get("operations", []):
        op_type = op.get("type")

        if op_type == "patch_text":
            full = os.path.join(project_root, op["target_file"])
            if not os.path.exists(full):
                results.append({"status": "missing_target", "operation": op})
                continue

            with open(full, "r", encoding="utf-8", errors="ignore") as f:
                original = f.read()

            if op.get("strategy") == "append_safe_guard_template":
                if "[JARVIS_V3_PATCH]" in original:
                    results.append({"status": "already_present", "operation": op})
                    continue
                patched = original + "\n\n" + VISION_GUARD_SNIPPET + "\n"
            elif op.get("strategy") == "append_zip_route_registration_comment":
                if "project-zip" in original:
                    results.append({"status": "already_present", "operation": op})
                    continue
                patched = original + "\n\n// [JARVIS_V3_PATCH] Registrar project-zip routes aqui.\n"
            else:
                results.append({"status": "unsupported_strategy", "operation": op})
                continue

            if apply_patch:
                with open(full, "w", encoding="utf-8", newline="\n") as f:
                    f.write(patched)
                results.append({"status": "applied", "operation": op})
            else:
                results.append({"status": "planned_only", "operation": op, "preview_added_chars": len(patched) - len(original)})

        elif op_type == "create_file":
            full = os.path.join(project_root, op["target_file"])
            if apply_patch:
                os.makedirs(os.path.dirname(full), exist_ok=True)
                if not os.path.exists(full):
                    with open(full, "w", encoding="utf-8", newline="\n") as f:
                        f.write(ZIP_ROUTE_FILE + "\n")
                    results.append({"status": "created", "operation": op})
                else:
                    results.append({"status": "already_exists", "operation": op})
            else:
                results.append({"status": "planned_only", "operation": op})

        else:
            results.append({"status": "not_applied", "operation": op})

    return {"mode": "apply" if apply_patch else "dry_run", "results": results}
