def plan_patch(mission: dict, evidence: dict, classification: dict) -> dict:
    scan = evidence.get("scan", {})
    interesting = scan.get("interesting_files", [])
    root_cause = classification.get("primary", {}).get("root_cause")

    patch_plan = {"root_cause": root_cause, "operations": [], "mode": "supervised", "risk": "medium"}

    if root_cause == "missing_input_validation":
        target = next((f for f in interesting if f.endswith("aiRoutes.js")), None)
        if target:
            patch_plan["operations"].append({
                "type": "patch_text",
                "target_file": target,
                "strategy": "append_safe_guard_template",
                "description": "Adicionar guardas de req.file e mimetype no fluxo vision."
            })
        else:
            patch_plan["operations"].append({"type": "manual_target_needed", "description": "Arquivo aiRoutes.js não encontrado automaticamente."})

    elif root_cause == "zip_route_missing":
        target = next((f for f in interesting if f.endswith(("app.js", "server.js", "index.js"))), None)
        patch_plan["operations"].append({
            "type": "create_file",
            "target_file": "src/routes/projectIngestRoutes.js",
            "description": "Criar rota inicial de ingestão ZIP."
        })
        if target:
            patch_plan["operations"].append({
                "type": "patch_text",
                "target_file": target,
                "strategy": "append_zip_route_registration_comment",
                "description": "Registrar rota project-zip no bootstrap do servidor."
            })

    elif root_cause == "provider_not_configured":
        patch_plan["operations"].append({
            "type": "config_checklist",
            "description": "Conferir VISION_PROVIDER, VISION_API_KEY, VISION_BASE_URL e VISION_MODEL."
        })
    else:
        patch_plan["operations"].append({"type": "manual_review", "description": "Sem patch automático seguro definido."})

    return patch_plan
