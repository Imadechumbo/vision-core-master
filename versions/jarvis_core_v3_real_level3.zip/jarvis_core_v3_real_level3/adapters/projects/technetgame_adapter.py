def load_adapter() -> dict:
    return {
        "project_id": "technetgame",
        "required_gates": [
            "health_gate",
            "vision_contract_gate",
            "vision_provider_gate",
            "zip_ingest_gate",
        ],
        "known_routes": [
            "/api/health",
            "/api/v1/chat/vision",
            "/api/v1/vision",
            "/api/v1/chat/project-zip",
        ],
    }
