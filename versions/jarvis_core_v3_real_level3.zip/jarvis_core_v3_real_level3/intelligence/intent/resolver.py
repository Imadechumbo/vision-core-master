from typing import Dict

def resolve_intent(text: str) -> Dict:
    lower = text.lower()
    project_id = "generic"
    if "technetgame" in lower or "technet ai" in lower:
        project_id = "technetgame"

    if "vision" in lower:
        intent = "fix_vision"
        targets = ["backend", "ai"]
    elif "zip" in lower:
        intent = "fix_zip_ingest"
        targets = ["backend", "content"]
    elif "runtime" in lower:
        intent = "diagnose_runtime"
        targets = ["runtime"]
    else:
        intent = "general_diagnosis"
        targets = ["unknown"]

    return {"project_id": project_id, "intent": intent, "targets": targets}
