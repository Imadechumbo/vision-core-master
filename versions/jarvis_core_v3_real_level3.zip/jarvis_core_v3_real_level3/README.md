# JARVIS CORE V3 EXECUTÁVEL — REAL NÍVEL 3

Base executável com:

- patch planner
- patch applier supervisionado
- scan de projeto local por árvore/arquivos
- incident store em JSON e SQLite
- playbooks RCA por intent
- gates reais iniciais para TechNetGame

## Executar
```bash
python apps/cli/jarvis.py "corrigir vision do technetgame" --project-root "C:/caminho/projeto"
python apps/cli/jarvis.py "corrigir vision do technetgame" --project-root "C:/caminho/projeto" --apply-patch
```
