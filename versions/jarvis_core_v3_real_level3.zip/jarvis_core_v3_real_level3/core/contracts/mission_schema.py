from dataclasses import dataclass, field
from typing import List, Dict, Any
import uuid

@dataclass
class Mission:
    mission_id: str
    project_id: str
    intent: str
    targets: List[str] = field(default_factory=list)
    surface: str = ""
    artifacts: List[Dict[str, Any]] = field(default_factory=list)
    constraints: Dict[str, Any] = field(default_factory=dict)
    risk_profile: str = "medium"

    @classmethod
    def create(cls, project_id: str, intent: str, **kwargs):
        return cls(
            mission_id=str(uuid.uuid4()),
            project_id=project_id,
            intent=intent,
            **kwargs,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mission_id": self.mission_id,
            "project_id": self.project_id,
            "intent": self.intent,
            "targets": self.targets,
            "surface": self.surface,
            "artifacts": self.artifacts,
            "constraints": self.constraints,
            "risk_profile": self.risk_profile,
        }
