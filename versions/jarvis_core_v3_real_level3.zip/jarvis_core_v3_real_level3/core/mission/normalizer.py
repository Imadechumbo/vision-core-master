from core.contracts.mission_schema import Mission
from intelligence.intent.resolver import resolve_intent

def normalize_mission(text: str) -> Mission:
    resolved = resolve_intent(text)
    return Mission.create(
        project_id=resolved["project_id"],
        intent=resolved["intent"],
        targets=resolved["targets"],
        constraints={
            "require_pass_gold": True,
            "allow_production": False,
            "allow_autopatch": True,
        },
        risk_profile="high" if resolved["intent"] in {"fix_vision", "fix_zip_ingest"} else "medium",
    )
