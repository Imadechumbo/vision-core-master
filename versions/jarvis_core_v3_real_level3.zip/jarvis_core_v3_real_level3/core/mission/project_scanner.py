from __future__ import annotations
import os
from typing import Dict, List

KNOWN_ROUTE_FILES = {"aiRoutes.js", "routes.js", "server.js", "app.js", "index.js"}

def _safe_read(path: str, limit: int = 4000) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(limit)
    except Exception:
        return ""

def scan_project_tree(project_root: str) -> Dict:
    if not project_root or not os.path.isdir(project_root):
        return {"ok": False, "error": "PROJECT_ROOT_NOT_FOUND", "project_root": project_root}

    total_files = 0
    interesting_files: List[str] = []
    package_json = None
    requirements_txt = None
    route_hits = []
    env_like = []
    detected_stack = {"runtime": "unknown", "framework": "unknown"}

    for base, _, files in os.walk(project_root):
        for name in files:
            total_files += 1
            full = os.path.join(base, name)
            rel = os.path.relpath(full, project_root).replace("\\", "/")
            if name == "package.json":
                package_json = rel
            elif name == "requirements.txt":
                requirements_txt = rel

            if name in KNOWN_ROUTE_FILES or "route" in name.lower():
                interesting_files.append(rel)

            if name.startswith(".env") or name.endswith(".env") or name.lower() == "env":
                env_like.append(rel)

            if name in KNOWN_ROUTE_FILES or rel.endswith(("server.js","app.js","aiRoutes.js")):
                text = _safe_read(full)
                for token in ["/api/health", "/api/v1/chat/vision", "/api/v1/vision", "/api/v1/chat/project-zip"]:
                    if token in text:
                        route_hits.append({"file": rel, "route": token})

    if package_json:
        detected_stack = {"runtime": "node", "framework": "possible-express"}
    elif requirements_txt:
        detected_stack = {"runtime": "python", "framework": "unknown"}

    return {
        "ok": True,
        "project_root": project_root,
        "detected_stack": detected_stack,
        "total_files": total_files,
        "package_json": package_json,
        "requirements_txt": requirements_txt,
        "interesting_files": sorted(set(interesting_files))[:100],
        "route_hits": route_hits,
        "env_like_files": env_like[:50],
    }
