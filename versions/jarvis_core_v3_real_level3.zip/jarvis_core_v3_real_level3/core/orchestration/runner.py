import os
from core.mission.normalizer import normalize_mission
from diagnostics.playbooks.loader import load_playbook_for_intent
from diagnostics.evidence.evidence_collector import collect_evidence
from diagnostics.classifier.root_cause_classifier import classify_root_causes
from diagnostics.cause_chain.cause_chain import build_cause_chain
from remediation.patching.patch_planner import plan_patch
from remediation.patching.patch_applier import apply_patch_plan
from security.aegis.policy import evaluate_policy
from validation.truth.gate_runner import run_gates
from memory.incidents.incident_store import IncidentStore
from memory.obsidian.obsidian_logger import write_obsidian_note
from adapters.projects.technetgame_adapter import load_adapter

def run_mission(text: str, project_root: str = "", apply_patch: bool = False) -> dict:
    mission = normalize_mission(text).to_dict()
    adapter = load_adapter() if mission["project_id"] == "technetgame" else {"required_gates": ["health_gate"]}
    playbook = load_playbook_for_intent(mission["intent"], os.path.join(os.path.dirname(__file__), "..", "..", "diagnostics", "playbooks"))
    playbook["recommended_gates"] = adapter["required_gates"]

    evidence = collect_evidence(mission, project_root)
    classification = classify_root_causes(mission, evidence)
    cause_chain = build_cause_chain(classification)
    patch_plan = plan_patch(mission, evidence, classification)
    policy = evaluate_policy(mission, patch_plan, apply_patch)
    patch_execution = apply_patch_plan(project_root, patch_plan, apply_patch=(apply_patch and not policy["blocked"])) if project_root else {"mode":"none","results":[]}
    gates = run_gates(playbook.get("recommended_gates", []), evidence)

    store = IncidentStore(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))
    incident = store.build_incident(mission, classification, cause_chain, {
        "evidence": evidence,
        "patch_plan": patch_plan,
        "policy": policy,
        "gates": gates,
    })
    store.save(incident)
    note_path = write_obsidian_note(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")), mission, classification, patch_plan, gates)

    return {
        "mission": mission,
        "playbook": playbook,
        "evidence": evidence,
        "classification": classification,
        "cause_chain": cause_chain,
        "patch_plan": patch_plan,
        "policy": policy,
        "patch_execution": patch_execution,
        "gates": gates,
        "incident_id": incident["incident_id"],
        "obsidian_note": note_path,
    }
