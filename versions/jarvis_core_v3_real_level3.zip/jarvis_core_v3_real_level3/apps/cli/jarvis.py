import os, sys, json, argparse

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from core.orchestration.runner import run_mission

def main():
    parser = argparse.ArgumentParser(description="JARVIS CORE V3 REAL NÍVEL 3")
    parser.add_argument("mission", help="Missão em linguagem natural")
    parser.add_argument("--project-root", default="", help="Raiz local do projeto alvo")
    parser.add_argument("--apply-patch", action="store_true", help="Aplica patch supervisionado")
    args = parser.parse_args()

    result = run_mission(args.mission, project_root=args.project_root, apply_patch=args.apply_patch)
    print(json.dumps(result, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
