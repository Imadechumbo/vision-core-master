# JARVIS CORE V5.1

Plataforma autônoma universal base para operação técnica multi-projeto.

## O que mudou no V5.1
- patch AST real para Node/Express (JavaScript com esprima)
- patch AST real para FastAPI/Python (módulo ast)
- fila distribuída com Redis opcional e fallback local
- worker Python dedicado
- adapters iniciais para Cloudflare Pages, AWS Elastic Beanstalk e Docker
- dashboard com estado da fila
- runtime com endpoint de enqueue

## Instalação
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Projeto
```bash
python apps/cli/jarvis.py project add technetgame --root "CAMINHO" --stack node_express
```

## Missão
```bash
python apps/cli/jarvis.py mission "corrigir vision do technetgame" --project technetgame --base-url "https://api.technetgame.com.br" --dry-run
```

## Fila distribuída
Sem Redis:
- usa fila local em disco

Com Redis:
```bash
set REDIS_URL=redis://127.0.0.1:6379/0
python workers/python_worker.py
```

## Dashboard
```bash
uvicorn jarvis_v5.interface_plane.api:app --host 127.0.0.1 --port 8088
```

## Runtime
```bash
uvicorn runtime.server:app --host 127.0.0.1 --port 8090
```
