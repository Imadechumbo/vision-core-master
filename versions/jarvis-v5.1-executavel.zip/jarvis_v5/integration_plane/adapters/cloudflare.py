import os


class CloudflareAdapter:
    def find_critical_files(self, files):
        return [f for f in files if any(k in f.lower() for k in ["wrangler", "_redirects", "runtime-config", "cloudflare", "pages"])][:20]

    def critical_endpoints(self):
        return []

    def infer_notes(self, mission):
        return ["adapter Cloudflare ativo", "inspeciona Pages, wrangler e runtime-config"]

    def inspect(self, project_root: str):
        return {
            "has_token": bool(os.getenv("CLOUDFLARE_API_TOKEN")),
            "has_zone": bool(os.getenv("CLOUDFLARE_ZONE_ID")),
            "has_account": bool(os.getenv("CLOUDFLARE_ACCOUNT_ID")),
        }

    def build_patch_candidate(self, mission, evidence, project_root):
        return {
            "strategy_key": "cloudflare_config_review",
            "target_file": None,
            "before": "",
            "after": "",
            "operations": [],
            "summary": "Adapter Cloudflare faz inspeção e diagnóstico; patch automático não definido.",
            "metadata": {"infra": True},
        }

    def estimate_risk(self, candidate):
        return "high"

    def apply_patch(self, patch, project_root):
        return {"applied": False, "mode": "require_approval", "notes": ["Patch Cloudflare deve ser aprovado manualmente."]}
