try:
    import docker
except Exception:
    docker = None


class DockerAdapter:
    def find_critical_files(self, files):
        return [f for f in files if any(k in f.lower() for k in ["dockerfile", "docker-compose", "compose.yml", "compose.yaml", "container"])][:20]

    def critical_endpoints(self):
        return []

    def infer_notes(self, mission):
        return ["adapter Docker ativo", "inspeciona Dockerfile e compose"]

    def inspect(self):
        if docker is None:
            return {"docker_python_available": False, "engine_access": False}
        try:
            client = docker.from_env()
            client.ping()
            return {"docker_python_available": True, "engine_access": True}
        except Exception as exc:
            return {"docker_python_available": True, "engine_access": False, "error": str(exc)}

    def build_patch_candidate(self, mission, evidence, project_root):
        return {
            "strategy_key": "docker_config_review",
            "target_file": None,
            "before": "",
            "after": "",
            "operations": [],
            "summary": "Adapter Docker faz inspeção de runtime; patch automático não definido.",
            "metadata": {"infra": True},
        }

    def estimate_risk(self, candidate):
        return "high"

    def apply_patch(self, patch, project_root):
        return {"applied": False, "mode": "require_approval", "notes": ["Patch Docker deve ser aprovado manualmente."]}
