from pathlib import Path

from jarvis_v5.intelligence_plane.ast_patchers import JavaScriptASTPatcher


class NodeExpressAdapter:
    def __init__(self):
        self.js_patcher = JavaScriptASTPatcher()

    def find_critical_files(self, files):
        priorities = ["aiRoutes.js", "routes", "vision", "chat", "server.js", "app.js", "index.js"]
        scored = []
        for file in files:
            lowered = file.lower()
            score = 0
            if lowered.endswith('airoutes.js'):
                score += 20
            if '/routes/' in lowered or '\\routes\\' in lowered:
                score += 10
            if 'vision' in lowered:
                score += 8
            if 'chat' in lowered:
                score += 5
            if lowered.endswith(('server.js', 'app.js', 'index.js')):
                score += 3
            if score:
                scored.append((score, file))
        return [item[1] for item in sorted(scored, reverse=True)[:20]]

    def critical_endpoints(self):
        return [
            {"name": "health", "method": "GET", "path": "/api/health"},
            {"name": "chat", "method": "POST", "path": "/api/v1/chat", "json": {"message": "ping"}},
            {"name": "vision", "method": "POST", "path": "/api/v1/chat/vision", "json": {"message": "ping"}},
        ]

    def infer_notes(self, mission):
        notes = ["adapter Node/Express ativo"]
        if mission["intent"] == "fix_vision":
            notes.append("patch AST JavaScript habilitado para vision/upload")
        return notes

    def _pick_target(self, project_root):
        root = Path(project_root)
        candidates = []
        for p in root.rglob("*.js"):
            rel = str(p.relative_to(root)).replace("\\", "/")
            score = 0
            lowered = rel.lower()
            if lowered.endswith('airoutes.js'):
                score += 30
            if '/routes/' in lowered:
                score += 20
            if 'vision' in lowered:
                score += 10
            if 'chat' in lowered:
                score += 7
            if lowered.endswith(('server.js', 'app.js', 'index.js')):
                score += 4
            if score:
                candidates.append((score, rel, p))
        candidates.sort(reverse=True)
        return candidates[0][2] if candidates else None

    def build_patch_candidate(self, mission, evidence, project_root):
        target = self._pick_target(project_root)
        before = target.read_text(encoding="utf-8", errors="ignore") if target and target.exists() else ""
        if mission["intent"] == "fix_vision" and before:
            patch = self.js_patcher.patch_express_vision(before)
            after = patch.after
            strategy_key = patch.strategy_key
            summary = patch.summary
            metadata = patch.metadata
        else:
            after = before
            strategy_key = "node_express_noop"
            summary = "Nenhum patch automático definido para esta missão."
            metadata = {"ast": False}

        return {
            "strategy_key": strategy_key,
            "target_file": str(target) if target else None,
            "before": before,
            "after": after,
            "operations": [{"type": "ast_insert_guard", "file": str(target) if target else None}],
            "summary": summary,
            "metadata": metadata,
        }

    def estimate_risk(self, candidate):
        if not candidate.get("target_file"):
            return "high"
        return "low" if candidate.get("metadata", {}).get("ast") else "medium"

    def apply_patch(self, patch, project_root):
        target_file = patch.get("target_file")
        if not target_file:
            return {"applied": False, "mode": "require_approval", "notes": ["Arquivo alvo não identificado."]}
        path = Path(target_file)
        backup = path.with_suffix(path.suffix + ".jarvis.bak")
        if not backup.exists():
            backup.write_text(patch.get("before", ""), encoding="utf-8")
        path.write_text(patch.get("after", ""), encoding="utf-8")
        return {"applied": True, "mode": "auto_apply", "notes": [f"Patch AST aplicado em {path.name}", f"Backup salvo em {backup.name}"]}
