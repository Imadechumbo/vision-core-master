from pathlib import Path

class GenericAdapter:
    def find_critical_files(self, files):
        return [f for f in files if any(k in f.lower() for k in ["app", "main", "server", "route"])][:20]

    def critical_endpoints(self):
        return [{"name": "health", "method": "GET", "path": "/health"}]

    def infer_notes(self, mission):
        return ["adapter genérico ativo"]

    def build_patch_candidate(self, mission, evidence, project_root):
        return {
            "strategy_key": f"{mission['intent']}_generic_guard",
            "target_file": None,
            "before": "",
            "after": "",
            "operations": [],
            "summary": "Nenhum patch específico disponível para este stack.",
        }

    def estimate_risk(self, candidate):
        return "high"

    def apply_patch(self, patch, project_root):
        return {"applied": False, "mode": "require_approval", "notes": ["Adapter genérico não aplica patch automático."]}
