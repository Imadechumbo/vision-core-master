import os

try:
    import boto3
except Exception:
    boto3 = None


class AwsElasticBeanstalkAdapter:
    def find_critical_files(self, files):
        return [f for f in files if any(k in f.lower() for k in ["procfile", ".ebextensions", "elasticbeanstalk", "package.json", "00-environment"])][:20]

    def critical_endpoints(self):
        return []

    def infer_notes(self, mission):
        return ["adapter AWS Elastic Beanstalk ativo", "inspeciona Procfile, .ebextensions e ambiente"]

    def inspect(self):
        return {
            "boto3_available": boto3 is not None,
            "aws_region": os.getenv("AWS_REGION") or os.getenv("AWS_DEFAULT_REGION"),
            "has_access_key": bool(os.getenv("AWS_ACCESS_KEY_ID")),
        }

    def build_patch_candidate(self, mission, evidence, project_root):
        return {
            "strategy_key": "aws_eb_config_review",
            "target_file": None,
            "before": "",
            "after": "",
            "operations": [],
            "summary": "Adapter AWS EB faz inspeção de ambiente; patch automático não definido.",
            "metadata": {"infra": True},
        }

    def estimate_risk(self, candidate):
        return "high"

    def apply_patch(self, patch, project_root):
        return {"applied": False, "mode": "require_approval", "notes": ["Patch AWS EB deve ser aprovado manualmente."]}
