from pathlib import Path
from jarvis_v5.integration_plane.adapter_router import AdapterRouter
from jarvis_v5.intelligence_plane.project_scanner import ProjectScanner
from jarvis_v5.intelligence_plane.evidence_collector import EvidenceCollector
from jarvis_v5.intelligence_plane.adaptive_rca import AdaptiveRCA
from jarvis_v5.intelligence_plane.patch_engine import SmartPatchEngine
from jarvis_v5.intelligence_plane.policy_engine import AegisPolicy
from jarvis_v5.intelligence_plane.gates import GateRunner

class MissionExecutor:
    def __init__(self, storage_root: Path, registry, incident_store, strategy_store, stable_vault):
        self.storage_root = Path(storage_root)
        self.registry = registry
        self.incident_store = incident_store
        self.strategy_store = strategy_store
        self.stable_vault = stable_vault

    def execute(self, mission: dict):
        project = mission["project"]
        adapter = AdapterRouter().for_project(project)
        scan = ProjectScanner().scan(project["root"])
        evidence = EvidenceCollector(adapter).collect(scan=scan, mission=mission)
        rca = AdaptiveRCA(self.incident_store, self.strategy_store).analyze(mission, evidence)
        patch = SmartPatchEngine(adapter, self.strategy_store).generate(mission, evidence, rca, project["root"])
        policy = AegisPolicy().evaluate(patch, mission)
        execution = {"applied": False, "mode": "blocked", "notes": []}

        if policy["decision"] == "auto_apply" and not mission.get("dry_run"):
            execution = adapter.apply_patch(patch, project["root"])
        else:
            execution = {"applied": False, "mode": "dry_run" if mission.get("dry_run") else policy["decision"], "notes": ["Patch não aplicado automaticamente."]}

        gates = GateRunner(adapter).run(project, mission, evidence)
        pass_gold = gates["pass_gold"]

        incident = self.incident_store.record(
            project=project["name"],
            mission=mission,
            evidence=evidence,
            rca=rca,
            patch=patch,
            policy=policy,
            execution=execution,
            gates=gates,
        )

        self.strategy_store.update_score(
            project=project["name"],
            strategy_key=patch["strategy_key"],
            success=pass_gold,
            metadata={"intent": mission["intent"], "risk": patch["risk_level"]},
        )

        if pass_gold:
            stable_result = self.stable_vault.promote(project["name"])
        elif mission.get("auto_rollback"):
            stable_result = self.stable_vault.rollback(project["name"], project["root"])
        else:
            stable_result = {"status": "not_promoted"}

        return {
            "mission": mission,
            "scan": scan,
            "evidence": evidence,
            "rca": rca,
            "patch": patch,
            "policy": policy,
            "execution": execution,
            "gates": gates,
            "pass_gold": pass_gold,
            "incident": incident,
            "stable": stable_result,
        }
