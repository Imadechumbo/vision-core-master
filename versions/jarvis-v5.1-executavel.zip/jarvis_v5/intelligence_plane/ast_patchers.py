from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Optional

try:
    import esprima
except Exception:
    esprima = None


@dataclass
class PatchResult:
    language: str
    changed: bool
    before: str
    after: str
    strategy_key: str
    summary: str
    metadata: dict


def _line_starts(text: str) -> list[int]:
    starts = [0]
    for idx, ch in enumerate(text):
        if ch == "\n":
            starts.append(idx + 1)
    return starts


def _offset_from_line_col(text: str, line: int, col: int) -> int:
    starts = _line_starts(text)
    if line - 1 >= len(starts):
        return len(text)
    return starts[line - 1] + col


class PythonASTPatcher:
    guard_name = "jarvis_v51_validate_vision_input"

    def patch_fastapi_vision(self, source: str) -> PatchResult:
        if self.guard_name in source:
            return PatchResult(
                "python",
                False,
                source,
                source,
                "python_ast_fastapi_vision_guard",
                "Guard AST já presente.",
                {"ast": True},
            )
        tree = ast.parse(source)
        target_fn = None
        for node in ast.walk(tree):
            if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)):
                for dec in getattr(node, "decorator_list", []):
                    if isinstance(dec, ast.Call) and getattr(dec.func, "attr", "") in {"post", "api_route"}:
                        for arg in dec.args:
                            if isinstance(arg, ast.Constant) and isinstance(arg.value, str) and "vision" in arg.value:
                                target_fn = node
                                break
                if target_fn:
                    break

        helper = (
            "\n\ndef jarvis_v51_validate_vision_input(request):\n"
            "    if not getattr(request, 'headers', None):\n"
            "        raise ValueError('missing_request_context')\n"
            "    content_type = request.headers.get('content-type', '')\n"
            "    if 'multipart/form-data' not in content_type and 'application/json' not in content_type:\n"
            "        raise ValueError('unsupported_content_type')\n"
        )

        after = source
        if target_fn and hasattr(target_fn, "body") and target_fn.body:
            first_stmt = target_fn.body[0]
            insert_pos = _offset_from_line_col(source, first_stmt.lineno, 0)
            indent = " " * first_stmt.col_offset
            guard_code = indent + "jarvis_v51_validate_vision_input(request)\n"
            after = source[:insert_pos] + guard_code + source[insert_pos:] + helper
            ast.parse(after)
            return PatchResult(
                "python",
                True,
                source,
                after,
                "python_ast_fastapi_vision_guard",
                "Guard AST inserido em endpoint FastAPI vision.",
                {"ast": True, "target": getattr(target_fn, "name", None)},
            )

        after = source + helper
        ast.parse(after)
        return PatchResult(
            "python",
            True,
            source,
            after,
            "python_ast_fastapi_helper_only",
            "Helper AST adicionado; endpoint vision não encontrado automaticamente.",
            {"ast": True, "target": None},
        )


class JavaScriptASTPatcher:
    guard_marker = "JARVIS_V51_VISION_GUARD"

    def patch_express_vision(self, source: str) -> PatchResult:
        if self.guard_marker in source:
            return PatchResult(
                "javascript",
                False,
                source,
                source,
                "node_ast_express_vision_guard",
                "Guard AST já presente.",
                {"ast": True},
            )
        if esprima is None:
            raise RuntimeError("esprima não disponível para AST JavaScript")

        tree = esprima.parseScript(source, options={"range": True, "tolerant": True})
        target = self._find_vision_handler(tree)
        if not target:
            raise ValueError("Nenhum handler vision encontrado via AST")

        body_start = target.body.range[0] + 1
        inner_indent = "  "
        guard = (
            f"\n{inner_indent}// {self.guard_marker}_START\n"
            f"{inner_indent}if (!req.file && !req.files && !(req.body && req.body.image) && !(req.body && req.body.imageUrl)) {{\n"
            f"{inner_indent}  return res.status(400).json({{\n"
            f"{inner_indent}    ok: false,\n"
            f"{inner_indent}    error: 'missing_image_input',\n"
            f"{inner_indent}    detail: 'Envie arquivo, image, imageUrl ou equivalente.'\n"
            f"{inner_indent}  }});\n"
            f"{inner_indent}}}\n"
            f"{inner_indent}// {self.guard_marker}_END\n"
        )
        after = source[:body_start] + guard + source[body_start:]
        esprima.parseScript(after, options={"range": True, "tolerant": True})
        return PatchResult(
            "javascript",
            True,
            source,
            after,
            "node_ast_express_vision_guard",
            "Guard AST inserido em rota Express vision.",
            {"ast": True, "range": target.range},
        )

    def _find_vision_handler(self, tree) -> Optional[object]:
        target = None

        def visit(node):
            nonlocal target
            if target is not None or node is None:
                return
            if isinstance(node, list):
                for item in node:
                    visit(item)
                return
            if not hasattr(node, "type"):
                return

            if node.type == "CallExpression":
                callee = getattr(node, "callee", None)
                args = getattr(node, "arguments", []) or []
                prop = getattr(callee, "property", None)
                method_name = getattr(prop, "name", None)
                if method_name in {"post", "use"} and args:
                    first = args[0]
                    route = getattr(first, "value", None) if getattr(first, "type", None) == "Literal" else None
                    if isinstance(route, str) and "vision" in route:
                        for cand in reversed(args[1:]):
                            if getattr(cand, "type", None) in {"ArrowFunctionExpression", "FunctionExpression"}:
                                target = cand
                                return
            for value in node.__dict__.values():
                if isinstance(value, list) or hasattr(value, "type"):
                    visit(value)

        visit(tree)
        return target
