class AegisPolicy:
    def evaluate(self, patch: dict, mission: dict):
        risk = patch["risk_level"]
        if mission.get("dry_run"):
            return {"decision": "dry_run", "reason": "dry-run solicitado"}
        if risk == "low":
            return {"decision": "auto_apply", "reason": "baixo risco"}
        if risk == "medium" and mission.get("auto_apply"):
            return {"decision": "auto_apply", "reason": "médio risco com auto-apply explícito"}
        return {"decision": "require_approval", "reason": f"risco {risk}"}
