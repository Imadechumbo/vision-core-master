import requests


class GateRunner:
    def __init__(self, adapter):
        self.adapter = adapter

    def _probe(self, method, url, json_body=None):
        try:
            r = requests.request(method, url, timeout=5, json=json_body)
            body = r.text[:300]
            return {"ok": r.status_code < 500, "status": r.status_code, "body": body}
        except Exception as exc:
            return {"ok": False, "status": 0, "body": str(exc)}

    def run(self, project: dict, mission: dict, evidence: dict):
        base_url = mission.get("base_url")
        checks = []
        if base_url and self.adapter.critical_endpoints():
            for endpoint in self.adapter.critical_endpoints():
                url = base_url.rstrip("/") + endpoint["path"]
                checks.append({
                    "name": endpoint["name"],
                    "method": endpoint["method"],
                    "url": url,
                    "result": self._probe(endpoint["method"], url, endpoint.get("json")),
                })
        else:
            checks.append({"name": "base_url_missing_or_no_http_checks", "result": {"ok": False, "status": 0, "body": "base_url não informado ou adapter sem gates HTTP"}})

        local_signals = {
            "critical_files_found": bool(evidence.get("critical_files")),
            "root_exists": evidence.get("scan_signals", {}).get("root_exists", False),
        }
        pass_gold = bool(base_url) and all(item["result"]["ok"] for item in checks)
        return {"checks": checks, "local_signals": local_signals, "pass_gold": pass_gold}
