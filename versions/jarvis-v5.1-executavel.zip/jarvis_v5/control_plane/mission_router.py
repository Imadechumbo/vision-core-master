from datetime import datetime, timezone

class MissionRouter:
    def route(self, text: str, project: dict, base_url: str | None, dry_run: bool, auto_apply: bool, auto_rollback: bool):
        lowered = text.lower()
        if "vision" in lowered:
            intent = "fix_vision"
        elif "deploy" in lowered or "build" in lowered:
            intent = "stabilize_deploy"
        else:
            intent = "general_diagnosis"

        return {
            "id": f"mission_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}",
            "text": text,
            "intent": intent,
            "project": project,
            "base_url": base_url,
            "dry_run": dry_run,
            "auto_apply": auto_apply,
            "auto_rollback": auto_rollback,
        }
