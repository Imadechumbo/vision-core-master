# MANUAL MESTRE — JARVIS CORE V5.1

## Estado
V5.1 executável.

## Capacidades principais
- multi-projeto
- scoring de estratégias
- incident store JSON + SQLite
- stable vault
- rollback
- gates HTTP reais
- patch AST Python e JavaScript
- adapters de aplicação e infra
- fila distribuída com fallback local

## Stacks suportadas
- node_express
- python_fastapi
- cloudflare_pages
- aws_elastic_beanstalk
- docker_runtime

## Regra central
SEM PASS GOLD -> NADA É PROMOVIDO
