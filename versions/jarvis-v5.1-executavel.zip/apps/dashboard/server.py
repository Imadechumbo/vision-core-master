from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import uvicorn
from jarvis_v5.interface_plane.api import app

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8088)
