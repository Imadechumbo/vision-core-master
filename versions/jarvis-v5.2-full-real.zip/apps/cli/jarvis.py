import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from jarvis_v5.control_plane.registry import ProjectRegistry
from jarvis_v5.control_plane.mission_router import MissionRouter
from jarvis_v5.control_plane.execution_controller import ExecutionController
from jarvis_v5.control_plane.scheduler import SchedulerService
from jarvis_v5.memory_plane.incident_store import IncidentStore
from jarvis_v5.memory_plane.strategy_store import StrategyStore
from jarvis_v5.memory_plane.stable_vault import StableVault
from jarvis_v5.memory_plane.patch_history import PatchHistoryStore
from jarvis_v5.execution_plane.distributed_queue import DistributedQueue


def build_parser():
    parser = argparse.ArgumentParser(description='JARVIS CORE V5.2 FULL REAL')
    sub = parser.add_subparsers(dest='command')

    project = sub.add_parser('project', help='Gerenciar projetos')
    psub = project.add_subparsers(dest='project_command')
    padd = psub.add_parser('add')
    padd.add_argument('name')
    padd.add_argument('--root', required=True)
    padd.add_argument('--stack', required=True, choices=['node_express', 'python_fastapi', 'cloudflare_pages', 'aws_elastic_beanstalk', 'docker_runtime', 'generic'])
    psub.add_parser('list')

    mission = sub.add_parser('mission', help='Executar missão')
    mission.add_argument('text')
    mission.add_argument('--project', required=True)
    mission.add_argument('--base-url')
    mission.add_argument('--dry-run', action='store_true')
    mission.add_argument('--auto-apply', action='store_true')
    mission.add_argument('--auto-rollback', action='store_true')

    incidents = sub.add_parser('incidents', help='Listar incidentes')
    incidents.add_argument('--project', required=False)
    incidents.add_argument('--filter', required=False)

    strategies = sub.add_parser('strategies', help='Listar estratégias')
    strategies.add_argument('--project', required=False)

    patches = sub.add_parser('patches', help='Histórico de patches')
    patches.add_argument('--project', required=False)

    stable = sub.add_parser('stable', help='Stable vault')
    ssub = stable.add_subparsers(dest='stable_command')
    sprom = ssub.add_parser('promote')
    sprom.add_argument('--project', required=True)
    srollback = ssub.add_parser('rollback')
    srollback.add_argument('--project', required=True)
    srollback.add_argument('--target', required=False)
    srollback.add_argument('--patch-id', required=False)
    slist = ssub.add_parser('list')
    slist.add_argument('--project', required=False)

    queue = sub.add_parser('queue', help='Estado da fila')
    queue.add_argument('action', choices=['info'])

    scheduler = sub.add_parser('scheduler', help='Scheduler por projeto')
    scheduler.add_argument('action', choices=['list', 'run'])
    scheduler.add_argument('--project', required=False)
    scheduler.add_argument('--force', action='store_true')

    runtime = sub.add_parser('runtime', help='Mostrar ajuda do runtime')
    runtime.add_argument('--host', default='127.0.0.1')
    runtime.add_argument('--port', default=8090, type=int)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    registry = ProjectRegistry(ROOT / 'storage' / 'projects')
    incidents = IncidentStore(ROOT / 'storage')
    strategies = StrategyStore(ROOT / 'storage')
    stable = StableVault(ROOT / 'storage')
    patches = PatchHistoryStore(ROOT / 'storage')
    queue = DistributedQueue(ROOT / 'storage' / 'queue')
    scheduler = SchedulerService(ROOT / 'storage', registry, queue)

    if args.command == 'project':
        if args.project_command == 'add':
            project = registry.add_project(args.name, args.root, args.stack)
            print(json.dumps(project, indent=2, ensure_ascii=False)); return
        if args.project_command == 'list':
            print(json.dumps(registry.list_projects(), indent=2, ensure_ascii=False)); return

    if args.command == 'mission':
        project = registry.get_project(args.project)
        if not project:
            raise SystemExit(f'Projeto não encontrado: {args.project}')
        router = MissionRouter()
        controller = ExecutionController(storage_root=ROOT / 'storage', registry=registry, incident_store=incidents, strategy_store=strategies, stable_vault=stable)
        mission = router.route(text=args.text, project=project, base_url=args.base_url, dry_run=args.dry_run, auto_apply=args.auto_apply, auto_rollback=args.auto_rollback)
        result = controller.run_mission(mission)
        print(json.dumps(result, indent=2, ensure_ascii=False)); return

    if args.command == 'incidents':
        print(json.dumps(incidents.query(project=args.project, keyword=args.filter), indent=2, ensure_ascii=False)); return
    if args.command == 'strategies':
        print(json.dumps(strategies.list_ranked(project=args.project), indent=2, ensure_ascii=False)); return
    if args.command == 'patches':
        print(json.dumps(patches.list(project=args.project), indent=2, ensure_ascii=False)); return
    if args.command == 'stable':
        if args.stable_command == 'promote':
            project = registry.get_project(args.project)
            print(json.dumps(stable.promote(args.project, project['root'] if project else None), indent=2, ensure_ascii=False)); return
        if args.stable_command == 'rollback':
            if args.patch_id:
                entry = patches.get(args.patch_id)
                if not entry: raise SystemExit('patch-id não encontrado')
                print(json.dumps(stable.rollback_patch(entry['target_file'], entry['backup_file']), indent=2, ensure_ascii=False)); return
            target = args.target or registry.get_project(args.project)['root']
            print(json.dumps(stable.rollback(args.project, target), indent=2, ensure_ascii=False)); return
        if args.stable_command == 'list':
            print(json.dumps(stable.list_entries(project=args.project), indent=2, ensure_ascii=False)); return
    if args.command == 'queue':
        print(json.dumps(queue.info(), indent=2, ensure_ascii=False)); return
    if args.command == 'scheduler':
        if args.action == 'list':
            print(json.dumps(scheduler.list_jobs(project=args.project), indent=2, ensure_ascii=False)); return
        if args.action == 'run':
            print(json.dumps(scheduler.run_due_jobs(force=args.force), indent=2, ensure_ascii=False)); return
    if args.command == 'runtime':
        print(json.dumps({'runtime': f"uvicorn runtime.server:app --host {args.host} --port {args.port}"}, indent=2, ensure_ascii=False)); return

    parser.print_help()


if __name__ == '__main__':
    main()
