from pathlib import Path

class ProjectScanner:
    def scan(self, project_root: str):
        root = Path(project_root)
        files = []
        envs = []
        package_json = False
        for p in root.rglob("*"):
            if p.is_file():
                rel = str(p.relative_to(root)).replace("\\", "/")
                files.append(rel)
                if p.name in {".env", ".env.example"}:
                    envs.append(rel)
                if p.name == "package.json":
                    package_json = True
                if len(files) >= 300:
                    break
        return {
            "root_exists": root.exists(),
            "root": str(root),
            "sample_files": files[:100],
            "env_files": envs,
            "signals": {
                "node_project": package_json,
                "has_routes": any("route" in f.lower() for f in files),
                "has_api": any("/api" in f.lower() or "api" in Path(f).name.lower() for f in files),
            }
        }
