class NodeAdapter:
    pass