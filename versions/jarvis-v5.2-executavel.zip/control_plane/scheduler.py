class SchedulerService:
    pass