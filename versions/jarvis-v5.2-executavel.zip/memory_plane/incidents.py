class IncidentStore:
    pass