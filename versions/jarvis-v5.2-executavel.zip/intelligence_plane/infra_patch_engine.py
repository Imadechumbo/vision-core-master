class InfraPatchEngine:
    pass